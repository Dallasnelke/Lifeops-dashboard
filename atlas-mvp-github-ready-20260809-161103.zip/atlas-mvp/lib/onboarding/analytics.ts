import type { OnboardingStepId } from "./types";

export type OnboardingAnalyticsEvent =
  | { name: "onboarding_started"; step: OnboardingStepId }
  | { name: "onboarding_step_viewed"; step: OnboardingStepId }
  | { name: "onboarding_step_completed"; step: OnboardingStepId }
  | { name: "onboarding_skipped"; step: OnboardingStepId }
  | { name: "personality_selected"; presetId: string }
  | { name: "character_customized"; field: string }
  | { name: "voice_previewed"; presetId: string }
  | { name: "focus_area_selected"; focusAreaId: string }
  | { name: "memory_permission_changed"; permissionId: string }
  | { name: "onboarding_completed"; step: OnboardingStepId };

export type OnboardingAnalytics = {
  track(event: OnboardingAnalyticsEvent): void;
};

export const noopOnboardingAnalytics: OnboardingAnalytics = {
  track() {
    // Provider intentionally omitted. This keeps analytics privacy-safe.
  },
};
