import type { ConversationMessage } from "@/lib/atlas/types";

type IdFactory = () => string;
type DateFactory = () => string;

function defaultIdFactory(): string {
  return crypto.randomUUID();
}

function defaultDateFactory(): string {
  return new Date().toISOString();
}

export function createConversationMessage(
  role: ConversationMessage["role"],
  content: string,
  status: ConversationMessage["status"] = "complete",
  idFactory: IdFactory = defaultIdFactory,
  dateFactory: DateFactory = defaultDateFactory,
): ConversationMessage {
  return { id: idFactory(), role, content, status, createdAt: dateFactory() };
}

export function appendAssistantContent(
  messages: ConversationMessage[],
  assistantId: string,
  content: string,
): ConversationMessage[] {
  return messages.map((message) =>
    message.id === assistantId ? { ...message, content } : message,
  );
}

export function completeAssistantMessage(
  messages: ConversationMessage[],
  assistantId: string,
  content: string,
  fallback = "Atlas finished without text.",
): ConversationMessage[] {
  const finalContent = content.trim() || fallback;
  return messages.map((message) =>
    message.id === assistantId
      ? { ...message, content: finalContent, status: "complete" }
      : message,
  );
}

export function failAssistantMessage(
  messages: ConversationMessage[],
  assistantId: string,
  content: string,
): ConversationMessage[] {
  return messages.map((message) =>
    message.id === assistantId
      ? { ...message, content, status: "error" }
      : message,
  );
}

export function stopStreamingMessages(
  messages: ConversationMessage[],
): ConversationMessage[] {
  return messages.map((message) =>
    message.status === "streaming"
      ? { ...message, status: "complete" }
      : message,
  );
}
