"use client";

import { AtlasWebGLStage } from "@/components/atlas/AtlasWebGLStage";
import type { AtlasPreferences, AtlasState } from "@/lib/atlas/types";

export type AtlasStageProps = {
  state: AtlasState;
  preferences: AtlasPreferences;
  onReady?: (ready: boolean) => void;
};

export function AtlasStage({ state, preferences, onReady }: AtlasStageProps) {
  return (
    <AtlasWebGLStage
      state={state}
      preferences={preferences}
      onReady={onReady}
    />
  );
}
