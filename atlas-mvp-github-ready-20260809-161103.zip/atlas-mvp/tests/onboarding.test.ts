import assert from "node:assert/strict";
import test from "node:test";
import { onboardingSteps, personalityPresets } from "../lib/onboarding/options";
import {
  buildFirstPlan,
  completeOnboardingProfile,
  createDefaultOnboardingProfile,
  sanitizeOnboardingProfile,
  selectNutritionGoal,
  selectPersonality,
  toggleChallenge,
} from "../lib/onboarding/profile";
import { localOnboardingRepository } from "../lib/onboarding/repository";

test("onboarding defaults create a valid nutrition-first local profile", () => {
  const profile = createDefaultOnboardingProfile("2026-01-01T00:00:00.000Z");
  assert.equal(profile.version, 2);
  assert.equal(profile.completed, false);
  assert.equal(profile.currentStep, "meet-atlas");
  assert.equal(onboardingSteps.length, 16);
  assert.equal(profile.personalityPreset, "balanced");
  assert.equal(profile.characterConfig.environmentPreset, "dark-studio");
  assert.equal(profile.memoryPermissions["body-baseline"], false);
  assert.equal(profile.memoryPermissions["sensitive-health"], false);
  assert.equal(profile.memoryPermissions.preferences, true);
});

test("nutrition goal and challenges update without mutating the profile", () => {
  const profile = createDefaultOnboardingProfile();
  const withGoal = selectNutritionGoal(profile, "body-recomposition");
  const withChallenge = toggleChallenge(withGoal, "low-protein");
  assert.equal(profile.nutritionGoal, "");
  assert.equal(withGoal.nutritionGoal, "body-recomposition");
  assert.deepEqual(withChallenge.challenges, ["low-protein"]);
});

test("personality preset updates communication and voice configuration", () => {
  const profile = createDefaultOnboardingProfile();
  const strategist = personalityPresets.find(
    (preset) => preset.id === "strategist",
  );
  const updated = selectPersonality(profile, "strategist");
  assert.equal(updated.personalityPreset, "strategist");
  assert.equal(updated.personalityOverrides.detail, strategist?.config.detail);
  assert.equal(updated.voiceConfig.presetId, strategist?.config.voiceStyle);
});

test("first plan is generated from nutrition goal and main challenge", () => {
  const profile = {
    ...createDefaultOnboardingProfile("2026-01-01T00:00:00.000Z"),
    nutritionGoal: "build-muscle" as const,
    eatingStyle: "high-protein" as const,
    challenges: ["low-protein" as const],
  };
  const plan = buildFirstPlan(profile);
  assert.match(plan.mission, /build muscle/i);
  assert.match(plan.recommendedAction, /low protein/i);
  assert.match(plan.safetyNote, /general wellness/i);
});

test("completion stores the generated first plan", () => {
  const profile = {
    ...createDefaultOnboardingProfile("2026-01-01T00:00:00.000Z"),
    nutritionGoal: "eat-consistently" as const,
    eatingStyle: "simple-prep" as const,
  };
  const completed = completeOnboardingProfile(
    profile,
    "2026-01-01T01:00:00.000Z",
  );
  assert.equal(completed.completed, true);
  assert.equal(completed.currentStep, "complete");
  assert.equal(completed.firstAction, completed.firstPlan.recommendedAction);
});

test("sanitization migrates old partial data with safe nutrition defaults", () => {
  const sanitized = sanitizeOnboardingProfile({
    completed: true,
    currentStep: "focus",
    preferredName: "A".repeat(80),
    personalityPreset: "direct",
    focusAreas: ["career", "money", "health"],
    memoryPermissions: { preferences: true, "body-baseline": true },
  });
  assert.ok(sanitized);
  assert.equal(sanitized?.version, 2);
  assert.equal(sanitized?.currentStep, "nutrition-goal");
  assert.equal(sanitized?.preferredName.length, 40);
  assert.equal(sanitized?.nutritionGoal, "");
  assert.deepEqual(sanitized?.legacyFocusAreas, ["career", "money", "health"]);
  assert.equal(sanitized?.personalityPreset, "direct");
  assert.equal(sanitized?.memoryPermissions["body-baseline"], true);
  assert.equal(sanitized?.memoryPermissions["sensitive-health"], false);
});

test("local onboarding repository saves, loads, and clears", () => {
  const store = new Map<string, string>();
  const fakeWindow = {
    localStorage: {
      getItem: (key: string) => store.get(key) ?? null,
      setItem: (key: string, value: string) => store.set(key, value),
      removeItem: (key: string) => store.delete(key),
    },
  };
  Object.defineProperty(globalThis, "window", {
    value: fakeWindow,
    configurable: true,
  });

  const profile = {
    ...createDefaultOnboardingProfile("2026-01-01T00:00:00.000Z"),
    preferredName: "Dallas",
  };

  assert.equal(localOnboardingRepository.save(profile), true);
  assert.equal(localOnboardingRepository.load()?.preferredName, "Dallas");
  localOnboardingRepository.clear();
  assert.equal(localOnboardingRepository.load(), null);
});
