import {
  challengeOptions,
  eatingStyleOptions,
  memoryPermissionOptions,
  nutritionGoalOptions,
  onboardingSteps,
  personalityPresets,
  trackingPreferenceOptions,
} from "./options";
import type {
  ActivityLevelId,
  ChallengeId,
  EatingStyleId,
  MemoryPermissionId,
  NutritionGoalId,
  OnboardingProfile,
  OnboardingStepId,
  PersonalityPresetId,
  TrackingPreferenceId,
} from "./types";
import { ONBOARDING_PROFILE_VERSION } from "./types";

export const ONBOARDING_PROFILE_STORAGE_KEY = "lifeops-onboarding-profile-v1";

const defaultMemoryPermissions = Object.fromEntries(
  memoryPermissionOptions.map((permission) => [
    permission.id,
    permission.sensitive ? false : true,
  ]),
) as Record<MemoryPermissionId, boolean>;

const legacyStepMap: Record<string, OnboardingStepId> = {
  "meet-atlas": "meet-atlas",
  identity: "identity",
  personality: "personality",
  character: "character",
  voice: "voice",
  focus: "nutrition-goal",
  challenges: "challenges",
  rhythm: "daily-rhythm",
  memory: "memory",
  review: "review",
  complete: "complete",
};

function cleanText(value: unknown, max = 160): string {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

function validStep(value: unknown): OnboardingStepId {
  return typeof value === "string" && onboardingSteps.includes(value as never)
    ? (value as OnboardingStepId)
    : legacyStepMap[String(value)] || "meet-atlas";
}

function firstValid<T extends string>(
  value: unknown,
  options: readonly T[],
  fallback: T,
): T {
  return typeof value === "string" && options.includes(value as T)
    ? (value as T)
    : fallback;
}

export function createDefaultOnboardingProfile(
  now = new Date().toISOString(),
): OnboardingProfile {
  return {
    version: ONBOARDING_PROFILE_VERSION,
    completed: false,
    currentStep: "meet-atlas",
    preferredName: "",
    language: "en",
    nutritionGoal: "",
    bodyBaseline: {
      age: "",
      height: "",
      weight: "",
      activityLevel: "not-sure",
      goalNote: "",
      comfortableSharingBodyData: false,
    },
    eatingStyle: "",
    foodPreferences: {
      likedFoods: "",
      dislikedFoods: "",
      dietaryNotes: "",
      budgetLevel: "not-sure",
      cookingAccess: "not-sure",
    },
    challenges: [],
    trackingPreference: "simple",
    personalityPreset: "balanced",
    personalityOverrides: {
      directness: 6,
      warmth: 7,
      detail: 6,
    },
    characterConfig: {
      bodyPreset: "balanced",
      facePreset: "warm",
      height: 0.5,
      build: 0.5,
      skinTone: "#b98f68",
      eyeColor: "#d9b45f",
      hairStyle: "short",
      hairColor: "#1d1710",
      clothingPreset: "minimal",
      accessoryIds: [],
      environmentPreset: "dark-studio",
      accentColor: "#d9b45f",
      quality: "medium",
    },
    voiceConfig: {
      presetId: "warm",
      rate: 1,
      pitch: 1,
      enabled: false,
      customVoiceEnabled: false,
    },
    dailyRhythm: {
      wakeTime: "",
      bedtime: "",
      planningTime: "morning",
      focusPeriod: "evening",
      mealsPerDay: "",
      busiestTime: "",
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "local",
    },
    memoryPermissions: defaultMemoryPermissions,
    environmentConfig: {
      roomPreset: "dark-studio",
      lighting: "cinematic",
      reducedMotion: false,
    },
    firstPlan: buildFirstPlan({} as OnboardingProfile),
    firstAction: "Choose one simple nutrition move today.",
    todayConcern: "",
    focusAreas: [],
    customFocusArea: "",
    legacyFocusAreas: [],
    createdAt: now,
    updatedAt: now,
  };
}

export function getStepIndex(step: OnboardingStepId): number {
  const index = onboardingSteps.indexOf(step);
  return index >= 0 ? index : 0;
}

export function getNextStep(step: OnboardingStepId): OnboardingStepId {
  return onboardingSteps[
    Math.min(getStepIndex(step) + 1, onboardingSteps.length - 1)
  ];
}

export function getPreviousStep(step: OnboardingStepId): OnboardingStepId {
  return onboardingSteps[Math.max(getStepIndex(step) - 1, 0)];
}

export function updateOnboardingProfile(
  profile: OnboardingProfile,
  patch: Partial<OnboardingProfile>,
  now = new Date().toISOString(),
): OnboardingProfile {
  return { ...profile, ...patch, updatedAt: now };
}

export function selectPersonality(
  profile: OnboardingProfile,
  presetId: PersonalityPresetId,
  now = new Date().toISOString(),
): OnboardingProfile {
  const preset =
    personalityPresets.find((item) => item.id === presetId) ??
    personalityPresets[0];
  return {
    ...profile,
    personalityPreset: preset.id,
    personalityOverrides: {
      directness: preset.config.directness,
      warmth: preset.config.warmth,
      detail: preset.config.detail,
    },
    voiceConfig: {
      ...profile.voiceConfig,
      presetId: preset.config.voiceStyle,
    },
    updatedAt: now,
  };
}

export function selectNutritionGoal(
  profile: OnboardingProfile,
  nutritionGoal: NutritionGoalId,
  now = new Date().toISOString(),
): OnboardingProfile {
  return { ...profile, nutritionGoal, updatedAt: now };
}

export function selectEatingStyle(
  profile: OnboardingProfile,
  eatingStyle: EatingStyleId,
  now = new Date().toISOString(),
): OnboardingProfile {
  return { ...profile, eatingStyle, updatedAt: now };
}

export function selectTrackingPreference(
  profile: OnboardingProfile,
  trackingPreference: TrackingPreferenceId,
  now = new Date().toISOString(),
): OnboardingProfile {
  return { ...profile, trackingPreference, updatedAt: now };
}

export function toggleChallenge(
  profile: OnboardingProfile,
  challenge: ChallengeId,
  now = new Date().toISOString(),
): OnboardingProfile {
  const exists = profile.challenges.includes(challenge);
  const challenges = exists
    ? profile.challenges.filter((item) => item !== challenge)
    : [...profile.challenges, challenge];
  return { ...profile, challenges, updatedAt: now };
}

export function toggleMemoryPermission(
  profile: OnboardingProfile,
  permission: MemoryPermissionId,
  now = new Date().toISOString(),
): OnboardingProfile {
  return {
    ...profile,
    memoryPermissions: {
      ...profile.memoryPermissions,
      [permission]: !profile.memoryPermissions[permission],
    },
    updatedAt: now,
  };
}

function goalLabel(profile: OnboardingProfile): string {
  return (
    nutritionGoalOptions.find((goal) => goal.id === profile.nutritionGoal)
      ?.label || "eat more consistently"
  );
}

function styleLabel(profile: OnboardingProfile): string {
  return (
    eatingStyleOptions.find((style) => style.id === profile.eatingStyle)
      ?.label || "simple"
  );
}

export function buildFirstPlan(profile: Partial<OnboardingProfile>): {
  mission: string;
  recommendedAction: string;
  estimatedTime: string;
  reason: string;
  safetyNote: string;
} {
  const complete = profile as OnboardingProfile;
  const goal = complete.nutritionGoal ? goalLabel(complete) : "eat consistently";
  const style = complete.eatingStyle ? styleLabel(complete) : "simple";
  const challenge = complete.challenges?.[0]
    ? challengeOptions.find((item) => item.id === complete.challenges[0])?.label
    : "";
  const action = challenge
    ? `Plan one ${style.toLowerCase()} meal that reduces ${challenge.toLowerCase()}.`
    : `Plan one ${style.toLowerCase()} meal that supports ${goal.toLowerCase()}.`;

  return {
    mission: `Build one nutrition win toward ${goal.toLowerCase()}.`,
    recommendedAction: action,
    estimatedTime:
      complete.trackingPreference === "detailed" ? "15 minutes" : "8 minutes",
    reason:
      "Atlas starts with one meal decision because consistency is easier to build than a perfect food system.",
    safetyNote:
      "Atlas provides general wellness guidance only. It does not diagnose, treat, or replace medical advice.",
  };
}

export function completeOnboardingProfile(
  profile: OnboardingProfile,
  now = new Date().toISOString(),
): OnboardingProfile {
  const firstPlan = buildFirstPlan(profile);
  return {
    ...profile,
    completed: true,
    currentStep: "complete",
    firstPlan,
    firstAction: firstPlan.recommendedAction,
    completedAt: now,
    updatedAt: now,
  };
}

export function sanitizeOnboardingProfile(
  value: unknown,
  now = new Date().toISOString(),
): OnboardingProfile | null {
  if (!value || typeof value !== "object") return null;
  const partial = value as Record<string, unknown>;
  const base = createDefaultOnboardingProfile(now);
  const oldFocusAreas = Array.isArray(partial.focusAreas)
    ? partial.focusAreas.filter((area): area is string => typeof area === "string")
    : [];
  const validNutritionGoals = nutritionGoalOptions.map((goal) => goal.id);
  const validEatingStyles = eatingStyleOptions.map((style) => style.id);
  const validTrackingPreferences = trackingPreferenceOptions.map(
    (tracking) => tracking.id,
  );
  const validActivityLevels: ActivityLevelId[] = [
    "not-sure",
    "low",
    "moderate",
    "active",
    "very-active",
  ];
  const bodyBaseline =
    typeof partial.bodyBaseline === "object" && partial.bodyBaseline
      ? (partial.bodyBaseline as Record<string, unknown>)
      : {};
  const foodPreferences =
    typeof partial.foodPreferences === "object" && partial.foodPreferences
      ? (partial.foodPreferences as Record<string, unknown>)
      : {};
  const dailyRhythm =
    typeof partial.dailyRhythm === "object" && partial.dailyRhythm
      ? (partial.dailyRhythm as Record<string, unknown>)
      : {};
  const memoryPermissions =
    typeof partial.memoryPermissions === "object" && partial.memoryPermissions
      ? (partial.memoryPermissions as Record<string, unknown>)
      : {};

  const profile: OnboardingProfile = {
    ...base,
    completed: Boolean(partial.completed),
    currentStep: validStep(partial.currentStep),
    lastCompletedStep: validStep(partial.lastCompletedStep),
    preferredName: cleanText(partial.preferredName, 40),
    pronouns: cleanText(partial.pronouns, 40) || undefined,
    language: cleanText(partial.language, 12) || "en",
    nutritionGoal: firstValid(
      partial.nutritionGoal,
      validNutritionGoals,
      "",
    ) as NutritionGoalId | "",
    bodyBaseline: {
      age: cleanText(bodyBaseline.age, 8),
      height: cleanText(bodyBaseline.height, 24),
      weight: cleanText(bodyBaseline.weight, 24),
      activityLevel: firstValid(
        bodyBaseline.activityLevel,
        validActivityLevels,
        "not-sure",
      ),
      goalNote: cleanText(bodyBaseline.goalNote, 180),
      comfortableSharingBodyData: Boolean(
        bodyBaseline.comfortableSharingBodyData,
      ),
    },
    eatingStyle: firstValid(partial.eatingStyle, validEatingStyles, "") as
      | EatingStyleId
      | "",
    foodPreferences: {
      likedFoods: cleanText(foodPreferences.likedFoods, 240),
      dislikedFoods: cleanText(foodPreferences.dislikedFoods, 240),
      dietaryNotes: cleanText(foodPreferences.dietaryNotes, 240),
      budgetLevel: firstValid(
        foodPreferences.budgetLevel,
        ["not-sure", "low-cost", "moderate", "flexible"],
        "not-sure",
      ),
      cookingAccess: firstValid(
        foodPreferences.cookingAccess,
        ["not-sure", "limited", "basic", "full-kitchen"],
        "not-sure",
      ),
    },
    challenges: Array.isArray(partial.challenges)
      ? partial.challenges.filter((item): item is ChallengeId =>
          challengeOptions.some((option) => option.id === item),
        )
      : [],
    trackingPreference: firstValid(
      partial.trackingPreference,
      validTrackingPreferences,
      "simple",
    ),
    personalityPreset: personalityPresets.some(
      (preset) => preset.id === partial.personalityPreset,
    )
      ? (partial.personalityPreset as PersonalityPresetId)
      : base.personalityPreset,
    characterConfig: {
      ...base.characterConfig,
      ...(typeof partial.characterConfig === "object"
        ? partial.characterConfig
        : {}),
    },
    voiceConfig: {
      ...base.voiceConfig,
      ...(typeof partial.voiceConfig === "object" ? partial.voiceConfig : {}),
    },
    dailyRhythm: {
      ...base.dailyRhythm,
      wakeTime: cleanText(dailyRhythm.wakeTime, 12),
      bedtime: cleanText(dailyRhythm.bedtime, 12),
      planningTime: cleanText(dailyRhythm.planningTime, 24) || "morning",
      focusPeriod: cleanText(dailyRhythm.focusPeriod, 24) || "evening",
      mealsPerDay: cleanText(dailyRhythm.mealsPerDay, 12),
      busiestTime: cleanText(dailyRhythm.busiestTime, 60),
      timezone: cleanText(dailyRhythm.timezone, 80) || base.dailyRhythm.timezone,
    },
    memoryPermissions: {
      ...base.memoryPermissions,
      ...Object.fromEntries(
        Object.keys(base.memoryPermissions).map((key) => [
          key,
          typeof memoryPermissions[key] === "boolean"
            ? Boolean(memoryPermissions[key])
            : base.memoryPermissions[key as MemoryPermissionId],
        ]),
      ),
    },
    environmentConfig: {
      ...base.environmentConfig,
      ...(typeof partial.environmentConfig === "object"
        ? partial.environmentConfig
        : {}),
    },
    todayConcern: cleanText(partial.todayConcern, 240),
    firstAction: cleanText(partial.firstAction, 240) || base.firstAction,
    focusAreas: [],
    customFocusArea: cleanText(partial.customFocusArea, 80),
    legacyFocusAreas: oldFocusAreas,
    createdAt: cleanText(partial.createdAt, 40) || now,
    updatedAt: cleanText(partial.updatedAt, 40) || now,
    completedAt: cleanText(partial.completedAt, 40) || undefined,
    version: ONBOARDING_PROFILE_VERSION,
  };

  return {
    ...profile,
    firstPlan:
      typeof partial.firstPlan === "object" && partial.firstPlan
        ? { ...buildFirstPlan(profile), ...(partial.firstPlan as object) }
        : buildFirstPlan(profile),
  };
}
