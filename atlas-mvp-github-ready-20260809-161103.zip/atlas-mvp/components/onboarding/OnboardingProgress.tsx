"use client";

import { useEffect, useRef } from "react";
import { onboardingStepMeta, onboardingSteps } from "@/lib/onboarding/options";
import { getStepIndex } from "@/lib/onboarding/profile";
import type {
  OnboardingProfile,
  OnboardingStepId,
} from "@/lib/onboarding/types";

type Props = {
  profile: OnboardingProfile;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStepSelect: (step: OnboardingStepId) => void;
};

function getStepStatus(step: OnboardingStepId, currentStep: OnboardingStepId) {
  const stepIndex = getStepIndex(step);
  const currentIndex = getStepIndex(currentStep);
  const meta = onboardingStepMeta.find((item) => item.id === step);

  if (stepIndex < currentIndex) return "Completed";
  if (stepIndex === currentIndex) return "Current";
  if (meta?.optional) return "Optional";
  return "Not started";
}

export function OnboardingProgress({
  profile,
  open,
  onOpenChange,
  onStepSelect,
}: Props) {
  const currentIndex = getStepIndex(profile.currentStep);
  const currentMeta = onboardingStepMeta[currentIndex] ?? onboardingStepMeta[0];
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") onOpenChange(false);
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      previous?.focus?.();
    };
  }, [onOpenChange, open]);

  return (
    <>
      <div className="progress-rail" aria-label="Onboarding progress">
        <div>
          <span className="progress-count">
            Step {currentIndex + 1} of {onboardingSteps.length}
          </span>
          <strong>{currentMeta.label}</strong>
        </div>
        <div className="progress-dots" aria-hidden="true">
          {onboardingSteps.map((step, index) => (
            <span
              className={
                index < currentIndex
                  ? "complete"
                  : index === currentIndex
                    ? "active"
                    : ""
              }
              key={step}
            />
          ))}
        </div>
        <button type="button" onClick={() => onOpenChange(true)}>
          View steps
        </button>
      </div>

      {open && (
        <div className="progress-sheet-backdrop" role="presentation">
          <section
            aria-label="Onboarding step list"
            aria-modal="true"
            className="progress-sheet"
            role="dialog"
          >
            <header>
              <div>
                <p className="eyebrow">Life Map</p>
                <h2>Setup progress</h2>
              </div>
              <button
                aria-label="Close onboarding step list"
                type="button"
                ref={closeRef}
                onClick={() => onOpenChange(false)}
              >
                Close
              </button>
            </header>
            <div className="progress-list">
              {onboardingStepMeta.map((step, index) => {
                const status = getStepStatus(step.id, profile.currentStep);
                const canVisit = index <= currentIndex;

                return (
                  <button
                    className={status.toLowerCase().replace(" ", "-")}
                    disabled={!canVisit}
                    key={step.id}
                    type="button"
                    onClick={() => {
                      onStepSelect(step.id);
                      onOpenChange(false);
                    }}
                  >
                    <span className="progress-marker" aria-hidden="true" />
                    <span>
                      <strong>{step.label}</strong>
                      <em>
                        {step.category} · {status}
                      </em>
                    </span>
                  </button>
                );
              })}
            </div>
            <p className="progress-note">
              Completed steps can be revisited. Optional steps can be skipped.
            </p>
          </section>
        </div>
      )}
    </>
  );
}
