export function AtlasPrivacy() {
  return (
    <section className="privacy-panel" aria-labelledby="privacy-title">
      <h3 id="privacy-title">Privacy and memory</h3>
      <ul>
        <li>Messages are sent to the AI provider to generate responses.</li>
        <li>
          The API key remains on the server and is never stored in browser code.
        </li>
        <li>Local memory is stored only in this browser for the MVP.</li>
        <li>Persistent cloud memory and accounts are not enabled yet.</li>
        <li>Atlas visual states are interface signals, not real emotions.</li>
      </ul>
    </section>
  );
}
