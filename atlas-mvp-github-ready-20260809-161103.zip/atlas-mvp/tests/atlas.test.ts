﻿import assert from "node:assert/strict";
import test from "node:test";
import { atlasRequestSchema, preferencesSchema } from "../lib/atlas/schemas";
import { truncateHistory, truncateUnicode } from "../lib/atlas/history";
import {
  checkRateLimit,
  resetRateLimitForTests,
} from "../lib/atlas/rate-limit";
import { atlasStorage, defaultPreferences } from "../lib/atlas/storage";
import {
  appendAssistantContent,
  completeAssistantMessage,
  createConversationMessage,
  failAssistantMessage,
  stopStreamingMessages,
} from "../lib/atlas/chat-state";

test("atlas request validation rejects empty and oversized messages", () => {
  const base = {
    conversationId: "test",
    history: [],
    preferences: {
      personality: "calm-strategist",
      coachingStyle: "balanced",
      atlasName: "Atlas",
    },
  };
  assert.equal(
    atlasRequestSchema.safeParse({ ...base, message: "" }).success,
    false,
  );
  assert.equal(
    atlasRequestSchema.safeParse({ ...base, message: "a".repeat(4001) })
      .success,
    false,
  );
  assert.equal(
    atlasRequestSchema.safeParse({ ...base, message: "What should I do next?" })
      .success,
    true,
  );
});

test("history truncation keeps recent messages and limits text safely", () => {
  const long = "abcdef".repeat(900);
  assert.equal(truncateUnicode(long, 3), "abc");

  const history = Array.from({ length: 18 }, (_, index) => ({
    role: index % 2 === 0 ? ("user" as const) : ("assistant" as const),
    content: `message-${index}-${long}`,
  }));
  const result = truncateHistory(history);
  assert.equal(result.truncated, true);
  assert.ok(result.history.length <= 12);
  assert.ok(
    result.history.every((item) => Array.from(item.content).length <= 4000),
  );
  assert.ok(result.history.at(-1)?.content.startsWith("message-17"));
});

test("preference validation accepts known values and rejects unsafe color", () => {
  assert.equal(preferencesSchema.safeParse(defaultPreferences).success, true);
  assert.equal(
    preferencesSchema.safeParse({ ...defaultPreferences, accentColor: "gold" })
      .success,
    false,
  );
  assert.equal(
    preferencesSchema.safeParse({ ...defaultPreferences, form: "dragon" })
      .success,
    false,
  );
});

test("local storage behavior saves, loads, and clears without server data", () => {
  const store = new Map<string, string>();
  const fakeWindow = {
    localStorage: {
      getItem: (key: string) => store.get(key) ?? null,
      setItem: (key: string, value: string) => store.set(key, value),
      removeItem: (key: string) => store.delete(key),
    },
  };
  Object.defineProperty(globalThis, "window", {
    value: fakeWindow,
    configurable: true,
  });

  const session = {
    conversationId: "conversation-1",
    messages: [
      createConversationMessage(
        "user",
        "hello",
        "complete",
        () => "m1",
        () => "2026-01-01T00:00:00.000Z",
      ),
    ],
    preferences: { ...defaultPreferences, name: "Atlas Test" },
  };

  atlasStorage.save(session);
  assert.deepEqual(atlasStorage.load(), session);
  atlasStorage.clear();
  assert.equal(atlasStorage.load(), null);
});

test("rate limit blocks repeated requests and can reset for tests", () => {
  resetRateLimitForTests();
  let latest = checkRateLimit("client-a");
  for (let i = 0; i < 18; i += 1) latest = checkRateLimit("client-a");
  assert.equal(latest.allowed, false);
  resetRateLimitForTests();
  assert.equal(checkRateLimit("client-a").allowed, true);
});

test("chat state transitions handle streaming, stopping, and failures", () => {
  const assistant = createConversationMessage(
    "assistant",
    "",
    "streaming",
    () => "a1",
    () => "2026-01-01T00:00:00.000Z",
  );
  const user = createConversationMessage(
    "user",
    "hello",
    "complete",
    () => "u1",
    () => "2026-01-01T00:00:00.000Z",
  );
  const messages = [user, assistant];

  const streamed = appendAssistantContent(messages, "a1", "partial");
  assert.equal(streamed[1].content, "partial");
  assert.equal(streamed[1].status, "streaming");

  const completed = completeAssistantMessage(streamed, "a1", "final answer");
  assert.equal(completed[1].content, "final answer");
  assert.equal(completed[1].status, "complete");

  const stopped = stopStreamingMessages([assistant]);
  assert.equal(stopped[0].status, "complete");

  const failed = failAssistantMessage([assistant], "a1", "failed request");
  assert.equal(failed[0].status, "error");
  assert.equal(failed[0].content, "failed request");
});

test("atlas request validation accepts read-only LifeOps context and rejects malformed bridge data", () => {
  const base = {
    conversationId: "test-context",
    message: "What deserves my attention?",
    history: [],
    preferences: {
      personality: "calm-strategist",
      coachingStyle: "balanced",
      atlasName: "Atlas",
    },
  };

  const context = {
    version: 1,
    generatedAt: "2026-08-04T10:00:00.000Z",
    source: "lifeops-local-bridge",
    profileName: "Dallas",
    currentPriority: "Protect cash and review upcoming bills",
    todayPlan: [
      {
        label: "Task",
        value: "Review rent payment",
        source: "Tasks",
        freshness: "today",
        privacy: "Personal",
      },
    ],
    bills: [],
    goals: [],
    habits: [],
    health: [],
    calendar: [],
    command: {
      priority: "Financial stability",
      recommendedAction: "Confirm the next payment plan",
      reason: "Upcoming obligations are the clearest pressure point.",
      evidence: ["Rent is due soon"],
      estimatedTime: "5 minutes",
      riskIfIgnored: "High",
    },
    limits: {
      readOnly: true,
      exactSensitiveAmountsRemoved: true,
      generatedLocally: true,
    },
  };

  assert.equal(
    atlasRequestSchema.safeParse({ ...base, lifeOpsContext: context }).success,
    true,
  );
  assert.equal(
    atlasRequestSchema.safeParse({
      ...base,
      lifeOpsContext: { ...context, source: "unknown" },
    }).success,
    false,
  );
});
