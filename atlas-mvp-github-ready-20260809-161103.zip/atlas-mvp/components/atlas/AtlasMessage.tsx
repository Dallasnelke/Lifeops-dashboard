import type { ConversationMessage } from "@/lib/atlas/types";

export function AtlasMessage({ message }: { message: ConversationMessage }) {
  return (
    <article
      className={`message ${message.role} ${message.status || "complete"}`}
    >
      <div className="message-meta">
        <span>{message.role === "user" ? "You" : "Atlas"}</span>
        {message.status === "streaming" && <span>streaming</span>}
        {message.status === "error" && <span>error</span>}
      </div>
      <p>
        {message.content ||
          (message.status === "streaming" ? "Thinking..." : "")}
      </p>
    </article>
  );
}
