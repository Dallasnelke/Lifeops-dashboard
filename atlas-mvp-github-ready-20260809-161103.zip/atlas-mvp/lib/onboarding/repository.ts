import {
  createDefaultOnboardingProfile,
  ONBOARDING_PROFILE_STORAGE_KEY,
  sanitizeOnboardingProfile,
} from "./profile";
import type { OnboardingProfile, OnboardingRepository } from "./types";

function canUseStorage(): boolean {
  try {
    return typeof window !== "undefined" && Boolean(window.localStorage);
  } catch {
    return false;
  }
}

export const localOnboardingRepository: OnboardingRepository = {
  load(): OnboardingProfile | null {
    if (!canUseStorage()) return null;
    try {
      const raw = window.localStorage.getItem(ONBOARDING_PROFILE_STORAGE_KEY);
      if (!raw) return null;
      return sanitizeOnboardingProfile(JSON.parse(raw));
    } catch {
      return null;
    }
  },
  save(profile: OnboardingProfile): boolean {
    if (!canUseStorage()) return false;
    try {
      window.localStorage.setItem(
        ONBOARDING_PROFILE_STORAGE_KEY,
        JSON.stringify(profile),
      );
      return true;
    } catch {
      return false;
    }
  },
  clear(): void {
    if (!canUseStorage()) return;
    window.localStorage.removeItem(ONBOARDING_PROFILE_STORAGE_KEY);
  },
  key: ONBOARDING_PROFILE_STORAGE_KEY,
};

export function loadOrCreateOnboardingProfile(
  repository: OnboardingRepository = localOnboardingRepository,
): OnboardingProfile {
  return repository.load() ?? createDefaultOnboardingProfile();
}
