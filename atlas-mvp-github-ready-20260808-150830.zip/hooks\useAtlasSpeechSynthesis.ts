"use client";

import { useCallback, useEffect, useRef } from "react";

export function useAtlasSpeechSynthesis(
  enabled: boolean,
  onSpeakingChange: (speaking: boolean) => void,
) {
  const lastSpokenRef = useRef("");
  const supported =
    typeof window !== "undefined" && "speechSynthesis" in window;

  const stopSpeaking = useCallback(() => {
    if (!supported) return;
    window.speechSynthesis.cancel();
    onSpeakingChange(false);
  }, [onSpeakingChange, supported]);

  const speak = useCallback(
    (text: string) => {
      if (
        !enabled ||
        !supported ||
        !text.trim() ||
        lastSpokenRef.current === text
      )
        return;
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 0.95;
      utterance.onstart = () => onSpeakingChange(true);
      utterance.onend = () => onSpeakingChange(false);
      utterance.onerror = () => onSpeakingChange(false);
      lastSpokenRef.current = text;
      window.speechSynthesis.speak(utterance);
    },
    [enabled, onSpeakingChange, supported],
  );

  useEffect(() => () => stopSpeaking(), [stopSpeaking]);

  return { supported, speak, stopSpeaking };
}
