import type { ReactNode } from "react";
import { onboardingCopy } from "@/lib/onboarding/content";
import type { OnboardingStepId } from "@/lib/onboarding/types";

export function OnboardingStepLayout({
  step,
  children,
}: {
  step: OnboardingStepId;
  children: ReactNode;
}) {
  const copy = onboardingCopy[step];
  return (
    <div className="setup-screen">
      <p className="eyebrow">{copy.eyebrow}</p>
      <h1>{copy.title}</h1>
      <p className="setup-helper">{copy.helper}</p>
      {children}
    </div>
  );
}
