import type { AtlasPreferences } from "@/lib/atlas/types";

const forms = [
  ["orb", "Atlas orb", "Complete MVP visual"],
  ["emblem", "Minimal emblem", "Complete MVP visual"],
  ["humanoid", "Humanoid assistant", "Coming later"],
  ["pet", "Pet companion", "Coming later"],
  ["spirit", "Tree or spirit", "Coming later"],
  ["robot", "Robot guide", "Coming later"],
] as const;

const personalities = [
  ["calm-strategist", "Calm strategist"],
  ["warm-coach", "Warm coach"],
  ["direct-adviser", "Direct adviser"],
  ["curious-collaborator", "Curious collaborator"],
] as const;

const coachingStyles = [
  ["concise", "Concise"],
  ["balanced", "Balanced"],
  ["reflective", "Reflective"],
  ["step-by-step", "Step-by-step"],
] as const;

export function AtlasCharacterStudio({
  preferences,
  onChange,
}: {
  preferences: AtlasPreferences;
  onChange: (next: AtlasPreferences) => void;
}) {
  return (
    <section className="settings-section" aria-labelledby="character-title">
      <h3 id="character-title">Character Studio</h3>
      <label>
        Atlas name
        <input
          value={preferences.name}
          maxLength={32}
          onChange={(event) =>
            onChange({ ...preferences, name: event.target.value || "Atlas" })
          }
        />
      </label>
      <label>
        Accent color
        <input
          type="color"
          value={preferences.accentColor}
          onChange={(event) =>
            onChange({ ...preferences, accentColor: event.target.value })
          }
        />
      </label>
      <div className="studio-grid" role="radiogroup" aria-label="Atlas form">
        {forms.map(([value, label, note]) => (
          <button
            key={value}
            type="button"
            className={preferences.form === value ? "selected" : ""}
            onClick={() => onChange({ ...preferences, form: value })}
          >
            <strong>{label}</strong>
            <span>{note}</span>
          </button>
        ))}
      </div>
      <label>
        Personality
        <select
          value={preferences.personality}
          onChange={(event) =>
            onChange({
              ...preferences,
              personality: event.target
                .value as AtlasPreferences["personality"],
            })
          }
        >
          {personalities.map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </select>
      </label>
      <label>
        Coaching style
        <select
          value={preferences.coachingStyle}
          onChange={(event) =>
            onChange({
              ...preferences,
              coachingStyle: event.target
                .value as AtlasPreferences["coachingStyle"],
            })
          }
        >
          {coachingStyles.map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </select>
      </label>
    </section>
  );
}
