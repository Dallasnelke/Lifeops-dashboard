import type {
  AtlasAppearancePreset,
  AtlasPreferences,
  AtlasVisualIntensity,
} from "./types";

export type AtlasMaterialId = "obsidian" | "graphite" | "gold" | "ivory";
export type AtlasEnvironmentPreset = "void" | "halo-floor" | "deep-orbit";

export type AtlasAvatarConfig = {
  bodyBuild: "slender" | "balanced" | "ethereal";
  bodyPresentation: "humanoid";
  headShape: "smooth-mask" | "sentinel-mask" | "narrow-orbital";
  shoulderWidth: number;
  torsoWidth: number;
  waistWidth: number;
  armLength: number;
  legLength: number;
  skinMaterial: AtlasMaterialId;
  primaryMaterial: AtlasMaterialId;
  secondaryMaterial: AtlasMaterialId;
  accentColor: string;
  coreColor: string;
  coreIntensity: number;
  eyeStyle: "single-sensor" | "dual-pin" | "thin-visor";
  eyeColor: string;
  facialDetail: "none" | "minimal-line" | "central-ridge";
  energySeamIntensity: number;
  glowIntensity: number;
  orbitIntensity: number;
  particleIntensity: number;
  environmentPreset: AtlasEnvironmentPreset;
  lighting: {
    keyLight: number;
    rimLight: number;
    bounceLight: number;
    shadowDepth: number;
  };
  futureMapping: {
    morphTargets: string[];
    materials: string[];
    meshSwaps: string[];
    boneScaling: string[];
    attachments: string[];
    animationStates: string[];
  };
};

export const atlasAppearancePresets: Record<
  AtlasAppearancePreset,
  Omit<AtlasAvatarConfig, "accentColor" | "coreColor" | "futureMapping">
> = {
  minimal: {
    bodyBuild: "slender",
    bodyPresentation: "humanoid",
    headShape: "smooth-mask",
    shoulderWidth: 0.88,
    torsoWidth: 0.88,
    waistWidth: 0.82,
    armLength: 0.94,
    legLength: 1.02,
    skinMaterial: "obsidian",
    primaryMaterial: "obsidian",
    secondaryMaterial: "graphite",
    coreIntensity: 0.72,
    eyeStyle: "single-sensor",
    eyeColor: "#ffe7a6",
    facialDetail: "minimal-line",
    energySeamIntensity: 0.58,
    glowIntensity: 0.62,
    orbitIntensity: 0.48,
    particleIntensity: 0.36,
    environmentPreset: "void",
    lighting: {
      keyLight: 0.82,
      rimLight: 0.74,
      bounceLight: 0.28,
      shadowDepth: 0.9,
    },
  },
  sentinel: {
    bodyBuild: "balanced",
    bodyPresentation: "humanoid",
    headShape: "sentinel-mask",
    shoulderWidth: 1.08,
    torsoWidth: 1,
    waistWidth: 0.9,
    armLength: 1,
    legLength: 1,
    skinMaterial: "obsidian",
    primaryMaterial: "obsidian",
    secondaryMaterial: "graphite",
    coreIntensity: 1,
    eyeStyle: "dual-pin",
    eyeColor: "#fff0b8",
    facialDetail: "central-ridge",
    energySeamIntensity: 0.82,
    glowIntensity: 0.9,
    orbitIntensity: 0.82,
    particleIntensity: 0.6,
    environmentPreset: "halo-floor",
    lighting: {
      keyLight: 1,
      rimLight: 1,
      bounceLight: 0.38,
      shadowDepth: 0.82,
    },
  },
  ethereal: {
    bodyBuild: "ethereal",
    bodyPresentation: "humanoid",
    headShape: "narrow-orbital",
    shoulderWidth: 0.96,
    torsoWidth: 0.9,
    waistWidth: 0.78,
    armLength: 1.08,
    legLength: 1.1,
    skinMaterial: "obsidian",
    primaryMaterial: "obsidian",
    secondaryMaterial: "ivory",
    coreIntensity: 1.12,
    eyeStyle: "thin-visor",
    eyeColor: "#fff7cf",
    facialDetail: "minimal-line",
    energySeamIntensity: 1,
    glowIntensity: 1.05,
    orbitIntensity: 1,
    particleIntensity: 0.78,
    environmentPreset: "deep-orbit",
    lighting: {
      keyLight: 0.94,
      rimLight: 1.12,
      bounceLight: 0.44,
      shadowDepth: 0.76,
    },
  },
};

export function buildAtlasAvatarConfig(
  preferences: AtlasPreferences,
): AtlasAvatarConfig {
  const preset =
    atlasAppearancePresets[preferences.appearancePreset] ??
    atlasAppearancePresets.sentinel;
  const intensity = getVisualIntensityMultiplier(preferences.visualIntensity);

  return {
    ...preset,
    accentColor: preferences.accentColor,
    coreColor: preferences.accentColor,
    coreIntensity: clamp(preset.coreIntensity * intensity, 0.3, 1.55),
    energySeamIntensity: clamp(
      preset.energySeamIntensity * intensity,
      0.2,
      1.45,
    ),
    glowIntensity: clamp(preset.glowIntensity * intensity, 0.2, 1.5),
    orbitIntensity: clamp(preset.orbitIntensity * intensity, 0.12, 1.55),
    particleIntensity: clamp(preset.particleIntensity * intensity, 0.08, 1.35),
    futureMapping: {
      morphTargets: ["headShape", "facialDetail", "bodyBuild"],
      materials: [
        "skinMaterial",
        "primaryMaterial",
        "secondaryMaterial",
        "accentColor",
        "coreColor",
      ],
      meshSwaps: ["eyeStyle", "headShape", "bodyPresentation"],
      boneScaling: [
        "shoulderWidth",
        "torsoWidth",
        "waistWidth",
        "armLength",
        "legLength",
      ],
      attachments: ["core", "energySeams", "orbitSystem", "floorContact"],
      animationStates: [
        "idle",
        "listening",
        "thinking",
        "speaking",
        "success",
        "attention",
      ],
    },
  };
}

function getVisualIntensityMultiplier(intensity: AtlasVisualIntensity) {
  if (intensity === "minimal") return 0.72;
  if (intensity === "radiant") return 1.22;
  return 1;
}

function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}
