﻿"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type {
  AtlasPreferences,
  AtlasState,
  ConversationMessage,
  LifeOpsContext,
} from "@/lib/atlas/types";
import { atlasStorage, defaultPreferences } from "@/lib/atlas/storage";
import {
  appendAssistantContent,
  completeAssistantMessage,
  createConversationMessage,
  failAssistantMessage,
  stopStreamingMessages,
} from "@/lib/atlas/chat-state";

export function useAtlasChat(lifeOpsContext?: LifeOpsContext | null) {
  const [initialSession] = useState(() => atlasStorage.load());
  const [conversationId, setConversationId] = useState(
    () => initialSession?.conversationId ?? crypto.randomUUID(),
  );
  const [messages, setMessages] = useState<ConversationMessage[]>(
    () => initialSession?.messages ?? [],
  );
  const [preferences, setPreferences] = useState<AtlasPreferences>(
    () => initialSession?.preferences ?? defaultPreferences,
  );
  const [atlasState, setAtlasState] = useState<AtlasState>("idle");
  const [error, setError] = useState("");
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (preferences.localMemoryEnabled)
      atlasStorage.save({ conversationId, messages, preferences });
  }, [conversationId, messages, preferences]);

  const clearConversation = useCallback(() => {
    setMessages([]);
    setConversationId(crypto.randomUUID());
    atlasStorage.clear();
  }, []);

  const deleteAllLocalData = useCallback(() => {
    atlasStorage.clear();
    setMessages([]);
    setPreferences(defaultPreferences);
    setConversationId(crypto.randomUUID());
  }, []);

  const stopGeneration = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    setAtlasState("idle");
    setMessages((current) => stopStreamingMessages(current));
  }, []);

  const sendMessage = useCallback(
    async (rawMessage: string) => {
      const message = rawMessage.trim();
      if (!message || atlasState === "thinking") return;

      setError("");
      window.speechSynthesis?.cancel?.();
      const userMessage = createConversationMessage("user", message);
      const assistantMessage = createConversationMessage(
        "assistant",
        "",
        "streaming",
      );
      setMessages((current) => [...current, userMessage, assistantMessage]);
      setAtlasState("thinking");

      const controller = new AbortController();
      abortRef.current = controller;

      try {
        const response = await fetch("/api/atlas", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            conversationId,
            message,
            history: messages
              .slice(-12)
              .map(({ role, content }) => ({ role, content })),
            preferences: {
              personality: preferences.personality,
              coachingStyle: preferences.coachingStyle,
              atlasName: preferences.name,
            },
            lifeOpsContext: lifeOpsContext || undefined,
          }),
          signal: controller.signal,
        });

        if (!response.ok || !response.body) {
          const payload = await response
            .json()
            .catch(() => ({ error: "Atlas could not respond." }));
          throw new Error(payload.error || "Atlas could not respond.");
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let content = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          content += decoder.decode(value, { stream: true });
          setMessages((current) =>
            appendAssistantContent(current, assistantMessage.id, content),
          );
        }
        setMessages((current) =>
          completeAssistantMessage(current, assistantMessage.id, content),
        );
        setAtlasState(preferences.speechEnabled ? "speaking" : "idle");
      } catch (err) {
        const stopped =
          err instanceof DOMException && err.name === "AbortError";
        const messageText = stopped
          ? "Atlas stopped generating."
          : err instanceof Error
            ? err.message
            : "Atlas could not respond.";
        setError(messageText);
        setAtlasState(stopped ? "idle" : "error");
        setMessages((current) =>
          stopped
            ? completeAssistantMessage(
                current,
                assistantMessage.id,
                messageText,
                messageText,
              )
            : failAssistantMessage(current, assistantMessage.id, messageText),
        );
      } finally {
        abortRef.current = null;
      }
    },
    [atlasState, conversationId, lifeOpsContext, messages, preferences],
  );

  return {
    conversationId,
    messages,
    preferences,
    setPreferences,
    atlasState,
    setAtlasState,
    error,
    sendMessage,
    stopGeneration,
    clearConversation,
    deleteAllLocalData,
  };
}
