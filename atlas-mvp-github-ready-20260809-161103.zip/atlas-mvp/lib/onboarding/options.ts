import type {
  ActivityLevelId,
  ChallengeId,
  CharacterClothingPreset,
  CharacterEnvironmentPreset,
  EatingStyleId,
  MemoryPermissionId,
  NutritionGoalId,
  OnboardingStepMeta,
  PersonalityPresetId,
  TrackingPreferenceId,
  VoicePresetId,
} from "./types";

export type PersonalityPreset = {
  id: PersonalityPresetId;
  name: string;
  description: string;
  tonePreview: string;
  sampleResponse: string;
  config: {
    directness: number;
    warmth: number;
    detail: number;
    voiceStyle: VoicePresetId;
    animationStyle: "calm" | "precise" | "warm" | "focused";
  };
};

export const onboardingStepMeta: OnboardingStepMeta[] = [
  { id: "meet-atlas", label: "Meet Atlas", category: "Start" },
  { id: "identity", label: "Identity", category: "Profile" },
  { id: "nutrition-goal", label: "Goal", category: "Nutrition" },
  {
    id: "body-baseline",
    label: "Baseline",
    category: "Nutrition",
    optional: true,
  },
  { id: "eating-style", label: "Eating Style", category: "Nutrition" },
  {
    id: "food-preferences",
    label: "Preferences",
    category: "Nutrition",
    optional: true,
  },
  {
    id: "daily-rhythm",
    label: "Rhythm",
    category: "Nutrition",
    optional: true,
  },
  { id: "challenges", label: "Challenges", category: "Nutrition" },
  { id: "tracking", label: "Tracking", category: "Nutrition" },
  { id: "personality", label: "Personality", category: "Atlas" },
  { id: "character", label: "Appearance", category: "Atlas", optional: true },
  { id: "voice", label: "Voice", category: "Atlas", optional: true },
  { id: "memory", label: "Memory", category: "Privacy" },
  { id: "review", label: "Review", category: "Plan" },
  { id: "first-plan", label: "First Plan", category: "Plan" },
  { id: "complete", label: "Complete", category: "Plan" },
] as const;

export const onboardingSteps = onboardingStepMeta.map((step) => step.id);

export const nutritionGoalOptions: Array<{
  id: NutritionGoalId;
  label: string;
  description: string;
}> = [
  {
    id: "lose-fat",
    label: "Lose body fat",
    description: "Build meals that support a steady calorie deficit.",
  },
  {
    id: "build-muscle",
    label: "Build muscle",
    description: "Prioritize protein, consistency, and training support.",
  },
  {
    id: "maintain",
    label: "Maintain",
    description: "Keep weight stable while improving food quality.",
  },
  {
    id: "body-recomposition",
    label: "Recomposition",
    description: "Support fat loss and strength with balanced meals.",
  },
  {
    id: "more-energy",
    label: "More energy",
    description: "Reduce crashes with steadier meals and hydration.",
  },
  {
    id: "eat-consistently",
    label: "Eat consistently",
    description: "Create a simple food rhythm that fits real life.",
  },
];

export const eatingStyleOptions: Array<{
  id: EatingStyleId;
  label: string;
  description: string;
}> = [
  {
    id: "balanced",
    label: "Balanced",
    description: "A practical mix of protein, carbs, fats, and flexibility.",
  },
  {
    id: "high-protein",
    label: "High protein",
    description: "Keep protein visible without overcomplicating the day.",
  },
  {
    id: "plant-forward",
    label: "Plant forward",
    description: "Build around produce, grains, legumes, and simple protein.",
  },
  {
    id: "budget-focused",
    label: "Budget focused",
    description: "Keep meals realistic, affordable, and repeatable.",
  },
  {
    id: "simple-prep",
    label: "Simple prep",
    description: "Use fast staples and repeat meals to lower friction.",
  },
  {
    id: "flexible",
    label: "Flexible",
    description: "Start with broad structure and adjust over time.",
  },
];

export const activityLevelOptions: Array<{ id: ActivityLevelId; label: string }> =
  [
    { id: "not-sure", label: "Not sure yet" },
    { id: "low", label: "Mostly sitting" },
    { id: "moderate", label: "Some movement" },
    { id: "active", label: "Active most days" },
    { id: "very-active", label: "Very active" },
  ];

export const trackingPreferenceOptions: Array<{
  id: TrackingPreferenceId;
  label: string;
  description: string;
}> = [
  {
    id: "simple",
    label: "Simple",
    description: "Use check-ins and broad meal notes.",
  },
  {
    id: "macro-aware",
    label: "Macro aware",
    description: "Track calories, protein, and rough macros when useful.",
  },
  {
    id: "detailed",
    label: "Detailed",
    description: "Track meals closely with numbers and summaries.",
  },
  {
    id: "photo-notes",
    label: "Photo notes",
    description: "Use pictures and short notes before detailed logging exists.",
  },
];

export const challengeOptions: Array<{ id: ChallengeId; label: string }> = [
  { id: "skipping-meals", label: "Skipping meals" },
  { id: "late-night-snacking", label: "Late-night snacking" },
  { id: "eating-out", label: "Eating out often" },
  { id: "low-protein", label: "Low protein" },
  { id: "low-energy", label: "Low energy" },
  { id: "meal-prep", label: "Meal prep is hard" },
  { id: "budget-pressure", label: "Food budget pressure" },
  { id: "inconsistent-routine", label: "Inconsistent routine" },
  { id: "stress-eating", label: "Stress eating" },
  { id: "weekend-drift", label: "Weekends drift" },
];

export const personalityPresets: PersonalityPreset[] = [
  {
    id: "balanced",
    name: "Balanced",
    description: "Clear guidance with a calm explanation.",
    tonePreview: "Steady, practical, and supportive.",
    sampleResponse: "Here is the meal move I would make first, and why.",
    config: {
      directness: 6,
      warmth: 7,
      detail: 6,
      voiceStyle: "warm",
      animationStyle: "calm",
    },
  },
  {
    id: "coach",
    name: "Coach",
    description: "More energy and accountability without guilt.",
    tonePreview: "Encouraging, focused, action-oriented.",
    sampleResponse: "Start small, finish the food action, then we reassess.",
    config: {
      directness: 8,
      warmth: 7,
      detail: 5,
      voiceStyle: "energetic",
      animationStyle: "focused",
    },
  },
  {
    id: "mentor",
    name: "Mentor",
    description: "Thoughtful guidance that helps you learn as you move.",
    tonePreview: "Patient, reflective, grounded.",
    sampleResponse: "This meal choice matters because it supports the system.",
    config: {
      directness: 5,
      warmth: 8,
      detail: 7,
      voiceStyle: "thoughtful",
      animationStyle: "warm",
    },
  },
  {
    id: "strategist",
    name: "Strategist",
    description: "Prioritizes constraints, tradeoffs, and repeatable wins.",
    tonePreview: "Analytical, concise, high-signal.",
    sampleResponse: "The highest-leverage move is the easiest meal to repeat.",
    config: {
      directness: 7,
      warmth: 5,
      detail: 8,
      voiceStyle: "professional",
      animationStyle: "precise",
    },
  },
  {
    id: "friend",
    name: "Friend",
    description: "Warm, plainspoken support for getting unstuck.",
    tonePreview: "Casual, kind, steady.",
    sampleResponse: "Let us make food easier today. One meal is enough.",
    config: {
      directness: 4,
      warmth: 9,
      detail: 5,
      voiceStyle: "warm",
      animationStyle: "warm",
    },
  },
  {
    id: "professor",
    name: "Professor",
    description: "Explains patterns clearly and teaches the reason.",
    tonePreview: "Structured, educational, precise.",
    sampleResponse: "The pattern is simple: reduce friction before precision.",
    config: {
      directness: 6,
      warmth: 5,
      detail: 9,
      voiceStyle: "thoughtful",
      animationStyle: "precise",
    },
  },
  {
    id: "executive-assistant",
    name: "Executive Assistant",
    description: "Organized, brief, and focused on the next decision.",
    tonePreview: "Professional, calm, efficient.",
    sampleResponse: "Priority one is ready. I would handle this meal first.",
    config: {
      directness: 8,
      warmth: 4,
      detail: 5,
      voiceStyle: "professional",
      animationStyle: "focused",
    },
  },
  {
    id: "calm-guide",
    name: "Calm Guide",
    description: "Low-pressure guidance for clarity and stability.",
    tonePreview: "Soft, clear, nonjudgmental.",
    sampleResponse: "One food choice is enough for now. Start there.",
    config: {
      directness: 4,
      warmth: 9,
      detail: 6,
      voiceStyle: "calm",
      animationStyle: "calm",
    },
  },
  {
    id: "disciplined",
    name: "Disciplined",
    description: "Direct structure for users who want more execution.",
    tonePreview: "Firm, respectful, concise.",
    sampleResponse: "Pick the meal, make it simple, and finish.",
    config: {
      directness: 9,
      warmth: 4,
      detail: 4,
      voiceStyle: "direct",
      animationStyle: "focused",
    },
  },
  {
    id: "direct",
    name: "Direct",
    description: "Plain answers with minimal extra explanation.",
    tonePreview: "Short, clear, decisive.",
    sampleResponse: "Eat this first. It supports the goal with low friction.",
    config: {
      directness: 10,
      warmth: 3,
      detail: 3,
      voiceStyle: "direct",
      animationStyle: "precise",
    },
  },
];

export const characterOptions = {
  clothing: [
    "minimal",
    "casual",
    "business",
    "hoodie",
    "futuristic",
    "academic",
  ] satisfies CharacterClothingPreset[],
  environments: [
    "dark-studio",
    "modern-office",
    "library",
    "creative-workspace",
  ] satisfies CharacterEnvironmentPreset[],
  accents: ["#d9b45f", "#f4d06f", "#b8d889", "#e0be77"],
};

export const voiceOptions: Array<{
  id: VoicePresetId;
  name: string;
  description: string;
}> = [
  { id: "warm", name: "Warm", description: "Friendly and steady." },
  {
    id: "professional",
    name: "Professional",
    description: "Clear and polished.",
  },
  {
    id: "energetic",
    name: "Energetic",
    description: "Brighter and more active.",
  },
  { id: "calm", name: "Calm", description: "Soft and low-pressure." },
  { id: "direct", name: "Direct", description: "Brief and decisive." },
  {
    id: "thoughtful",
    name: "Thoughtful",
    description: "Reflective and patient.",
  },
];

export const memoryPermissionOptions: Array<{
  id: MemoryPermissionId;
  label: string;
  description: string;
  sensitive?: boolean;
}> = [
  {
    id: "preferences",
    label: "Food preferences",
    description: "Likes, dislikes, cooking access, and budget style.",
  },
  {
    id: "routine-patterns",
    label: "Routine patterns",
    description: "Meal timing and the moments that usually create friction.",
  },
  {
    id: "meal-history",
    label: "Meal history",
    description: "Past meal notes when future logging exists.",
  },
  {
    id: "nutrition-goals",
    label: "Nutrition goals",
    description: "The goal you want Atlas to support.",
  },
  {
    id: "body-baseline",
    label: "Body baseline",
    description: "Optional body data used only with permission.",
    sensitive: true,
  },
  {
    id: "conversation-context",
    label: "Conversation context",
    description: "Recent Atlas conversations for continuity.",
  },
  {
    id: "sensitive-health",
    label: "Sensitive health information",
    description: "Medical or highly personal health context.",
    sensitive: true,
  },
];
