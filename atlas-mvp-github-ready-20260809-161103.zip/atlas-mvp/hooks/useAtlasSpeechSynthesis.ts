"use client";

import { useCallback, useEffect, useRef } from "react";
import type { AtlasVoiceStyle } from "@/lib/atlas/types";

export function useAtlasSpeechSynthesis(
  enabled: boolean,
  voiceStyle: AtlasVoiceStyle,
  onSpeakingChange: (speaking: boolean) => void,
) {
  const lastSpokenRef = useRef("");
  const supported =
    typeof window !== "undefined" && "speechSynthesis" in window;

  const stopSpeaking = useCallback(() => {
    if (!supported) return;
    window.speechSynthesis.cancel();
    onSpeakingChange(false);
  }, [onSpeakingChange, supported]);

  const speak = useCallback(
    (text: string) => {
      if (
        !enabled ||
        !supported ||
        !text.trim() ||
        lastSpokenRef.current === text
      )
        return;
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      const style =
        voiceStyle === "warm"
          ? { rate: 0.92, pitch: 1.02 }
          : voiceStyle === "direct"
            ? { rate: 1.03, pitch: 0.9 }
            : { rate: 0.95, pitch: 0.95 };
      utterance.rate = style.rate;
      utterance.pitch = style.pitch;
      utterance.onstart = () => onSpeakingChange(true);
      utterance.onend = () => onSpeakingChange(false);
      utterance.onerror = () => onSpeakingChange(false);
      lastSpokenRef.current = text;
      window.speechSynthesis.speak(utterance);
    },
    [enabled, onSpeakingChange, supported, voiceStyle],
  );

  useEffect(() => () => stopSpeaking(), [stopSpeaking]);

  return { supported, speak, stopSpeaking };
}
