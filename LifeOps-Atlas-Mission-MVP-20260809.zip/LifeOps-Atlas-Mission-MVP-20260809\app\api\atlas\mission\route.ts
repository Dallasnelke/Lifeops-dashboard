import OpenAI from "openai";
import { NextRequest } from "next/server";
import {
  createLocalMission,
  missionJsonSchema,
  missionRequestSchema,
  missionSchema,
  rescueMission,
} from "@/lib/missions";
import { checkRateLimit } from "@/lib/atlas/rate-limit";

export const runtime = "nodejs";

const REQUEST_TIMEOUT_MS = 24_000;

function clientIdentifier(request: NextRequest): string {
  return (
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    "local-dev"
  );
}

export async function POST(request: NextRequest): Promise<Response> {
  const rate = checkRateLimit(`mission:${clientIdentifier(request)}`);
  if (!rate.allowed)
    return Response.json(
      { error: "Atlas needs a moment before creating another mission." },
      { status: 429 },
    );

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Send a valid Life Scan." }, { status: 400 });
  }

  const parsed = missionRequestSchema.safeParse(body);
  if (!parsed.success)
    return Response.json(
      { error: "Atlas needs a situation, energy level, and available time." },
      { status: 400 },
    );

  const { mode, scan, currentMission, rescueReason } = parsed.data;
  const localMission =
    mode === "rescue" && currentMission
      ? rescueMission(currentMission, rescueReason)
      : createLocalMission(scan);
  const apiKey = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL || "gpt-5.6-terra";

  if (!apiKey) return Response.json({ mission: localMission });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort("timeout"), REQUEST_TIMEOUT_MS);
  request.signal.addEventListener("abort", () => controller.abort("client"), {
    once: true,
  });

  try {
    const client = new OpenAI({ apiKey });
    const response = await client.responses.create(
      {
        model,
        store: false,
        max_output_tokens: 700,
        instructions: `Role: Atlas Mission Planner.

Goal: Turn the user's current reality into one safe, concrete, finishable mission that creates visible progress today.

Success criteria:
- choose one priority rather than a list
- make the first step immediately actionable
- fit the mission inside the available time and reported energy
- explain the decision using only the supplied evidence
- provide a five-minute fallback that preserves momentum

Constraints:
- do not diagnose, treat, shame, or claim certainty about the user
- do not provide medical, legal, investment, trading, gambling, or dangerous instructions
- never invent integrations, calendar events, records, or facts
- if the input suggests a high-stakes issue, choose a safe organizational step and recommend qualified help where appropriate

Output only the required structured mission fields.`,
        input: JSON.stringify({ mode, scan, currentMission, rescueReason }),
        text: {
          format: {
            type: "json_schema",
            name: "atlas_mission",
            strict: true,
            schema: missionJsonSchema,
          },
          verbosity: "low",
        },
      },
      { signal: controller.signal },
    );

    const generated = JSON.parse(response.output_text) as Record<string, unknown>;
    const mission = missionSchema.parse({
      ...generated,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      status: "ready",
      source: "atlas-ai",
      rescueCount:
        mode === "rescue" && currentMission
          ? currentMission.rescueCount + 1
          : 0,
    });
    return Response.json({ mission });
  } catch (error) {
    if (!controller.signal.aborted)
      console.error("Atlas mission route used local fallback", error);
    return Response.json({ mission: localMission, fallback: true });
  } finally {
    clearTimeout(timeout);
  }
}

