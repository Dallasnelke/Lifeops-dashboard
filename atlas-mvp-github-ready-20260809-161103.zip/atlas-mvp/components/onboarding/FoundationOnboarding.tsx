"use client";

import { useState } from "react";
import { CharacterRenderer } from "@/components/atlas-character/CharacterRenderer";
import { onboardingCopy } from "@/lib/onboarding/content";
import {
  activityLevelOptions,
  challengeOptions,
  characterOptions,
  eatingStyleOptions,
  memoryPermissionOptions,
  nutritionGoalOptions,
  onboardingStepMeta,
  personalityPresets,
  trackingPreferenceOptions,
  voiceOptions,
} from "@/lib/onboarding/options";
import {
  buildFirstPlan,
  completeOnboardingProfile,
  getNextStep,
  getPreviousStep,
  selectEatingStyle,
  selectNutritionGoal,
  selectPersonality,
  selectTrackingPreference,
  toggleChallenge,
  toggleMemoryPermission,
  updateOnboardingProfile,
} from "@/lib/onboarding/profile";
import type {
  ActivityLevelId,
  CharacterClothingPreset,
  CharacterEnvironmentPreset,
  EatingStyleId,
  NutritionGoalId,
  OnboardingProfile,
  TrackingPreferenceId,
  VoicePresetId,
} from "@/lib/onboarding/types";
import { OnboardingNavigation } from "./OnboardingNavigation";
import { OnboardingProgress } from "./OnboardingProgress";
import { OnboardingStepLayout } from "./OnboardingStepLayout";

type Props = {
  profile: OnboardingProfile;
  onChange: (profile: OnboardingProfile) => void;
  onComplete: (profile: OnboardingProfile) => void;
  onSkip: () => void;
};

type Option = {
  id: string;
  label: string;
  description?: string;
};

function isOptionalStep(stepId: OnboardingProfile["currentStep"]) {
  return Boolean(onboardingStepMeta.find((step) => step.id === stepId)?.optional);
}

function optionGrid<T extends Option>({
  options,
  selected,
  onSelect,
}: {
  options: T[];
  selected: string | string[];
  onSelect: (id: T["id"]) => void;
}) {
  return (
    <div className="choice-grid">
      {options.map((option) => {
        const isSelected = Array.isArray(selected)
          ? selected.includes(option.id)
          : selected === option.id;
        return (
          <button
            className={isSelected ? "selected" : ""}
            key={option.id}
            type="button"
            onClick={() => onSelect(option.id)}
          >
            <strong>{option.label}</strong>
            {option.description && <span>{option.description}</span>}
          </button>
        );
      })}
    </div>
  );
}

export function FoundationOnboarding({
  profile,
  onChange,
  onComplete,
  onSkip,
}: Props) {
  const [progressOpen, setProgressOpen] = useState(false);

  function patch(patchValue: Partial<OnboardingProfile>) {
    onChange(updateOnboardingProfile(profile, patchValue));
  }

  function moveTo(step: OnboardingProfile["currentStep"]) {
    onChange(updateOnboardingProfile(profile, { currentStep: step }));
  }

  function goNext() {
    if (profile.currentStep === "complete") {
      onComplete(completeOnboardingProfile(profile));
      return;
    }
    if (profile.currentStep === "first-plan") {
      moveTo("complete");
      return;
    }
    moveTo(getNextStep(profile.currentStep));
  }

  function goBack() {
    moveTo(getPreviousStep(profile.currentStep));
  }

  function skipCurrent() {
    if (profile.currentStep === "meet-atlas") {
      onSkip();
      return;
    }
    if (isOptionalStep(profile.currentStep)) {
      goNext();
      return;
    }
    goNext();
  }

  function setCharacterConfig(
    configPatch: Partial<OnboardingProfile["characterConfig"]>,
  ) {
    patch({
      characterConfig: { ...profile.characterConfig, ...configPatch },
    });
  }

  function setVoice(presetId: VoicePresetId) {
    patch({
      voiceConfig: { ...profile.voiceConfig, presetId },
    });
  }

  function renderNavigation(nextLabel = "Continue", nextDisabled = false) {
    return (
      <OnboardingNavigation
        currentStep={profile.currentStep}
        onBack={goBack}
        onNext={goNext}
        onSkip={skipCurrent}
        nextLabel={nextLabel}
        nextDisabled={nextDisabled}
      />
    );
  }

  function renderStep() {
    switch (profile.currentStep) {
      case "meet-atlas":
        return (
          <OnboardingStepLayout step="meet-atlas">
            <article className="mission-preview compact">
              <strong>General wellness only</strong>
              <span>
                Atlas helps with food planning and habit clarity. Medical
                decisions still belong with qualified professionals.
              </span>
            </article>
            {renderNavigation("Begin")}
          </OnboardingStepLayout>
        );
      case "identity":
        return (
          <OnboardingStepLayout step="identity">
            <label className="field-label">
              Preferred name
              <input
                autoFocus
                value={profile.preferredName}
                onChange={(event) =>
                  patch({ preferredName: event.target.value.slice(0, 40) })
                }
                placeholder="Dallas"
              />
            </label>
            {renderNavigation()}
          </OnboardingStepLayout>
        );
      case "nutrition-goal":
        return (
          <OnboardingStepLayout step="nutrition-goal">
            {optionGrid({
              options: nutritionGoalOptions,
              selected: profile.nutritionGoal,
              onSelect: (id) =>
                onChange(selectNutritionGoal(profile, id as NutritionGoalId)),
            })}
            {renderNavigation("Continue", !profile.nutritionGoal)}
          </OnboardingStepLayout>
        );
      case "body-baseline":
        return (
          <OnboardingStepLayout step="body-baseline">
            <div className="customizer-grid">
              <label className="field-label">
                Age
                <input
                  inputMode="numeric"
                  value={profile.bodyBaseline.age}
                  onChange={(event) =>
                    patch({
                      bodyBaseline: {
                        ...profile.bodyBaseline,
                        age: event.target.value.replace(/\D/g, "").slice(0, 3),
                      },
                    })
                  }
                  placeholder="Optional"
                />
              </label>
              <label className="field-label">
                Height
                <input
                  value={profile.bodyBaseline.height}
                  onChange={(event) =>
                    patch({
                      bodyBaseline: {
                        ...profile.bodyBaseline,
                        height: event.target.value.slice(0, 24),
                      },
                    })
                  }
                  placeholder="Optional"
                />
              </label>
              <label className="field-label">
                Weight
                <input
                  value={profile.bodyBaseline.weight}
                  onChange={(event) =>
                    patch({
                      bodyBaseline: {
                        ...profile.bodyBaseline,
                        weight: event.target.value.slice(0, 24),
                      },
                    })
                  }
                  placeholder="Optional"
                />
              </label>
              <label className="field-label">
                Activity
                <select
                  value={profile.bodyBaseline.activityLevel}
                  onChange={(event) =>
                    patch({
                      bodyBaseline: {
                        ...profile.bodyBaseline,
                        activityLevel: event.target.value as ActivityLevelId,
                      },
                    })
                  }
                >
                  {activityLevelOptions.map((option) => (
                    <option key={option.id} value={option.id}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <label className="check-row">
              <input
                checked={profile.bodyBaseline.comfortableSharingBodyData}
                type="checkbox"
                onChange={(event) =>
                  patch({
                    bodyBaseline: {
                      ...profile.bodyBaseline,
                      comfortableSharingBodyData: event.target.checked,
                    },
                  })
                }
              />
              I am comfortable saving this optional body baseline locally.
            </label>
            {renderNavigation()}
          </OnboardingStepLayout>
        );
      case "eating-style":
        return (
          <OnboardingStepLayout step="eating-style">
            {optionGrid({
              options: eatingStyleOptions,
              selected: profile.eatingStyle,
              onSelect: (id) =>
                onChange(selectEatingStyle(profile, id as EatingStyleId)),
            })}
            {renderNavigation("Continue", !profile.eatingStyle)}
          </OnboardingStepLayout>
        );
      case "food-preferences":
        return (
          <OnboardingStepLayout step="food-preferences">
            <div className="customizer-grid">
              <label className="field-label">
                Foods you like
                <textarea
                  value={profile.foodPreferences.likedFoods}
                  onChange={(event) =>
                    patch({
                      foodPreferences: {
                        ...profile.foodPreferences,
                        likedFoods: event.target.value.slice(0, 240),
                      },
                    })
                  }
                  placeholder="Chicken, rice bowls, Greek yogurt..."
                />
              </label>
              <label className="field-label">
                Foods or limits to avoid
                <textarea
                  value={profile.foodPreferences.dislikedFoods}
                  onChange={(event) =>
                    patch({
                      foodPreferences: {
                        ...profile.foodPreferences,
                        dislikedFoods: event.target.value.slice(0, 240),
                      },
                    })
                  }
                  placeholder="Optional"
                />
              </label>
              <label className="field-label">
                Budget style
                <select
                  value={profile.foodPreferences.budgetLevel}
                  onChange={(event) =>
                    patch({
                      foodPreferences: {
                        ...profile.foodPreferences,
                        budgetLevel: event.target.value as never,
                      },
                    })
                  }
                >
                  <option value="not-sure">Not sure yet</option>
                  <option value="low-cost">Low cost</option>
                  <option value="moderate">Moderate</option>
                  <option value="flexible">Flexible</option>
                </select>
              </label>
              <label className="field-label">
                Cooking access
                <select
                  value={profile.foodPreferences.cookingAccess}
                  onChange={(event) =>
                    patch({
                      foodPreferences: {
                        ...profile.foodPreferences,
                        cookingAccess: event.target.value as never,
                      },
                    })
                  }
                >
                  <option value="not-sure">Not sure yet</option>
                  <option value="limited">Limited</option>
                  <option value="basic">Basic kitchen</option>
                  <option value="full-kitchen">Full kitchen</option>
                </select>
              </label>
            </div>
            {renderNavigation()}
          </OnboardingStepLayout>
        );
      case "daily-rhythm":
        return (
          <OnboardingStepLayout step="daily-rhythm">
            <div className="customizer-grid">
              <label className="field-label">
                Wake time
                <input
                  type="time"
                  value={profile.dailyRhythm.wakeTime}
                  onChange={(event) =>
                    patch({
                      dailyRhythm: {
                        ...profile.dailyRhythm,
                        wakeTime: event.target.value,
                      },
                    })
                  }
                />
              </label>
              <label className="field-label">
                Meals per day
                <select
                  value={profile.dailyRhythm.mealsPerDay}
                  onChange={(event) =>
                    patch({
                      dailyRhythm: {
                        ...profile.dailyRhythm,
                        mealsPerDay: event.target.value,
                      },
                    })
                  }
                >
                  <option value="">Not sure yet</option>
                  <option value="2">2 meals</option>
                  <option value="3">3 meals</option>
                  <option value="4">4 meals/snacks</option>
                  <option value="flexible">It changes</option>
                </select>
              </label>
              <label className="field-label">
                Planning time
                <select
                  value={profile.dailyRhythm.planningTime}
                  onChange={(event) =>
                    patch({
                      dailyRhythm: {
                        ...profile.dailyRhythm,
                        planningTime: event.target.value,
                      },
                    })
                  }
                >
                  <option value="morning">Morning</option>
                  <option value="afternoon">Afternoon</option>
                  <option value="evening">Evening</option>
                  <option value="not-sure">Not sure yet</option>
                </select>
              </label>
              <label className="field-label">
                Hardest time of day
                <input
                  value={profile.dailyRhythm.busiestTime}
                  onChange={(event) =>
                    patch({
                      dailyRhythm: {
                        ...profile.dailyRhythm,
                        busiestTime: event.target.value.slice(0, 60),
                      },
                    })
                  }
                  placeholder="After work, late night..."
                />
              </label>
            </div>
            {renderNavigation()}
          </OnboardingStepLayout>
        );
      case "challenges":
        return (
          <OnboardingStepLayout step="challenges">
            {optionGrid({
              options: challengeOptions,
              selected: profile.challenges,
              onSelect: (id) => onChange(toggleChallenge(profile, id as never)),
            })}
            {renderNavigation()}
          </OnboardingStepLayout>
        );
      case "tracking":
        return (
          <OnboardingStepLayout step="tracking">
            {optionGrid({
              options: trackingPreferenceOptions,
              selected: profile.trackingPreference,
              onSelect: (id) =>
                onChange(
                  selectTrackingPreference(profile, id as TrackingPreferenceId),
                ),
            })}
            {renderNavigation()}
          </OnboardingStepLayout>
        );
      case "personality":
        return (
          <OnboardingStepLayout step="personality">
            <div className="personality-grid">
              {personalityPresets.map((preset) => (
                <button
                  className={
                    profile.personalityPreset === preset.id ? "selected" : ""
                  }
                  key={preset.id}
                  type="button"
                  onClick={() =>
                    onChange(selectPersonality(profile, preset.id))
                  }
                >
                  <strong>{preset.name}</strong>
                  <span>{preset.description}</span>
                  <em>{preset.sampleResponse}</em>
                </button>
              ))}
            </div>
            {renderNavigation()}
          </OnboardingStepLayout>
        );
      case "character":
        return (
          <OnboardingStepLayout step="character">
            <div className="customizer-grid">
              <label className="field-label">
                Clothing
                <select
                  value={profile.characterConfig.clothingPreset}
                  onChange={(event) =>
                    setCharacterConfig({
                      clothingPreset: event.target
                        .value as CharacterClothingPreset,
                    })
                  }
                >
                  {characterOptions.clothing.map((option) => (
                    <option key={option} value={option}>
                      {option.replace("-", " ")}
                    </option>
                  ))}
                </select>
              </label>
              <label className="field-label">
                Environment
                <select
                  value={profile.characterConfig.environmentPreset}
                  onChange={(event) =>
                    setCharacterConfig({
                      environmentPreset: event.target
                        .value as CharacterEnvironmentPreset,
                    })
                  }
                >
                  {characterOptions.environments.map((option) => (
                    <option key={option} value={option}>
                      {option.replace("-", " ")}
                    </option>
                  ))}
                </select>
              </label>
              <label className="field-label">
                Height
                <input
                  max="1"
                  min="0"
                  step="0.05"
                  type="range"
                  value={profile.characterConfig.height}
                  onChange={(event) =>
                    setCharacterConfig({
                      height: Number(event.target.value),
                    })
                  }
                />
              </label>
              <label className="field-label">
                Build
                <input
                  max="1"
                  min="0"
                  step="0.05"
                  type="range"
                  value={profile.characterConfig.build}
                  onChange={(event) =>
                    setCharacterConfig({ build: Number(event.target.value) })
                  }
                />
              </label>
            </div>
            <div className="swatch-row" aria-label="Accent color">
              {characterOptions.accents.map((accent) => (
                <button
                  aria-label={`Use accent ${accent}`}
                  className={
                    profile.characterConfig.accentColor === accent
                      ? "selected"
                      : ""
                  }
                  key={accent}
                  style={{ background: accent }}
                  type="button"
                  onClick={() => setCharacterConfig({ accentColor: accent })}
                />
              ))}
            </div>
            {renderNavigation()}
          </OnboardingStepLayout>
        );
      case "voice":
        return (
          <OnboardingStepLayout step="voice">
            <div className="guidance-grid">
              {voiceOptions.map((voice) => (
                <button
                  className={
                    profile.voiceConfig.presetId === voice.id ? "selected" : ""
                  }
                  key={voice.id}
                  type="button"
                  onClick={() => setVoice(voice.id)}
                >
                  <strong>{voice.name}</strong>
                  <span>{voice.description}</span>
                </button>
              ))}
            </div>
            <label className="check-row">
              <input
                checked={profile.voiceConfig.enabled}
                type="checkbox"
                onChange={(event) =>
                  patch({
                    voiceConfig: {
                      ...profile.voiceConfig,
                      enabled: event.target.checked,
                    },
                  })
                }
              />
              Enable browser voice when supported
            </label>
            {renderNavigation()}
          </OnboardingStepLayout>
        );
      case "memory":
        return (
          <OnboardingStepLayout step="memory">
            <div className="memory-grid">
              {memoryPermissionOptions.map((permission) => (
                <label className="permission-card" key={permission.id}>
                  <input
                    checked={profile.memoryPermissions[permission.id]}
                    type="checkbox"
                    onChange={() =>
                      onChange(toggleMemoryPermission(profile, permission.id))
                    }
                  />
                  <span>
                    <strong>{permission.label}</strong>
                    {permission.description}
                    {permission.sensitive ? " Sensitive - off by default." : ""}
                  </span>
                </label>
              ))}
            </div>
            {renderNavigation()}
          </OnboardingStepLayout>
        );
      case "review":
        return (
          <OnboardingStepLayout step="review">
            <div className="review-grid">
              <span>
                <strong>Name</strong>
                {profile.preferredName || "Optional"}
              </span>
              <span>
                <strong>Goal</strong>
                {nutritionGoalOptions.find(
                  (goal) => goal.id === profile.nutritionGoal,
                )?.label || "Not set"}
              </span>
              <span>
                <strong>Eating style</strong>
                {eatingStyleOptions.find(
                  (style) => style.id === profile.eatingStyle,
                )?.label || "Not set"}
              </span>
              <span>
                <strong>Tracking</strong>
                {trackingPreferenceOptions.find(
                  (tracking) => tracking.id === profile.trackingPreference,
                )?.label || "Simple"}
              </span>
            </div>
            <label className="field-label">
              What would make eating today feel easier?
              <textarea
                value={profile.todayConcern}
                onChange={(event) =>
                  patch({ todayConcern: event.target.value.slice(0, 240) })
                }
                placeholder="One meal, one obstacle, or one useful move"
              />
            </label>
            {renderNavigation("Prepare first plan")}
          </OnboardingStepLayout>
        );
      case "first-plan": {
        const plan = buildFirstPlan(profile);
        return (
          <OnboardingStepLayout step="first-plan">
            <article className="mission-preview">
              <strong>{plan.mission}</strong>
              <span>{plan.recommendedAction}</span>
              <em>{plan.estimatedTime}</em>
            </article>
            <div className="reason-panel">
              <strong>Why Atlas chose it</strong>
              <p>{plan.reason}</p>
            </div>
            <div className="reason-panel">
              <strong>Safety boundary</strong>
              <p>{plan.safetyNote}</p>
            </div>
            {renderNavigation("Finalize")}
          </OnboardingStepLayout>
        );
      }
      case "complete": {
        const completed = completeOnboardingProfile(profile);
        return (
          <OnboardingStepLayout step="complete">
            <article className="mission-preview">
              <strong>{completed.firstPlan.mission}</strong>
              <span>{completed.firstPlan.recommendedAction}</span>
              <em>{completed.firstPlan.estimatedTime}</em>
            </article>
            <div className="setup-actions">
              <button type="button" onClick={() => moveTo("review")}>
                Review
              </button>
              <button
                className="primary"
                type="button"
                onClick={() => onComplete(completed)}
              >
                Launch Atlas
              </button>
            </div>
          </OnboardingStepLayout>
        );
      }
    }
  }

  const currentCopy = onboardingCopy[profile.currentStep];
  const animationState =
    profile.currentStep === "complete"
      ? "acknowledging"
      : profile.currentStep === "first-plan" || profile.currentStep === "review"
        ? "thinking"
        : profile.currentStep === "voice"
          ? "speaking"
          : "idle";

  return (
    <main className="setup-shell">
      <section className="setup-card cinematic-onboarding" aria-live="polite">
        <aside className="setup-orb atlas-stage" aria-label="Atlas setup">
          <div className="stage-status" aria-hidden="true">
            <span />
            Atlas online
          </div>
          <CharacterRenderer
            animationState={animationState}
            config={profile.characterConfig}
            reducedMotion={profile.environmentConfig.reducedMotion}
          />
          <p className="stage-dialogue">{currentCopy.atlasLine}</p>
        </aside>
        <div className="setup-main">
          <OnboardingProgress
            profile={profile}
            open={progressOpen}
            onOpenChange={setProgressOpen}
            onStepSelect={moveTo}
          />
          {renderStep()}
        </div>
      </section>
    </main>
  );
}
