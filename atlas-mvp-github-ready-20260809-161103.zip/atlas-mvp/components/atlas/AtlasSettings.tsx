import { atlasStorage } from "@/lib/atlas/storage";
import type { AtlasPreferences } from "@/lib/atlas/types";

export function AtlasSettings({
  preferences,
  onChange,
  onClearConversation,
  onDeleteAllLocalData,
}: {
  preferences: AtlasPreferences;
  onChange: (next: AtlasPreferences) => void;
  onClearConversation: () => void;
  onDeleteAllLocalData: () => void;
}) {
  function handleMemoryChange(enabled: boolean) {
    if (
      !enabled &&
      !confirm(
        "Stop remembering this conversation on this device and clear saved Atlas chat data?",
      )
    )
      return;
    if (!enabled) atlasStorage.clear();
    onChange({ ...preferences, localMemoryEnabled: enabled });
  }

  return (
    <section className="settings-section" aria-labelledby="settings-title">
      <h3 id="settings-title">Settings</h3>
      <label className="check-row">
        <input
          type="checkbox"
          checked={preferences.speechEnabled}
          onChange={(event) =>
            onChange({ ...preferences, speechEnabled: event.target.checked })
          }
        />
        Read Atlas replies aloud
      </label>
      <label className="check-row">
        <input
          type="checkbox"
          checked={preferences.localMemoryEnabled}
          onChange={(event) => handleMemoryChange(event.target.checked)}
        />
        Remember this conversation on this device
      </label>
      <div className="danger-row">
        <button type="button" onClick={onClearConversation}>
          Clear conversation
        </button>
        <button
          type="button"
          onClick={() => {
            if (confirm("Delete all local Atlas data from this browser?"))
              onDeleteAllLocalData();
          }}
        >
          Delete all local Atlas data
        </button>
      </div>
    </section>
  );
}
