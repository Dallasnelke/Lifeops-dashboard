export const ONBOARDING_PROFILE_VERSION = 2;

export type OnboardingStepId =
  | "meet-atlas"
  | "identity"
  | "nutrition-goal"
  | "body-baseline"
  | "eating-style"
  | "food-preferences"
  | "daily-rhythm"
  | "challenges"
  | "tracking"
  | "personality"
  | "character"
  | "voice"
  | "memory"
  | "review"
  | "first-plan"
  | "complete";

export type OnboardingStepCategory =
  | "Start"
  | "Profile"
  | "Nutrition"
  | "Atlas"
  | "Privacy"
  | "Plan";

export type OnboardingStepMeta = {
  id: OnboardingStepId;
  label: string;
  category: OnboardingStepCategory;
  optional?: boolean;
};

export type PersonalityPresetId =
  | "balanced"
  | "coach"
  | "mentor"
  | "strategist"
  | "friend"
  | "professor"
  | "executive-assistant"
  | "calm-guide"
  | "disciplined"
  | "direct";

export type CharacterBodyPreset = "balanced" | "compact" | "tall" | "strong";
export type CharacterFacePreset = "soft" | "focused" | "warm" | "sharp";
export type CharacterClothingPreset =
  | "minimal"
  | "casual"
  | "business"
  | "hoodie"
  | "futuristic"
  | "academic";
export type CharacterEnvironmentPreset =
  | "dark-studio"
  | "modern-office"
  | "library"
  | "creative-workspace";
export type AtlasAnimationState =
  | "idle"
  | "listening"
  | "thinking"
  | "speaking"
  | "acknowledging"
  | "focused";
export type VoicePresetId =
  | "warm"
  | "professional"
  | "energetic"
  | "calm"
  | "direct"
  | "thoughtful";

export type NutritionGoalId =
  | "lose-fat"
  | "build-muscle"
  | "maintain"
  | "body-recomposition"
  | "more-energy"
  | "eat-consistently";

export type EatingStyleId =
  | "balanced"
  | "high-protein"
  | "plant-forward"
  | "budget-focused"
  | "simple-prep"
  | "flexible";

export type TrackingPreferenceId =
  | "simple"
  | "macro-aware"
  | "detailed"
  | "photo-notes";

export type ActivityLevelId =
  | "not-sure"
  | "low"
  | "moderate"
  | "active"
  | "very-active";

export type ChallengeId =
  | "skipping-meals"
  | "late-night-snacking"
  | "eating-out"
  | "low-protein"
  | "low-energy"
  | "meal-prep"
  | "budget-pressure"
  | "inconsistent-routine"
  | "stress-eating"
  | "weekend-drift";

export type FocusAreaId =
  | "career"
  | "school"
  | "money"
  | "fitness"
  | "health"
  | "sleep"
  | "relationships"
  | "family"
  | "business"
  | "programming"
  | "creativity"
  | "mental-wellbeing"
  | "organization"
  | "habits"
  | "personal-growth";

export type MemoryPermissionId =
  | "preferences"
  | "routine-patterns"
  | "meal-history"
  | "nutrition-goals"
  | "body-baseline"
  | "conversation-context"
  | "sensitive-health";

export type CharacterConfig = {
  bodyPreset: CharacterBodyPreset;
  facePreset: CharacterFacePreset;
  height: number;
  build: number;
  skinTone: string;
  eyeColor: string;
  hairStyle: string;
  hairColor: string;
  clothingPreset: CharacterClothingPreset;
  accessoryIds: string[];
  environmentPreset: CharacterEnvironmentPreset;
  accentColor: string;
  quality: "low" | "medium" | "high";
};

export type VoiceConfig = {
  presetId: VoicePresetId;
  rate: number;
  pitch: number;
  enabled: boolean;
  customVoiceEnabled: boolean;
};

export type BodyBaseline = {
  age: string;
  height: string;
  weight: string;
  activityLevel: ActivityLevelId;
  goalNote: string;
  comfortableSharingBodyData: boolean;
};

export type FoodPreferences = {
  likedFoods: string;
  dislikedFoods: string;
  dietaryNotes: string;
  budgetLevel: "not-sure" | "low-cost" | "moderate" | "flexible";
  cookingAccess: "not-sure" | "limited" | "basic" | "full-kitchen";
};

export type DailyRhythm = {
  wakeTime: string;
  bedtime: string;
  planningTime: string;
  focusPeriod: string;
  mealsPerDay: string;
  busiestTime: string;
  timezone: string;
};

export type EnvironmentConfig = {
  roomPreset: CharacterEnvironmentPreset;
  lighting: "soft" | "focused" | "cinematic";
  reducedMotion: boolean;
};

export type FirstPlan = {
  mission: string;
  recommendedAction: string;
  estimatedTime: string;
  reason: string;
  safetyNote: string;
};

export type OnboardingProfile = {
  version: typeof ONBOARDING_PROFILE_VERSION;
  completed: boolean;
  currentStep: OnboardingStepId;
  lastCompletedStep?: OnboardingStepId;
  preferredName: string;
  pronouns?: string;
  language?: string;
  nutritionGoal: NutritionGoalId | "";
  bodyBaseline: BodyBaseline;
  eatingStyle: EatingStyleId | "";
  foodPreferences: FoodPreferences;
  challenges: ChallengeId[];
  trackingPreference: TrackingPreferenceId;
  personalityPreset: PersonalityPresetId;
  personalityOverrides: {
    directness: number;
    warmth: number;
    detail: number;
  };
  characterConfig: CharacterConfig;
  voiceConfig: VoiceConfig;
  dailyRhythm: DailyRhythm;
  memoryPermissions: Record<MemoryPermissionId, boolean>;
  environmentConfig: EnvironmentConfig;
  firstPlan: FirstPlan;
  firstAction: string;
  todayConcern: string;
  focusAreas: FocusAreaId[];
  customFocusArea: string;
  legacyFocusAreas?: string[];
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
};

export type OnboardingRepository = {
  load(): OnboardingProfile | null;
  save(profile: OnboardingProfile): boolean;
  clear(): void;
  key: string;
};
