import type { CSSProperties } from "react";
import type { AtlasState, AtlasPreferences } from "@/lib/atlas/types";

type Props = {
  state: AtlasState;
  preferences: AtlasPreferences;
  onClick?: () => void;
  label?: string;
  compact?: boolean;
};

export function AtlasOrb({
  state,
  preferences,
  onClick,
  label = "Open Atlas",
  compact = false,
}: Props) {
  const formClass = preferences.form === "emblem" ? "emblem" : "orb";
  return (
    <button
      className={`atlas-orb ${formClass} ${state} ${compact ? "compact" : ""}`}
      onClick={onClick}
      type="button"
      aria-label={label}
      style={{ "--atlas-accent": preferences.accentColor } as CSSProperties}
    >
      <span className="orb-halo" aria-hidden="true" />
      <span className="orb-core" aria-hidden="true">
        <span className="orb-mark">A</span>
      </span>
      <span className="orb-ring ring-one" aria-hidden="true" />
      <span className="orb-ring ring-two" aria-hidden="true" />
      <span className="orb-state-label">{state}</span>
    </button>
  );
}
