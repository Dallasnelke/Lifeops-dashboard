import type { AtlasPreferences, ConversationMessage } from "./types";
import { preferencesSchema } from "./schemas";

const STORAGE_KEY = "atlas-mvp-session-v1";

export const defaultPreferences: AtlasPreferences = {
  name: "Atlas",
  form: "orb",
  personality: "calm-strategist",
  coachingStyle: "balanced",
  accentColor: "#d9b45f",
  speechEnabled: false,
  localMemoryEnabled: true,
};

type StoredSession = {
  conversationId: string;
  messages: ConversationMessage[];
  preferences: AtlasPreferences;
};

function canUseStorage(): boolean {
  try {
    return typeof window !== "undefined" && Boolean(window.localStorage);
  } catch {
    return false;
  }
}

export const atlasStorage = {
  load(): StoredSession | null {
    if (!canUseStorage()) return null;
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as Partial<StoredSession>;
      return {
        conversationId:
          typeof parsed.conversationId === "string"
            ? parsed.conversationId
            : crypto.randomUUID(),
        messages: Array.isArray(parsed.messages)
          ? (parsed.messages.filter(
              (m) => typeof m?.content === "string",
            ) as ConversationMessage[])
          : [],
        preferences: preferencesSchema
          .catch(defaultPreferences)
          .parse(parsed.preferences),
      };
    } catch {
      return null;
    }
  },
  save(session: StoredSession): boolean {
    if (!canUseStorage() || !session.preferences.localMemoryEnabled)
      return false;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
      return true;
    } catch {
      return false;
    }
  },
  clear(): void {
    if (!canUseStorage()) return;
    window.localStorage.removeItem(STORAGE_KEY);
  },
  key: STORAGE_KEY,
};
