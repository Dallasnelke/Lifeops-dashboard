"use client";

import { KeyboardEvent, useState } from "react";

type Props = {
  onSend: (value: string) => void;
  disabled: boolean;
  onMic: () => void;
  micSupported: boolean;
  listening: boolean;
  interimText: string;
  onStop: () => void;
  generating: boolean;
};

export function AtlasComposer({
  onSend,
  disabled,
  onMic,
  micSupported,
  listening,
  interimText,
  onStop,
  generating,
}: Props) {
  const [value, setValue] = useState("");

  function submit() {
    const next = value.trim();
    if (!next || disabled) return;
    onSend(next);
    setValue("");
  }

  function handleKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      submit();
    }
  }

  return (
    <div className="composer">
      {interimText && (
        <div className="interim-text">Listening: {interimText}</div>
      )}
      <label htmlFor="atlas-message-input">Message Atlas</label>
      <textarea
        id="atlas-message-input"
        value={value}
        onChange={(event) => setValue(event.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Ask Atlas for a plan, next step, or clearer thinking..."
        rows={3}
      />
      <div className="composer-actions">
        <button
          className="primary"
          type="button"
          onClick={submit}
          disabled={disabled || !value.trim()}
        >
          Send
        </button>
        <button
          type="button"
          onClick={onMic}
          disabled={!micSupported}
          aria-pressed={listening}
        >
          {listening ? "Listening" : "Mic"}
        </button>
        <button type="button" onClick={onStop} disabled={!generating}>
          Stop generation
        </button>
      </div>
      <p className="composer-note">
        Enter sends. Shift+Enter creates a new line.
      </p>
    </div>
  );
}
