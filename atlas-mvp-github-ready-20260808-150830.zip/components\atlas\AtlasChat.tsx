﻿"use client";

import { useEffect, useRef, useState } from "react";
import { useAtlasChat } from "@/hooks/useAtlasChat";
import { useAtlasSpeechRecognition } from "@/hooks/useAtlasSpeechRecognition";
import { useAtlasSpeechSynthesis } from "@/hooks/useAtlasSpeechSynthesis";
import { AtlasOrb } from "./AtlasOrb";
import { AtlasMessage } from "./AtlasMessage";
import { AtlasComposer } from "./AtlasComposer";
import { AtlasSettings } from "./AtlasSettings";
import { AtlasPrivacy } from "./AtlasPrivacy";
import { AtlasCharacterStudio } from "./AtlasCharacterStudio";
import { AtlasStateIndicator } from "./AtlasStateIndicator";
import type { LifeOpsContext } from "@/lib/atlas/types";

export function AtlasChat({
  open,
  onClose,
  lifeOpsContext,
}: {
  open: boolean;
  onClose: () => void;
  lifeOpsContext?: LifeOpsContext | null;
}) {
  const chat = useAtlasChat(lifeOpsContext);
  const [draftFromVoice, setDraftFromVoice] = useState("");
  const [activePanel, setActivePanel] = useState<"chat" | "studio" | "privacy">(
    "chat",
  );
  const dialogRef = useRef<HTMLDivElement>(null);
  const historyRef = useRef<HTMLDivElement>(null);
  const shouldAutoScrollRef = useRef(true);

  const speechRecognition = useAtlasSpeechRecognition(
    (value) => setDraftFromVoice(value),
    (listening) => chat.setAtlasState(listening ? "listening" : "idle"),
  );
  const speechSynthesis = useAtlasSpeechSynthesis(
    chat.preferences.speechEnabled,
    (speaking) => chat.setAtlasState(speaking ? "speaking" : "idle"),
  );

  useEffect(() => {
    const latest = chat.messages.at(-1);
    if (
      latest?.role === "assistant" &&
      latest.status === "complete" &&
      chat.preferences.speechEnabled
    ) {
      speechSynthesis.speak(latest.content);
    }
  }, [chat.messages, chat.preferences.speechEnabled, speechSynthesis]);

  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const dialog = dialogRef.current;
    dialog?.focus();
    function handleKey(event: KeyboardEvent) {
      if (event.key === "Escape") onClose();
      if (event.key !== "Tab" || !dialog) return;
      const focusables = Array.from(
        dialog.querySelectorAll<HTMLElement>(
          "button, input, select, textarea, [tabindex]:not([tabindex='-1'])",
        ),
      ).filter((el) => !el.hasAttribute("disabled"));
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
    document.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("keydown", handleKey);
      previous?.focus?.();
    };
  }, [onClose, open]);

  useEffect(() => {
    function handlePrompt(event: Event) {
      const prompt = (event as CustomEvent<string>).detail;
      if (typeof prompt !== "string" || !prompt.trim()) return;
      chat.sendMessage(prompt);
    }

    window.addEventListener("lifeops-atlas-prompt", handlePrompt);
    return () =>
      window.removeEventListener("lifeops-atlas-prompt", handlePrompt);
  }, [chat]);

  useEffect(() => {
    if (shouldAutoScrollRef.current)
      historyRef.current?.scrollTo({
        top: historyRef.current.scrollHeight,
        behavior: "smooth",
      });
  }, [chat.messages]);

  function handleHistoryScroll() {
    const el = historyRef.current;
    if (!el) return;
    shouldAutoScrollRef.current =
      el.scrollHeight - el.scrollTop - el.clientHeight < 80;
  }

  function askForCommand() {
    chat.sendMessage(
      "Using the connected LifeOps context, tell me what deserves my attention today. Return one Atlas Command with priority, recommended action, reason, evidence, estimated time, and risk if ignored.",
    );
  }

  if (!open) return null;

  return (
    <div className="modal-backdrop" role="presentation">
      <div
        className="atlas-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="atlas-dialog-title"
        ref={dialogRef}
        tabIndex={-1}
      >
        <header className="dialog-header">
          <div className="dialog-title-row">
            <AtlasOrb
              state={chat.atlasState}
              preferences={chat.preferences}
              compact
            />
            <div>
              <p className="eyebrow">Conversation</p>
              <h2 id="atlas-dialog-title">{chat.preferences.name}</h2>
              <AtlasStateIndicator state={chat.atlasState} />
            </div>
          </div>
          <button type="button" onClick={onClose} aria-label="Close Atlas">
            Close
          </button>
        </header>

        <nav className="dialog-tabs" aria-label="Atlas panels">
          <button
            className={activePanel === "chat" ? "active" : ""}
            onClick={() => setActivePanel("chat")}
            type="button"
          >
            Chat
          </button>
          <button
            className={activePanel === "studio" ? "active" : ""}
            onClick={() => setActivePanel("studio")}
            type="button"
          >
            Character
          </button>
          <button
            className={activePanel === "privacy" ? "active" : ""}
            onClick={() => setActivePanel("privacy")}
            type="button"
          >
            Privacy
          </button>
        </nav>

        {activePanel === "chat" && (
          <main className="chat-layout">
            {lifeOpsContext && (
              <div className="context-strip" role="status">
                <strong>LifeOps connected</strong>
                <span>
                  {lifeOpsContext.command?.recommendedAction ||
                    lifeOpsContext.currentPriority ||
                    "Atlas can use a read-only LifeOps snapshot."}
                </span>
                <button
                  type="button"
                  onClick={askForCommand}
                  disabled={chat.atlasState === "thinking"}
                >
                  What deserves attention?
                </button>
              </div>
            )}
            <section
              className="message-history"
              ref={historyRef}
              onScroll={handleHistoryScroll}
              aria-live="polite"
            >
              {chat.messages.length === 0 ? (
                <div className="empty-chat">
                  <h3>
                    {lifeOpsContext
                      ? "Ask Atlas for today’s command."
                      : "Ask Atlas where to begin."}
                  </h3>
                  <p>
                    {lifeOpsContext
                      ? "Atlas has a read-only LifeOps snapshot and can explain the next highest-impact move."
                      : "Atlas can help turn a concern, decision, or plan into one clear next action."}
                  </p>
                </div>
              ) : (
                chat.messages.map((message) => (
                  <AtlasMessage key={message.id} message={message} />
                ))
              )}
            </section>
            {chat.error && (
              <p className="error-message" role="alert">
                {chat.error}
              </p>
            )}
            {draftFromVoice && (
              <button
                className="voice-draft"
                type="button"
                onClick={() => {
                  chat.sendMessage(draftFromVoice);
                  setDraftFromVoice("");
                }}
              >
                Use voice text: {draftFromVoice}
              </button>
            )}
            <AtlasComposer
              onSend={chat.sendMessage}
              disabled={chat.atlasState === "thinking"}
              onMic={speechRecognition.startListening}
              micSupported={speechRecognition.supported}
              listening={chat.atlasState === "listening"}
              interimText={speechRecognition.interimText}
              onStop={() => {
                chat.stopGeneration();
                speechSynthesis.stopSpeaking();
              }}
              generating={chat.atlasState === "thinking"}
            />
            {chat.preferences.speechEnabled && (
              <button
                className="stop-speaking"
                type="button"
                onClick={speechSynthesis.stopSpeaking}
              >
                Stop speaking
              </button>
            )}
            <p className="ai-disclaimer">
              Atlas is an AI system. It uses connected LifeOps context only when
              this page receives a local read-only snapshot.
            </p>
          </main>
        )}

        {activePanel === "studio" && (
          <div className="settings-grid">
            <AtlasCharacterStudio
              preferences={chat.preferences}
              onChange={chat.setPreferences}
            />
            <AtlasSettings
              preferences={chat.preferences}
              onChange={chat.setPreferences}
              onClearConversation={chat.clearConversation}
              onDeleteAllLocalData={chat.deleteAllLocalData}
            />
          </div>
        )}

        {activePanel === "privacy" && <AtlasPrivacy />}
      </div>
    </div>
  );
}
