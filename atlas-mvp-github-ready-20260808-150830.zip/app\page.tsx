"use client";

import type { PointerEvent } from "react";
import { useRef, useState } from "react";

export default function Home() {
  const [active, setActive] = useState(false);
  const shellRef = useRef<HTMLElement>(null);

  const interfaceNodes = Array.from({ length: 10 }, (_, index) => (
    <span key={index} className={`atlas-interface-node node-${index + 1}`} aria-hidden="true" />
  ));

  const biometricNodes = Array.from({ length: 7 }, (_, index) => (
    <span key={index} className={`atlas-bio-node bio-${index + 1}`} aria-hidden="true" />
  ));

  function handlePointerMove(event: PointerEvent<HTMLButtonElement>) {
    const rect = event.currentTarget.getBoundingClientRect();

    shellRef.current?.style.setProperty("--pointer-x", `${((event.clientX - rect.left) / rect.width) * 100}%`);
    shellRef.current?.style.setProperty("--pointer-y", `${((event.clientY - rect.top) / rect.height) * 100}%`);
  }

  function resetPointer() {
    shellRef.current?.style.setProperty("--pointer-x", "50%");
    shellRef.current?.style.setProperty("--pointer-y", "50%");
  }

  return (
    <main
      ref={shellRef}
      className={`atlas-visual-shell ${active ? "active" : ""}`}
    >
      <button
        className="atlas-visual-stage"
        type="button"
        aria-label="Activate Atlas"
        onPointerMove={handlePointerMove}
        onPointerLeave={resetPointer}
        onClick={() => setActive((value) => !value)}
      >
        <span className="atlas-deep-space" aria-hidden="true" />
        <span className="atlas-energy-field" aria-hidden="true" />
        <svg
          className="atlas-vector-character"
          viewBox="0 0 420 820"
          aria-hidden="true"
          focusable="false"
        >
          <defs>
            <radialGradient id="atlasGoldCore" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#fff6c8" />
              <stop offset="32%" stopColor="#ffd261" />
              <stop offset="72%" stopColor="#d9a632" stopOpacity="0.28" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="atlasMetal" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fff3bc" stopOpacity="0.92" />
              <stop offset="18%" stopColor="#302710" stopOpacity="0.66" />
              <stop offset="46%" stopColor="#030303" stopOpacity="0.9" />
              <stop offset="72%" stopColor="#d9b45f" stopOpacity="0.56" />
              <stop offset="100%" stopColor="#fff6cc" stopOpacity="0.78" />
            </linearGradient>
            <linearGradient id="atlasEnergyStroke" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#fff7d0" stopOpacity="0" />
              <stop offset="18%" stopColor="#fff7d0" stopOpacity="0.95" />
              <stop offset="52%" stopColor="#f0b93d" stopOpacity="0.58" />
              <stop offset="86%" stopColor="#fff0a3" stopOpacity="0.92" />
              <stop offset="100%" stopColor="#fff7d0" stopOpacity="0" />
            </linearGradient>
            <filter id="atlasVectorGlow" x="-60%" y="-60%" width="220%" height="220%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feColorMatrix
                in="blur"
                type="matrix"
                values="1 0 0 0 0.98 0 0.74 0 0 0.55 0 0 0.2 0 0.05 0 0 0 0.8 0"
                result="goldBlur"
              />
              <feMerge>
                <feMergeNode in="goldBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          <g className="vector-aura" filter="url(#atlasVectorGlow)">
            <ellipse cx="210" cy="405" rx="144" ry="342" />
            <path d="M210 40 C258 150 272 250 244 386 C222 494 232 615 210 778" />
            <path d="M210 40 C162 150 148 250 176 386 C198 494 188 615 210 778" />
          </g>

          <g className="vector-body">
            <path
              className="vector-part vector-head"
              d="M167 112 C168 52 252 52 253 112 C255 170 238 205 210 208 C181 205 165 170 167 112 Z"
            />
            <path
              className="vector-panel"
              d="M188 87 C203 68 220 68 235 87 C229 124 224 151 210 178 C196 151 191 124 188 87 Z"
            />
            <path className="vector-part vector-neck" d="M190 196 L230 196 L239 240 L181 240 Z" />
            <path
              className="vector-part vector-chest"
              d="M132 245 C156 212 183 225 210 245 C237 225 264 212 288 245 C276 319 252 383 210 421 C168 383 144 319 132 245 Z"
            />
            <path
              className="vector-part vector-core-shell"
              d="M175 283 C189 258 231 258 245 283 C261 313 244 354 210 360 C176 354 159 313 175 283 Z"
            />
            <circle className="vector-core" cx="210" cy="312" r="39" />
            <circle className="vector-core-inner" cx="210" cy="312" r="17" />
            <path
              className="vector-part vector-waist"
              d="M172 414 C189 397 231 397 248 414 L270 506 C248 538 224 552 210 556 C196 552 172 538 150 506 Z"
            />
            <path
              className="vector-part vector-arm vector-arm-left"
              d="M129 260 C89 310 68 382 62 464 C60 494 82 499 92 470 C108 404 129 356 156 309 Z"
            />
            <path
              className="vector-part vector-arm vector-arm-right"
              d="M291 260 C331 310 352 382 358 464 C360 494 338 499 328 470 C312 404 291 356 264 309 Z"
            />
            <path
              className="vector-hand vector-hand-left"
              d="M58 462 C45 475 37 493 41 506 C55 501 69 490 84 472 Z"
            />
            <path
              className="vector-hand vector-hand-right"
              d="M362 462 C375 475 383 493 379 506 C365 501 351 490 336 472 Z"
            />
            <path
              className="vector-part vector-leg vector-leg-left"
              d="M153 506 C177 529 195 562 199 614 L192 768 C166 739 149 668 144 608 C140 562 141 532 153 506 Z"
            />
            <path
              className="vector-part vector-leg vector-leg-right"
              d="M267 506 C243 529 225 562 221 614 L228 768 C254 739 271 668 276 608 C280 562 279 532 267 506 Z"
            />
          </g>

          <g className="vector-circuits">
            <path d="M210 70 L210 780" />
            <path d="M183 126 C195 153 202 180 210 212 C218 180 225 153 237 126" />
            <path d="M139 268 C175 284 195 298 210 312 C225 298 245 284 281 268" />
            <path d="M120 352 C157 380 186 401 210 432 C234 401 263 380 300 352" />
            <path d="M156 538 C184 574 199 620 210 712 C221 620 236 574 264 538" />
            <path d="M91 446 C126 424 151 396 176 360" />
            <path d="M329 446 C294 424 269 396 244 360" />
          </g>

          <g className="vector-joints">
            <circle cx="210" cy="104" r="15" />
            <circle cx="151" cy="288" r="9" />
            <circle cx="269" cy="288" r="9" />
            <circle cx="91" cy="454" r="8" />
            <circle cx="329" cy="454" r="8" />
            <circle cx="184" cy="610" r="8" />
            <circle cx="236" cy="610" r="8" />
            <circle cx="192" cy="760" r="8" />
            <circle cx="228" cy="760" r="8" />
          </g>
        </svg>
        <span className="atlas-core-glow" aria-hidden="true" />
        <span className="atlas-head-sensor" aria-hidden="true" />
        <span className="atlas-spine-light" aria-hidden="true" />
        <span className="atlas-vertical-light" aria-hidden="true" />
        <span className="atlas-ring ring-a" aria-hidden="true" />
        <span className="atlas-ring ring-b" aria-hidden="true" />
        <span className="atlas-ring ring-c" aria-hidden="true" />
        <span className="atlas-orbit-shell orbit-shell-a" aria-hidden="true" />
        <span className="atlas-orbit-shell orbit-shell-b" aria-hidden="true" />
        <span className="atlas-interface-grid" aria-hidden="true" />
        <span className="atlas-data-rain" aria-hidden="true" />
        {interfaceNodes}
        {biometricNodes}
        <span className="atlas-particles" aria-hidden="true" />
        <span className="atlas-neural-halo" aria-hidden="true" />
        <span className="atlas-ground" aria-hidden="true" />
      </button>
    </main>
  );
}
