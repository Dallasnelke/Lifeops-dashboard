import type { AtlasPreferences } from "@/lib/atlas/types";

const forms = [
  ["humanoid", "Synthetic guide", "Full Atlas body"],
  ["orb", "Core orb", "Minimal command mode"],
  ["emblem", "Emblem", "Quiet brand mode"],
  ["spirit", "Energy form", "Softer presence"],
  ["robot", "Technical guide", "Sharper signal"],
  ["pet", "Companion", "Future character path"],
] as const;

const personalities = [
  ["calm-strategist", "Calm strategist"],
  ["warm-coach", "Warm coach"],
  ["direct-adviser", "Direct adviser"],
  ["curious-collaborator", "Curious collaborator"],
] as const;

const coachingStyles = [
  ["concise", "Concise"],
  ["balanced", "Balanced"],
  ["reflective", "Reflective"],
  ["step-by-step", "Step-by-step"],
] as const;

const voiceStyles = [
  ["calm", "Calm", "Low, steady delivery"],
  ["warm", "Warm", "Softer and more encouraging"],
  ["direct", "Direct", "Clear and efficient"],
] as const;

const motionStyles = [
  ["still", "Still", "Least movement"],
  ["calm", "Calm", "Premium breathing motion"],
  ["alive", "Alive", "More responsive energy"],
] as const;

const visualIntensities = [
  ["minimal", "Minimal", "Low glow"],
  ["balanced", "Balanced", "Default presence"],
  ["radiant", "Radiant", "Stronger gold energy"],
] as const;

export function AtlasCharacterStudio({
  preferences,
  onChange,
}: {
  preferences: AtlasPreferences;
  onChange: (next: AtlasPreferences) => void;
}) {
  return (
    <section className="settings-section" aria-labelledby="character-title">
      <h3 id="character-title">Character Studio</h3>
      <label>
        Atlas name
        <input
          value={preferences.name}
          maxLength={32}
          onChange={(event) =>
            onChange({ ...preferences, name: event.target.value || "Atlas" })
          }
        />
      </label>
      <label>
        Accent color
        <input
          type="color"
          value={preferences.accentColor}
          onChange={(event) =>
            onChange({ ...preferences, accentColor: event.target.value })
          }
        />
      </label>
      <div
        className="studio-grid studio-grid-three"
        role="radiogroup"
        aria-label="Voice style"
      >
        {voiceStyles.map(([value, label, note]) => (
          <button
            key={value}
            type="button"
            className={preferences.voiceStyle === value ? "selected" : ""}
            onClick={() => onChange({ ...preferences, voiceStyle: value })}
          >
            <strong>{label}</strong>
            <span>{note}</span>
          </button>
        ))}
      </div>
      <div
        className="studio-grid studio-grid-three"
        role="radiogroup"
        aria-label="Motion style"
      >
        {motionStyles.map(([value, label, note]) => (
          <button
            key={value}
            type="button"
            className={preferences.motionStyle === value ? "selected" : ""}
            onClick={() => onChange({ ...preferences, motionStyle: value })}
          >
            <strong>{label}</strong>
            <span>{note}</span>
          </button>
        ))}
      </div>
      <div
        className="studio-grid studio-grid-three"
        role="radiogroup"
        aria-label="Visual intensity"
      >
        {visualIntensities.map(([value, label, note]) => (
          <button
            key={value}
            type="button"
            className={preferences.visualIntensity === value ? "selected" : ""}
            onClick={() => onChange({ ...preferences, visualIntensity: value })}
          >
            <strong>{label}</strong>
            <span>{note}</span>
          </button>
        ))}
      </div>
      <div className="studio-grid" role="radiogroup" aria-label="Atlas form">
        {forms.map(([value, label, note]) => (
          <button
            key={value}
            type="button"
            className={preferences.form === value ? "selected" : ""}
            onClick={() => onChange({ ...preferences, form: value })}
          >
            <strong>{label}</strong>
            <span>{note}</span>
          </button>
        ))}
      </div>
      <label>
        Personality
        <select
          value={preferences.personality}
          onChange={(event) =>
            onChange({
              ...preferences,
              personality: event.target
                .value as AtlasPreferences["personality"],
            })
          }
        >
          {personalities.map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </select>
      </label>
      <label>
        Coaching style
        <select
          value={preferences.coachingStyle}
          onChange={(event) =>
            onChange({
              ...preferences,
              coachingStyle: event.target
                .value as AtlasPreferences["coachingStyle"],
            })
          }
        >
          {coachingStyles.map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </select>
      </label>
    </section>
  );
}
