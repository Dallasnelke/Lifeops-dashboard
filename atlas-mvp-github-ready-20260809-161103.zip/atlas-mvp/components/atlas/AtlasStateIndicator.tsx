import type { AtlasState } from "@/lib/atlas/types";

export function AtlasStateIndicator({ state }: { state: AtlasState }) {
  const copy: Record<AtlasState, string> = {
    idle: "Atlas is idle",
    thinking: "Atlas is thinking",
    listening: "Atlas is listening",
    speaking: "Atlas is speaking",
    success: "Atlas completed a response",
    attention: "Atlas has something to review",
    error: "Atlas needs attention",
  };
  return (
    <div
      className={`state-indicator ${state}`}
      role="status"
      aria-live="polite"
    >
      <span aria-hidden="true" />
      {copy[state]}
    </div>
  );
}
