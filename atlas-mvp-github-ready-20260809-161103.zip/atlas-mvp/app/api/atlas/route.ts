﻿import OpenAI from "openai";
import { NextRequest } from "next/server";
import { atlasRequestSchema } from "@/lib/atlas/schemas";
import { truncateHistory } from "@/lib/atlas/history";
import { buildAtlasInstructions } from "@/lib/atlas/instructions";
import { checkRateLimit } from "@/lib/atlas/rate-limit";
import { summarizeLifeOpsContext } from "@/lib/atlas/lifeops-context";

export const runtime = "nodejs";

const REQUEST_TIMEOUT_MS = 30_000;

function readableError(status: number, message: string): Response {
  return Response.json({ error: message }, { status });
}

function clientIdentifier(request: NextRequest): string {
  return (
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local-dev"
  );
}

export async function POST(request: NextRequest): Promise<Response> {
  const apiKey = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL;

  if (!apiKey)
    return readableError(
      500,
      "Atlas is not configured yet. Add OPENAI_API_KEY to .env.local.",
    );
  if (!model)
    return readableError(500, "Atlas is missing OPENAI_MODEL in .env.local.");

  const rate = checkRateLimit(clientIdentifier(request));
  if (!rate.allowed)
    return readableError(
      429,
      "Atlas is receiving too many requests. Wait a moment and try again.",
    );

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return readableError(400, "Send a valid JSON request.");
  }

  const parsed = atlasRequestSchema.safeParse(body);
  if (!parsed.success)
    return readableError(
      400,
      "Atlas needs a non-empty message and valid preferences.",
    );

  const { history, truncated } = truncateHistory(parsed.data.history);
  const contextMessage = parsed.data.lifeOpsContext
    ? [
        {
          type: "message" as const,
          role: "user" as const,
          content: summarizeLifeOpsContext(parsed.data.lifeOpsContext),
        },
      ]
    : [];
  const input = [
    ...contextMessage,
    ...history.map((item) => ({
      type: "message" as const,
      role: item.role,
      content: item.content,
    })),
    {
      type: "message" as const,
      role: "user" as const,
      content: parsed.data.message,
    },
  ];

  const timeoutController = new AbortController();
  const timeout = setTimeout(
    () => timeoutController.abort("timeout"),
    REQUEST_TIMEOUT_MS,
  );
  request.signal.addEventListener(
    "abort",
    () => timeoutController.abort("client disconnected"),
    { once: true },
  );

  const encoder = new TextEncoder();
  const client = new OpenAI({ apiKey });

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        if (truncated)
          controller.enqueue(
            encoder.encode(
              "[Older context was trimmed for this response.]\n\n",
            ),
          );
        const upstream = await client.responses.create(
          {
            model,
            instructions: buildAtlasInstructions({
              atlasName: parsed.data.preferences.atlasName,
              personality: parsed.data.preferences.personality,
              coachingStyle: parsed.data.preferences.coachingStyle,
            }),
            input,
            max_output_tokens: 900,
            temperature: 0.6,
            store: false,
            stream: true,
          },
          { signal: timeoutController.signal },
        );

        for await (const event of upstream) {
          if (timeoutController.signal.aborted) break;
          if (event.type === "response.output_text.delta")
            controller.enqueue(encoder.encode(event.delta));
          if (event.type === "response.failed")
            throw new Error("The AI provider could not complete the response.");
          if (event.type === "error")
            throw new Error("The AI provider returned an error.");
        }
        controller.close();
      } catch (error) {
        const aborted =
          timeoutController.signal.aborted || request.signal.aborted;
        const message = aborted
          ? "Atlas stopped before finishing the response."
          : "Atlas could not generate a response. Check configuration or try again.";
        controller.enqueue(encoder.encode(`\n\n${message}`));
        controller.close();
        if (!aborted) console.error("Atlas API route error", error);
      } finally {
        clearTimeout(timeout);
      }
    },
    cancel() {
      timeoutController.abort("client cancelled stream");
      clearTimeout(timeout);
    },
  });

  return new Response(stream, {
    status: 200,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Atlas-RateLimit-Remaining": String(rate.remaining),
    },
  });
}
