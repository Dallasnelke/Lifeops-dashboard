import type { CSSProperties } from "react";
import type {
  AtlasAnimationState,
  CharacterConfig,
} from "@/lib/onboarding/types";

type Props = {
  config: CharacterConfig;
  animationState: AtlasAnimationState;
  reducedMotion?: boolean;
  label?: string;
};

export function CharacterRenderer({
  config,
  animationState,
  reducedMotion = false,
  label = "Atlas character preview",
}: Props) {
  const style = {
    "--character-accent": config.accentColor,
    "--eye-color": config.eyeColor,
    "--skin-tone": config.skinTone,
    "--character-scale-y": 0.92 + config.height * 0.2,
    "--character-scale-x": 0.92 + config.build * 0.16,
  } as CSSProperties;

  return (
    <figure
      className={`character-renderer ${animationState} ${reducedMotion ? "reduced" : ""}`}
      data-renderer="css-prototype"
      style={style}
      aria-label={label}
    >
      <div className={`character-room ${config.environmentPreset}`}>
        <div className="character-light" aria-hidden="true" />
        <div className="character-halo" aria-hidden="true" />
        <div className="character-avatar" aria-hidden="true">
          <span className="character-head">
            <span className="character-hair" />
            <span className="character-eye left" />
            <span className="character-eye right" />
            <span className="character-mouth" />
          </span>
          <span className="character-neck" />
          <span className={`character-body ${config.clothingPreset}`}>
            <span className="character-collar left" />
            <span className="character-collar right" />
            <span className="character-core" />
          </span>
          <span className="character-arm left" />
          <span className="character-arm right" />
          <span className="character-shadow" />
        </div>
      </div>
      <figcaption>Local character renderer</figcaption>
    </figure>
  );
}
