# Upload Notes

Upload the contents of this folder to GitHub for the current Atlas MVP.

Do upload:
- app/
- components/
- hooks/
- lib/
- public/
- tests/
- README.md
- package.json
- pnpm-lock.yaml
- pnpm-workspace.yaml
- tsconfig.json
- next.config.mjs
- eslint.config.mjs
- next-env.d.ts
- .env.example
- .gitignore

Do not upload:
- node_modules/
- .next/
- .env.local
- tsconfig.tsbuildinfo
- old zip files
- private backups or personal data

Latest verification performed before packaging:
- TypeScript passed
- Source ESLint passed
- 14 tests passed
- Production build passed
- Browser runtime check passed with WebGL active and no console errors
