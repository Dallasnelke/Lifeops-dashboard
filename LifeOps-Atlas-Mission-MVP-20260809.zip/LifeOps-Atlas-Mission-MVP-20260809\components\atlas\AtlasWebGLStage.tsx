"use client";

import { useEffect, useRef, useState } from "react";
import {
  buildAtlasAvatarConfig,
  type AtlasAvatarConfig,
  type AtlasMaterialId,
} from "@/lib/atlas/avatar-config";
import type {
  AtlasPreferences,
  AtlasState,
  AtlasVisualIntensity,
} from "@/lib/atlas/types";

type AtlasWebGLStageProps = {
  state: AtlasState;
  preferences: AtlasPreferences;
  onReady?: (ready: boolean) => void;
};

type Vec3 = [number, number, number];
type Mat4 = Float32Array;

type MeshBuffers = {
  vertexBuffer: WebGLBuffer;
  normalBuffer: WebGLBuffer;
  indexBuffer: WebGLBuffer;
  indexCount: number;
};

type RendererResources = {
  gl: WebGLRenderingContext;
  program: WebGLProgram;
  mesh: MeshBuffers;
  locations: {
    position: number;
    normal: number;
    model: WebGLUniformLocation;
    viewProjection: WebGLUniformLocation;
    baseColor: WebGLUniformLocation;
    accentColor: WebGLUniformLocation;
    cameraPosition: WebGLUniformLocation;
    lightPosition: WebGLUniformLocation;
    glow: WebGLUniformLocation;
    material: WebGLUniformLocation;
  };
};

type Part = {
  name: string;
  translate: Vec3;
  rotate: Vec3;
  scale: Vec3;
  color: Vec3;
  glow: number;
  material: number;
};

const VERTEX_SHADER = `
attribute vec3 aPosition;
attribute vec3 aNormal;

uniform mat4 uModel;
uniform mat4 uViewProjection;

varying vec3 vNormal;
varying vec3 vWorldPosition;

void main() {
  vec4 worldPosition = uModel * vec4(aPosition, 1.0);
  vWorldPosition = worldPosition.xyz;
  vNormal = normalize(mat3(uModel) * aNormal);
  gl_Position = uViewProjection * worldPosition;
}
`;

const FRAGMENT_SHADER = `
precision mediump float;

uniform vec3 uBaseColor;
uniform vec3 uAccentColor;
uniform vec3 uCameraPosition;
uniform vec3 uLightPosition;
uniform float uGlow;
uniform float uMaterial;

varying vec3 vNormal;
varying vec3 vWorldPosition;

void main() {
  vec3 normal = normalize(vNormal);
  vec3 viewDirection = normalize(uCameraPosition - vWorldPosition);
  vec3 lightDirection = normalize(uLightPosition - vWorldPosition);
  vec3 halfVector = normalize(viewDirection + lightDirection);
  vec3 rimDirection = normalize(vec3(-0.55, 0.34, -0.76));
  vec3 bounceDirection = normalize(vec3(0.18, -0.9, 0.25));

  float diffuse = max(dot(normal, lightDirection), 0.0);
  float rim = pow(1.0 - max(dot(normal, viewDirection), 0.0), 2.15);
  float backRim = pow(max(dot(normal, rimDirection), 0.0), 1.45);
  float lowerBounce = max(dot(normal, bounceDirection), 0.0) * smoothstep(0.3, -1.9, vWorldPosition.y);
  float specular = pow(max(dot(normal, halfVector), 0.0), mix(22.0, 96.0, uMaterial));
  float tightSpecular = pow(max(dot(normal, halfVector), 0.0), 180.0) * uMaterial;
  float verticalWarmth = smoothstep(-1.7, 2.4, vWorldPosition.y);
  float coreFalloff = 1.0 - smoothstep(0.0, 1.28, distance(vWorldPosition, vec3(0.0, 0.92, 0.18)));
  float floorFalloff = 1.0 - smoothstep(-2.18, -1.25, vWorldPosition.y);

  vec3 metal = uBaseColor * (0.18 + diffuse * 0.62 + lowerBounce * 0.14);
  vec3 edge = uAccentColor * (
    rim * (0.12 + uGlow * 0.2) +
    backRim * (0.09 + uGlow * 0.12) +
    specular * (0.08 + uMaterial * 0.2) +
    tightSpecular * 0.28
  );
  vec3 innerWarmth = uAccentColor * (verticalWarmth * 0.018 + coreFalloff * uGlow * 0.07 + floorFalloff * 0.035);
  vec3 color = metal + edge + innerWarmth;

  gl_FragColor = vec4(color, 1.0);
}
`;

const BLACK_GOLD: Vec3 = [0.011, 0.01, 0.008];
const DEEP_GRAPHITE: Vec3 = [0.032, 0.03, 0.026];
const GLASS_BLACK: Vec3 = [0.018, 0.017, 0.014];
const JOINT_GOLD: Vec3 = [0.58, 0.4, 0.1];
const IVORY_GOLD: Vec3 = [0.86, 0.74, 0.42];
const SHADOW_BLACK: Vec3 = [0.006, 0.005, 0.004];

export function AtlasWebGLStage({
  state,
  preferences,
  onReady,
}: AtlasWebGLStageProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<number | null>(null);
  const propsRef = useRef({ state, preferences });
  const [supported, setSupported] = useState(true);

  useEffect(() => {
    propsRef.current = { state, preferences };
  }, [state, preferences]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const gl = canvas.getContext("webgl", {
      alpha: true,
      antialias: true,
      depth: true,
      powerPreference: "high-performance",
      premultipliedAlpha: false,
    });

    if (!gl) {
      setSupported(false);
      onReady?.(false);
      return;
    }

    const resources = createResources(gl);
    if (!resources) {
      setSupported(false);
      onReady?.(false);
      return;
    }
    const activeCanvas = canvas;
    const activeResources = resources;

    onReady?.(true);
    let disposed = false;
    function resizeCanvas() {
      const pixelRatio = Math.min(window.devicePixelRatio || 1, 1.35);
      const rect = activeCanvas.getBoundingClientRect();
      const width = Math.max(1, Math.floor(rect.width * pixelRatio));
      const height = Math.max(1, Math.floor(rect.height * pixelRatio));
      if (activeCanvas.width !== width || activeCanvas.height !== height) {
        activeCanvas.width = width;
        activeCanvas.height = height;
      }
      activeResources.gl.viewport(
        0,
        0,
        activeCanvas.width,
        activeCanvas.height,
      );
    }

    function render(timeMs: number) {
      if (disposed) return;
      resizeCanvas();

      const { state: currentState, preferences: currentPreferences } =
        propsRef.current;
      const t = timeMs / 1000;
      const stateConfig = getStateConfig(currentState);
      const avatarConfig = buildAtlasAvatarConfig(currentPreferences);
      const intensity = getIntensity(currentPreferences.visualIntensity);
      const motion =
        currentPreferences.motionStyle === "still"
          ? 0
          : currentPreferences.motionStyle === "alive"
            ? 1.25
            : 0.72;
      const breath = Math.sin(t * (0.85 + stateConfig.speed * 0.35)) * motion;
      const turn = Math.sin(t * 0.28) * 0.045 * motion;
      const aspect = activeCanvas.width / Math.max(activeCanvas.height, 1);
      const cameraPosition: Vec3 = [
        0,
        aspect < 0.78 ? 0.28 : 0.48,
        aspect < 0.78 ? 9.85 : 8.15,
      ];
      const lightPosition: Vec3 = [
        -2.4,
        4.1,
        4.3 + avatarConfig.lighting.rimLight * 0.25,
      ];
      const viewProjection = createViewProjection(aspect, cameraPosition);
      const accent = hexToVector(currentPreferences.accentColor);
      const coreColor = hexToVector(avatarConfig.coreColor);

      drawScene(activeResources, {
        time: t,
        breath,
        turn,
        accent,
        coreColor,
        config: avatarConfig,
        cameraPosition,
        lightPosition,
        viewProjection,
        glow: stateConfig.glow * intensity * avatarConfig.glowIntensity,
      });

      frameRef.current = window.requestAnimationFrame(render);
    }

    frameRef.current = window.requestAnimationFrame(render);

    return () => {
      disposed = true;
      if (frameRef.current !== null) {
        window.cancelAnimationFrame(frameRef.current);
        frameRef.current = null;
      }
      cleanupResources(activeResources);
    };
  }, [onReady]);

  if (!supported) {
    return null;
  }

  return (
    <canvas ref={canvasRef} className="atlas-webgl-stage" aria-hidden="true" />
  );
}

function createResources(gl: WebGLRenderingContext): RendererResources | null {
  const vertexShader = compileShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
  const fragmentShader = compileShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER);
  if (!vertexShader || !fragmentShader) return null;

  const program = gl.createProgram();
  if (!program) return null;
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);
  gl.deleteShader(vertexShader);
  gl.deleteShader(fragmentShader);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.error("Atlas WebGL program failed", gl.getProgramInfoLog(program));
    gl.deleteProgram(program);
    return null;
  }

  const mesh = createSphereMesh(gl, 18, 12);
  if (!mesh) {
    gl.deleteProgram(program);
    return null;
  }

  const locations = {
    position: gl.getAttribLocation(program, "aPosition"),
    normal: gl.getAttribLocation(program, "aNormal"),
    model: getUniform(gl, program, "uModel"),
    viewProjection: getUniform(gl, program, "uViewProjection"),
    baseColor: getUniform(gl, program, "uBaseColor"),
    accentColor: getUniform(gl, program, "uAccentColor"),
    cameraPosition: getUniform(gl, program, "uCameraPosition"),
    lightPosition: getUniform(gl, program, "uLightPosition"),
    glow: getUniform(gl, program, "uGlow"),
    material: getUniform(gl, program, "uMaterial"),
  };

  if (
    locations.position < 0 ||
    locations.normal < 0 ||
    Object.values(locations).some((value) => value === null)
  ) {
    cleanupResources({ gl, program, mesh, locations } as RendererResources);
    return null;
  }

  gl.enable(gl.DEPTH_TEST);
  gl.enable(gl.CULL_FACE);
  gl.cullFace(gl.BACK);
  gl.clearColor(0, 0, 0, 0);

  return { gl, program, mesh, locations };
}

function compileShader(
  gl: WebGLRenderingContext,
  type: number,
  source: string,
) {
  const shader = gl.createShader(type);
  if (!shader) return null;
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error("Atlas WebGL shader failed", gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}

function getUniform(
  gl: WebGLRenderingContext,
  program: WebGLProgram,
  name: string,
) {
  const location = gl.getUniformLocation(program, name);
  if (!location) console.error(`Atlas WebGL missing uniform: ${name}`);
  return location as WebGLUniformLocation;
}

function createSphereMesh(
  gl: WebGLRenderingContext,
  columns: number,
  rows: number,
): MeshBuffers | null {
  const vertices: number[] = [];
  const normals: number[] = [];
  const indices: number[] = [];

  for (let y = 0; y <= rows; y += 1) {
    const v = y / rows;
    const theta = v * Math.PI;
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let x = 0; x <= columns; x += 1) {
      const u = x / columns;
      const phi = u * Math.PI * 2;
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);
      const px = cosPhi * sinTheta;
      const py = cosTheta;
      const pz = sinPhi * sinTheta;
      vertices.push(px, py, pz);
      normals.push(px, py, pz);
    }
  }

  for (let y = 0; y < rows; y += 1) {
    for (let x = 0; x < columns; x += 1) {
      const first = y * (columns + 1) + x;
      const second = first + columns + 1;
      indices.push(first, second, first + 1, second, second + 1, first + 1);
    }
  }

  const vertexBuffer = gl.createBuffer();
  const normalBuffer = gl.createBuffer();
  const indexBuffer = gl.createBuffer();
  if (!vertexBuffer || !normalBuffer || !indexBuffer) return null;

  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
  gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.STATIC_DRAW);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
  gl.bufferData(
    gl.ELEMENT_ARRAY_BUFFER,
    new Uint16Array(indices),
    gl.STATIC_DRAW,
  );

  return {
    vertexBuffer,
    normalBuffer,
    indexBuffer,
    indexCount: indices.length,
  };
}

function drawScene(
  resources: RendererResources,
  options: {
    time: number;
    breath: number;
    turn: number;
    accent: Vec3;
    coreColor: Vec3;
    config: AtlasAvatarConfig;
    cameraPosition: Vec3;
    lightPosition: Vec3;
    viewProjection: Mat4;
    glow: number;
  },
) {
  const { gl, program, mesh, locations } = resources;
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.useProgram(program);

  gl.bindBuffer(gl.ARRAY_BUFFER, mesh.vertexBuffer);
  gl.enableVertexAttribArray(locations.position);
  gl.vertexAttribPointer(locations.position, 3, gl.FLOAT, false, 0, 0);

  gl.bindBuffer(gl.ARRAY_BUFFER, mesh.normalBuffer);
  gl.enableVertexAttribArray(locations.normal);
  gl.vertexAttribPointer(locations.normal, 3, gl.FLOAT, false, 0, 0);

  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.indexBuffer);
  gl.uniformMatrix4fv(locations.viewProjection, false, options.viewProjection);
  gl.uniform3fv(locations.accentColor, options.accent);
  gl.uniform3fv(locations.cameraPosition, options.cameraPosition);
  gl.uniform3fv(locations.lightPosition, options.lightPosition);

  const bodyParts = createAtlasParts(options);
  for (const part of bodyParts) {
    const model = composeMatrix(part.translate, part.rotate, part.scale);
    gl.uniformMatrix4fv(locations.model, false, model);
    gl.uniform3fv(locations.baseColor, part.color);
    gl.uniform1f(locations.glow, part.glow);
    gl.uniform1f(locations.material, part.material);
    gl.drawElements(gl.TRIANGLES, mesh.indexCount, gl.UNSIGNED_SHORT, 0);
  }
}

function createAtlasParts({
  time,
  breath,
  turn,
  glow,
  config,
  coreColor,
}: {
  time: number;
  breath: number;
  turn: number;
  accent: Vec3;
  coreColor: Vec3;
  config: AtlasAvatarConfig;
  cameraPosition: Vec3;
  lightPosition: Vec3;
  viewProjection: Mat4;
  glow: number;
}): Part[] {
  const chestRise = breath * 0.035;
  const headRise = breath * 0.045;
  const armSwing = breath * 0.025;
  const corePulse =
    (0.7 + Math.sin(time * 1.7) * 0.15 + glow * 0.28) * config.coreIntensity;
  const seamGlow = glow * config.energySeamIntensity;
  const skin = materialColor(config.skinMaterial);
  const primary = materialColor(config.primaryMaterial);
  const secondary = materialColor(config.secondaryMaterial);
  const highlight =
    config.secondaryMaterial === "ivory" ? IVORY_GOLD : JOINT_GOLD;
  const shoulder = config.shoulderWidth;
  const torso = config.torsoWidth;
  const waist = config.waistWidth;
  const arm = config.armLength;
  const leg = config.legLength;
  const headScale: Vec3 =
    config.headShape === "narrow-orbital"
      ? [0.2, 0.38, 0.2]
      : config.headShape === "sentinel-mask"
        ? [0.24, 0.34, 0.22]
        : [0.21, 0.35, 0.2];

  const parts: Part[] = [
    {
      name: "lower-bounce-shadow",
      translate: [0, -2.05, -0.04],
      rotate: [0, 0, 0],
      scale: [0.76, 0.038, 0.34],
      color: SHADOW_BLACK,
      glow: seamGlow * 0.16,
      material: 0.4,
    },
    {
      name: "abdomen",
      translate: [0, 0.55 + chestRise, 0],
      rotate: [0.04, turn, 0],
      scale: [0.34 * torso, 0.65, 0.19],
      color: skin,
      glow: seamGlow * 0.3,
      material: 0.96,
    },
    {
      name: "chest-shell",
      translate: [0, 0.98 + chestRise, 0.03],
      rotate: [0.08, turn, 0],
      scale: [0.55 * shoulder, 0.35, 0.18],
      color: primary,
      glow: seamGlow * 0.34,
      material: 1,
    },
    {
      name: "shoulder-yoke",
      translate: [0, 1.16 + chestRise, 0.01],
      rotate: [0.02, turn, 0],
      scale: [0.64 * shoulder, 0.13, 0.13],
      color: secondary,
      glow: seamGlow * 0.2,
      material: 1,
    },
    {
      name: "sternum-plate",
      translate: [0, 0.74 + chestRise, 0.185],
      rotate: [0.08, turn, 0],
      scale: [0.12, 0.33, 0.026],
      color: secondary,
      glow: seamGlow * 0.18,
      material: 1,
    },
    {
      name: "pelvis",
      translate: [0, -0.08, 0],
      rotate: [-0.03, turn, 0],
      scale: [0.4 * waist, 0.28, 0.2],
      color: primary,
      glow: seamGlow * 0.22,
      material: 0.9,
    },
    {
      name: "neck",
      translate: [0, 1.52 + headRise * 0.45, 0],
      rotate: [0, turn, 0],
      scale: [0.13, 0.22, 0.12],
      color: skin,
      glow: seamGlow * 0.2,
      material: 0.88,
    },
    {
      name: "head",
      translate: [0, 1.86 + headRise, 0],
      rotate: [0.03, turn * 1.35, 0],
      scale: headScale,
      color: skin,
      glow: seamGlow * 0.42,
      material: 1,
    },
    {
      name: "cranial-highlight-left",
      translate: [-0.068, 1.89 + headRise, 0.165],
      rotate: [0.05, turn + 0.16, -0.08],
      scale: [0.034, 0.23, 0.014],
      color: secondary,
      glow: seamGlow * 0.18,
      material: 1,
    },
    {
      name: "cranial-highlight-right",
      translate: [0.068, 1.89 + headRise, 0.165],
      rotate: [0.05, turn - 0.16, 0.08],
      scale: [0.034, 0.23, 0.014],
      color: secondary,
      glow: seamGlow * 0.18,
      material: 1,
    },
    {
      name: "face-mask",
      translate: [0, 1.88 + headRise, 0.19],
      rotate: [0, turn, 0],
      scale: [0.11, 0.17, 0.018],
      color: BLACK_GOLD,
      glow: seamGlow * 0.12,
      material: 0.98,
    },
    {
      name: "core-housing",
      translate: [0, 0.94 + chestRise, 0.19],
      rotate: [0, turn, 0],
      scale: [0.17, 0.17, 0.045],
      color: BLACK_GOLD,
      glow: seamGlow * 0.22,
      material: 1,
    },
    {
      name: "core-source",
      translate: [0, 0.94 + chestRise, 0.2],
      rotate: [0, turn, 0],
      scale: [0.09 + corePulse * 0.016, 0.09 + corePulse * 0.016, 0.038],
      color: coreColor,
      glow: 0.78 + corePulse,
      material: 0.72,
    },
    {
      name: "core-halo",
      translate: [0, 0.94 + chestRise, 0.18],
      rotate: [0, turn, 0],
      scale: [0.22 + corePulse * 0.026, 0.22 + corePulse * 0.026, 0.018],
      color: coreColor,
      glow: 0.36 + corePulse * 0.55,
      material: 0.32,
    },
    {
      name: "left-deltoid",
      translate: [-0.56 * shoulder, 1.02 + chestRise, 0.01],
      rotate: [0.05, turn, -0.28],
      scale: [0.16, 0.19, 0.13],
      color: secondary,
      glow: seamGlow * 0.2,
      material: 1,
    },
    {
      name: "right-deltoid",
      translate: [0.56 * shoulder, 1.02 + chestRise, 0.01],
      rotate: [0.05, turn, 0.28],
      scale: [0.16, 0.19, 0.13],
      color: secondary,
      glow: seamGlow * 0.2,
      material: 1,
    },
    limb(
      "upper-arm-left",
      [-0.51 * shoulder, 0.62, 0],
      [0.2, 0.18, 0.58 + armSwing],
      [0.1, 0.5 * arm, 0.084],
      seamGlow,
      skin,
    ),
    limb(
      "upper-arm-right",
      [0.51 * shoulder, 0.62, 0],
      [0.2, -0.18, -0.58 - armSwing],
      [0.1, 0.5 * arm, 0.084],
      seamGlow,
      skin,
    ),
    limb(
      "forearm-left",
      [-0.69 * shoulder, 0.12, 0.03],
      [0.12, 0.1, 0.22 + armSwing],
      [0.1, 0.45 * arm, 0.075],
      seamGlow,
      primary,
    ),
    limb(
      "forearm-right",
      [0.69 * shoulder, 0.12, 0.03],
      [0.12, -0.1, -0.22 - armSwing],
      [0.1, 0.45 * arm, 0.075],
      seamGlow,
      primary,
    ),
    joint(
      "elbow-left",
      [-0.61 * shoulder, 0.34, 0.06],
      seamGlow * 0.82,
      highlight,
    ),
    joint(
      "elbow-right",
      [0.61 * shoulder, 0.34, 0.06],
      seamGlow * 0.82,
      highlight,
    ),
    joint(
      "wrist-left",
      [-0.72 * shoulder, -0.24 * arm, 0.07],
      seamGlow * 0.58,
      highlight,
    ),
    joint(
      "wrist-right",
      [0.72 * shoulder, -0.24 * arm, 0.07],
      seamGlow * 0.58,
      highlight,
    ),
    joint(
      "shoulder-left",
      [-0.48 * shoulder, 1.1 + chestRise, 0.04],
      seamGlow,
      highlight,
    ),
    joint(
      "shoulder-right",
      [0.48 * shoulder, 1.1 + chestRise, 0.04],
      seamGlow,
      highlight,
    ),
    hand(
      "hand-left",
      [-0.75 * shoulder, -0.36 * arm, 0.08],
      [0.08, 0.04, 0.11],
      seamGlow,
      highlight,
    ),
    hand(
      "hand-right",
      [0.75 * shoulder, -0.36 * arm, 0.08],
      [0.08, 0.04, 0.11],
      seamGlow,
      highlight,
    ),
    limb(
      "thigh-left",
      [-0.19, -0.58, 0],
      [-0.02, 0, 0.1],
      [0.13, 0.66 * leg, 0.092],
      seamGlow,
      skin,
    ),
    limb(
      "thigh-right",
      [0.19, -0.58, 0],
      [-0.02, 0, -0.1],
      [0.13, 0.66 * leg, 0.092],
      seamGlow,
      skin,
    ),
    limb(
      "shin-left",
      [-0.17, -1.34 * leg, 0.02],
      [-0.01, 0, -0.02],
      [0.095, 0.64 * leg, 0.068],
      seamGlow,
      primary,
    ),
    limb(
      "shin-right",
      [0.17, -1.34 * leg, 0.02],
      [-0.01, 0, 0.02],
      [0.095, 0.64 * leg, 0.068],
      seamGlow,
      primary,
    ),
    joint("knee-left", [-0.19, -0.94 * leg, 0.08], seamGlow, highlight),
    joint("knee-right", [0.19, -0.94 * leg, 0.08], seamGlow, highlight),
    hand(
      "foot-left",
      [-0.16, -1.96 * leg, 0.14],
      [0.13, 0.038, 0.18],
      seamGlow * 0.8,
      highlight,
    ),
    hand(
      "foot-right",
      [0.16, -1.96 * leg, 0.14],
      [0.13, 0.038, 0.18],
      seamGlow * 0.8,
      highlight,
    ),
  ];

  return parts
    .concat(
      createEnergySeams(
        config,
        shoulder,
        arm,
        leg,
        chestRise,
        turn,
        coreColor,
        seamGlow,
      ),
    )
    .concat(createFaceParts(config, headRise, turn, coreColor, seamGlow));
}

function limb(
  name: string,
  translate: Vec3,
  rotate: Vec3,
  scale: Vec3,
  glow: number,
  color: Vec3,
): Part {
  return {
    name,
    translate,
    rotate,
    scale,
    color,
    glow: glow * 0.24,
    material: 0.88,
  };
}

function joint(name: string, translate: Vec3, glow: number, color: Vec3): Part {
  return {
    name,
    translate,
    rotate: [0, 0, 0],
    scale: [0.055 + glow * 0.01, 0.055 + glow * 0.01, 0.055],
    color,
    glow: 0.95 + glow,
    material: 0.72,
  };
}

function hand(
  name: string,
  translate: Vec3,
  scale: Vec3,
  glow: number,
  color: Vec3,
): Part {
  return {
    name,
    translate,
    rotate: [0.02, 0, 0],
    scale,
    color,
    glow: 0.42 + glow * 0.5,
    material: 0.72,
  };
}

function createEnergySeams(
  config: AtlasAvatarConfig,
  shoulder: number,
  arm: number,
  leg: number,
  chestRise: number,
  turn: number,
  color: Vec3,
  glow: number,
): Part[] {
  const seamScale = 0.62 + config.energySeamIntensity * 0.38;
  const seamGlow = 0.28 + glow * 0.82;

  return [
    seam(
      "forehead-seam",
      [0, 1.985 + chestRise * 0.22, 0.215],
      [0.012, 0.07, 0.009],
      turn,
      color,
      seamGlow,
    ),
    seam(
      "throat-seam",
      [0, 1.46 + chestRise * 0.38, 0.13],
      [0.018, 0.08, 0.012],
      turn,
      color,
      seamGlow * 0.72,
    ),
    seam(
      "sternum-seam",
      [0, 1.08 + chestRise, 0.225],
      [0.018, 0.18, 0.014],
      turn,
      color,
      seamGlow,
    ),
    seam(
      "abdomen-seam",
      [0, 0.39 + chestRise, 0.205],
      [0.014, 0.22, 0.012],
      turn,
      color,
      seamGlow * 0.68,
    ),
    seam(
      "left-clavicle",
      [-0.24 * shoulder, 1.16 + chestRise, 0.155],
      [0.09 * shoulder, 0.014, 0.01],
      turn - 0.18,
      color,
      seamGlow * 0.58,
    ),
    seam(
      "right-clavicle",
      [0.24 * shoulder, 1.16 + chestRise, 0.155],
      [0.09 * shoulder, 0.014, 0.01],
      turn + 0.18,
      color,
      seamGlow * 0.58,
    ),
    seam(
      "left-forearm-seam",
      [-0.69 * shoulder, 0.08, 0.105],
      [0.012, 0.19 * arm, 0.008],
      turn + 0.1,
      color,
      seamGlow * 0.48,
    ),
    seam(
      "right-forearm-seam",
      [0.69 * shoulder, 0.08, 0.105],
      [0.012, 0.19 * arm, 0.008],
      turn - 0.1,
      color,
      seamGlow * 0.48,
    ),
    seam(
      "left-thigh-seam",
      [-0.16, -0.72 * leg, 0.1],
      [0.012, 0.22 * leg, 0.008],
      turn + 0.08,
      color,
      seamGlow * 0.45,
    ),
    seam(
      "right-thigh-seam",
      [0.16, -0.72 * leg, 0.1],
      [0.012, 0.22 * leg, 0.008],
      turn - 0.08,
      color,
      seamGlow * 0.45,
    ),
    seam(
      "left-shin-seam",
      [-0.14, -1.46 * leg, 0.09],
      [0.01, 0.19 * leg, 0.008],
      turn + 0.04,
      color,
      seamGlow * 0.42,
    ),
    seam(
      "right-shin-seam",
      [0.14, -1.46 * leg, 0.09],
      [0.01, 0.19 * leg, 0.008],
      turn - 0.04,
      color,
      seamGlow * 0.42,
    ),
  ].map((part) => ({
    ...part,
    scale: [
      part.scale[0] * seamScale,
      part.scale[1] * seamScale,
      part.scale[2],
    ] as Vec3,
  }));
}

function seam(
  name: string,
  translate: Vec3,
  scale: Vec3,
  turn: number,
  color: Vec3,
  glow: number,
): Part {
  return {
    name,
    translate,
    rotate: [0.02, turn, 0],
    scale,
    color,
    glow,
    material: 0.58,
  };
}

function createFaceParts(
  config: AtlasAvatarConfig,
  headRise: number,
  turn: number,
  coreColor: Vec3,
  glow: number,
): Part[] {
  const y = 1.93 + headRise;
  if (config.eyeStyle === "thin-visor") {
    return [
      {
        name: "visor",
        translate: [0, y, 0.206],
        rotate: [0, turn, 0],
        scale: [0.095, 0.012, 0.012],
        color: coreColor,
        glow: 0.78 + glow * 0.9,
        material: 0.65,
      },
    ];
  }

  if (config.eyeStyle === "dual-pin") {
    return [
      {
        name: "eye-left",
        translate: [-0.052, y + 0.004, 0.208],
        rotate: [0, turn, 0],
        scale: [0.024, 0.024, 0.012],
        color: coreColor,
        glow: 0.8 + glow * 0.72,
        material: 0.64,
      },
      {
        name: "eye-right",
        translate: [0.052, y + 0.004, 0.208],
        rotate: [0, turn, 0],
        scale: [0.024, 0.024, 0.012],
        color: coreColor,
        glow: 0.8 + glow * 0.72,
        material: 0.64,
      },
      ...(config.facialDetail === "central-ridge"
        ? [
            {
              name: "face-ridge",
              translate: [0, y - 0.086, 0.202],
              rotate: [0, turn, 0],
              scale: [0.014, 0.09, 0.01],
              color: IVORY_GOLD,
              glow: 0.26 + glow * 0.35,
              material: 0.76,
            } satisfies Part,
          ]
        : []),
    ];
  }

  return [
    {
      name: "single-sensor",
      translate: [0, y, 0.208],
      rotate: [0, turn, 0],
      scale: [0.04 + glow * 0.006, 0.04 + glow * 0.006, 0.014],
      color: coreColor,
      glow: 0.74 + glow * 0.55,
      material: 0.72,
    },
  ];
}

function materialColor(material: AtlasMaterialId): Vec3 {
  if (material === "graphite") return DEEP_GRAPHITE;
  if (material === "gold") return JOINT_GOLD;
  if (material === "ivory") return IVORY_GOLD;
  return GLASS_BLACK;
}

function getStateConfig(state: AtlasState) {
  switch (state) {
    case "listening":
      return { glow: 0.62, speed: 1.25 };
    case "thinking":
      return { glow: 0.48, speed: 1.6 };
    case "speaking":
      return { glow: 0.72, speed: 1.45 };
    case "success":
      return { glow: 0.74, speed: 1.85 };
    case "attention":
      return { glow: 0.42, speed: 0.85 };
    case "error":
      return { glow: 0.32, speed: 0.65 };
    case "idle":
    default:
      return { glow: 0.18, speed: 0.8 };
  }
}

function getIntensity(intensity: AtlasVisualIntensity) {
  if (intensity === "minimal") return 0.64;
  if (intensity === "radiant") return 1.28;
  return 1;
}

function hexToVector(hex: string): Vec3 {
  const normalized = /^#[0-9a-f]{6}$/i.test(hex) ? hex : "#d9b45f";
  const value = normalized.slice(1);
  return [
    parseInt(value.slice(0, 2), 16) / 255,
    parseInt(value.slice(2, 4), 16) / 255,
    parseInt(value.slice(4, 6), 16) / 255,
  ];
}

function createViewProjection(aspect: number, cameraPosition: Vec3): Mat4 {
  const projection = perspective(Math.PI / 5.4, aspect, 0.1, 18);
  const view = lookAt(cameraPosition, [0, -0.02, 0], [0, 1, 0]);
  return multiply(projection, view);
}

function composeMatrix(translate: Vec3, rotate: Vec3, scale: Vec3): Mat4 {
  let matrix = identity();
  matrix = multiply(matrix, translation(translate));
  matrix = multiply(matrix, rotationY(rotate[1]));
  matrix = multiply(matrix, rotationX(rotate[0]));
  matrix = multiply(matrix, rotationZ(rotate[2]));
  matrix = multiply(matrix, scaling(scale));
  return matrix;
}

function identity(): Mat4 {
  return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
}

function translation([x, y, z]: Vec3): Mat4 {
  return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1]);
}

function scaling([x, y, z]: Vec3): Mat4 {
  return new Float32Array([x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1]);
}

function rotationX(angle: number): Mat4 {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return new Float32Array([1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]);
}

function rotationY(angle: number): Mat4 {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return new Float32Array([c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]);
}

function rotationZ(angle: number): Mat4 {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return new Float32Array([c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
}

function perspective(
  fieldOfView: number,
  aspect: number,
  near: number,
  far: number,
): Mat4 {
  const f = 1 / Math.tan(fieldOfView / 2);
  const rangeInv = 1 / (near - far);
  return new Float32Array([
    f / aspect,
    0,
    0,
    0,
    0,
    f,
    0,
    0,
    0,
    0,
    (near + far) * rangeInv,
    -1,
    0,
    0,
    near * far * rangeInv * 2,
    0,
  ]);
}

function lookAt(eye: Vec3, target: Vec3, up: Vec3): Mat4 {
  const zAxis = normalize([
    eye[0] - target[0],
    eye[1] - target[1],
    eye[2] - target[2],
  ]);
  const xAxis = normalize(cross(up, zAxis));
  const yAxis = cross(zAxis, xAxis);

  return new Float32Array([
    xAxis[0],
    yAxis[0],
    zAxis[0],
    0,
    xAxis[1],
    yAxis[1],
    zAxis[1],
    0,
    xAxis[2],
    yAxis[2],
    zAxis[2],
    0,
    -dot(xAxis, eye),
    -dot(yAxis, eye),
    -dot(zAxis, eye),
    1,
  ]);
}

function multiply(a: Mat4, b: Mat4): Mat4 {
  const out = new Float32Array(16);
  for (let row = 0; row < 4; row += 1) {
    for (let column = 0; column < 4; column += 1) {
      out[column * 4 + row] =
        a[0 * 4 + row] * b[column * 4 + 0] +
        a[1 * 4 + row] * b[column * 4 + 1] +
        a[2 * 4 + row] * b[column * 4 + 2] +
        a[3 * 4 + row] * b[column * 4 + 3];
    }
  }
  return out;
}

function normalize([x, y, z]: Vec3): Vec3 {
  const length = Math.hypot(x, y, z) || 1;
  return [x / length, y / length, z / length];
}

function cross(a: Vec3, b: Vec3): Vec3 {
  return [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
}

function dot(a: Vec3, b: Vec3): number {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

function cleanupResources(resources: RendererResources) {
  const { gl, program, mesh } = resources;
  gl.deleteBuffer(mesh.vertexBuffer);
  gl.deleteBuffer(mesh.normalBuffer);
  gl.deleteBuffer(mesh.indexBuffer);
  gl.deleteProgram(program);
}
