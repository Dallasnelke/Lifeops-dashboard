import assert from "node:assert/strict";
import test from "node:test";
import {
  buildHistoryItem,
  createLocalMission,
  lifeScanSchema,
  missionSchema,
  rescueMission,
  simplifyMission,
  storedMissionStateSchema,
} from "../lib/missions";

const scan = lifeScanSchema.parse({
  situation: "Finish the first section of my application before work.",
  energy: "low",
  availableMinutes: 25,
  derailment: "I keep trying to perfect the wording.",
});

test("local mission planner creates a bounded actionable mission", () => {
  const mission = createLocalMission(
    scan,
    "2026-08-09T12:00:00.000Z",
    "mission-1",
  );

  assert.equal(mission.id, "mission-1");
  assert.equal(mission.status, "ready");
  assert.equal(mission.source, "local-planner");
  assert.equal(mission.estimatedMinutes, 15);
  assert.equal(mission.difficulty, "light");
  assert.equal(mission.risk, "medium");
  assert.ok(mission.firstStep.includes("begin"));
  assert.equal(mission.evidence.length, 3);
});

test("make easier reduces time and promotes the fallback", () => {
  const mission = createLocalMission(scan, "2026-08-09T12:00:00.000Z", "m1");
  const easier = simplifyMission({ ...mission, estimatedMinutes: 25 });

  assert.equal(easier.firstStep, mission.fallback);
  assert.equal(easier.estimatedMinutes, 13);
  assert.equal(easier.difficulty, "light");
  assert.equal(easier.status, "ready");
});

test("rescue mode preserves evidence and records the disruption", () => {
  const mission = createLocalMission(scan, "2026-08-09T12:00:00.000Z", "m1");
  const rescued = rescueMission(
    mission,
    "A meeting used half of my available time.",
    "2026-08-09T12:30:00.000Z",
  );

  assert.equal(rescued.rescueCount, 1);
  assert.equal(rescued.status, "ready");
  assert.equal(rescued.source, "local-planner");
  assert.ok(rescued.why.includes("meeting"));
  assert.ok(rescued.evidence.some((item) => item.includes("meeting")));
});

test("completed missions become validated local history", () => {
  const mission = missionSchema.parse({
    ...createLocalMission(scan, "2026-08-09T12:00:00.000Z", "m1"),
    status: "completed",
    completedAt: "2026-08-09T12:20:00.000Z",
  });
  const history = buildHistoryItem(
    mission,
    "Starting with five minutes removed the pressure.",
    "Perfectionism",
  );
  const stored = storedMissionStateSchema.parse({
    current: null,
    history: [history],
  });

  assert.equal(stored.history[0].status, "completed");
  assert.equal(stored.history[0].obstacle, "Perfectionism");
  assert.equal(stored.history[0].completedAt, mission.completedAt);
});

