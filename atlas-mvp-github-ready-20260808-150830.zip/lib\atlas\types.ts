﻿export type AtlasState =
  "idle" | "thinking" | "listening" | "speaking" | "error";

export type MessageRole = "user" | "assistant";

export type ConversationMessage = {
  id: string;
  role: MessageRole;
  content: string;
  createdAt: string;
  status?: "streaming" | "complete" | "error";
};

export type AtlasForm =
  "orb" | "emblem" | "humanoid" | "pet" | "spirit" | "robot";
export type AtlasPersonality =
  "calm-strategist" | "warm-coach" | "direct-adviser" | "curious-collaborator";
export type AtlasCoachingStyle =
  "concise" | "balanced" | "reflective" | "step-by-step";

export type AtlasPreferences = {
  name: string;
  form: AtlasForm;
  personality: AtlasPersonality;
  coachingStyle: AtlasCoachingStyle;
  accentColor: string;
  speechEnabled: boolean;
  localMemoryEnabled: boolean;
};

export type AtlasRequestHistoryItem = {
  role: MessageRole;
  content: string;
};

export type AtlasRequest = {
  conversationId: string;
  message: string;
  history: AtlasRequestHistoryItem[];
  preferences: {
    personality: AtlasPersonality;
    coachingStyle: AtlasCoachingStyle;
    atlasName: string;
  };
};

export type LifeOpsSignal = {
  label: string;
  value: string;
  source: string;
  freshness?: string;
  privacy?: "Private" | "Personal" | "Shared" | "Sensitive";
};

export type LifeOpsContext = {
  version: 1;
  generatedAt: string;
  source: "lifeops-local-bridge";
  profileName?: string;
  currentPriority?: string;
  todayPlan: LifeOpsSignal[];
  bills: LifeOpsSignal[];
  goals: LifeOpsSignal[];
  habits: LifeOpsSignal[];
  health: LifeOpsSignal[];
  calendar: LifeOpsSignal[];
  command?: {
    priority?: string;
    recommendedAction?: string;
    reason?: string;
    evidence: string[];
    estimatedTime?: string;
    riskIfIgnored?: string;
  };
  limits: {
    readOnly: boolean;
    exactSensitiveAmountsRemoved: boolean;
    generatedLocally: boolean;
  };
};
