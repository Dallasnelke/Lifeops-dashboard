﻿import { z } from "zod";

const contextText = z.string().trim().max(240).default("");
const contextShortText = z.string().trim().max(96).default("");
const statusText = z.string().trim().max(64).default("");

export const lifeOpsSignalSchema = z.object({
  label: contextShortText,
  value: contextText,
  source: contextShortText,
  freshness: statusText.optional().default("local"),
  privacy: z
    .enum(["Private", "Personal", "Shared", "Sensitive"])
    .optional()
    .default("Personal"),
});

export const lifeOpsContextSchema = z.object({
  version: z.literal(1).default(1),
  generatedAt: z.string().trim().max(40).default(""),
  source: z.literal("lifeops-local-bridge").default("lifeops-local-bridge"),
  profileName: contextShortText.optional().default(""),
  currentPriority: contextText.optional().default(""),
  todayPlan: z.array(lifeOpsSignalSchema).max(5).default([]),
  bills: z.array(lifeOpsSignalSchema).max(5).default([]),
  goals: z.array(lifeOpsSignalSchema).max(5).default([]),
  habits: z.array(lifeOpsSignalSchema).max(5).default([]),
  health: z.array(lifeOpsSignalSchema).max(5).default([]),
  calendar: z.array(lifeOpsSignalSchema).max(5).default([]),
  command: z
    .object({
      priority: contextText.optional().default(""),
      recommendedAction: contextText.optional().default(""),
      reason: z.string().trim().max(500).optional().default(""),
      evidence: z.array(contextText).max(5).default([]),
      estimatedTime: statusText.optional().default(""),
      riskIfIgnored: statusText.optional().default(""),
    })
    .optional(),
  limits: z
    .object({
      readOnly: z.boolean().default(true),
      exactSensitiveAmountsRemoved: z.boolean().default(true),
      generatedLocally: z.boolean().default(true),
    })
    .default({
      readOnly: true,
      exactSensitiveAmountsRemoved: true,
      generatedLocally: true,
    }),
});

export type LifeOpsSignal = z.infer<typeof lifeOpsSignalSchema>;
export type LifeOpsContext = z.infer<typeof lifeOpsContextSchema>;

function linesFromSignals(title: string, signals: LifeOpsSignal[]): string[] {
  if (!signals.length) return [];
  return [
    `${title}:`,
    ...signals.map(
      (signal) =>
        `- ${signal.label}: ${signal.value || "No detail"} (${signal.source}; ${signal.freshness || "local"})`,
    ),
  ];
}

export function summarizeLifeOpsContext(context: LifeOpsContext): string {
  const rows = [
    "Read-only LifeOps context snapshot:",
    `Generated: ${context.generatedAt || "local session"}`,
    context.profileName ? `User name: ${context.profileName}` : "",
    context.currentPriority
      ? `Current priority: ${context.currentPriority}`
      : "",
    context.command?.priority ? "Current Atlas Command:" : "",
    context.command?.priority ? `- Priority: ${context.command.priority}` : "",
    context.command?.recommendedAction
      ? `- Recommended action: ${context.command.recommendedAction}`
      : "",
    context.command?.estimatedTime
      ? `- Estimated time: ${context.command.estimatedTime}`
      : "",
    context.command?.riskIfIgnored
      ? `- Risk if ignored: ${context.command.riskIfIgnored}`
      : "",
    context.command?.reason ? `- Reason: ${context.command.reason}` : "",
    ...(context.command?.evidence?.length
      ? [
          "- Evidence:",
          ...context.command.evidence.map((item) => `  - ${item}`),
        ]
      : []),
    ...linesFromSignals("Today's plan", context.todayPlan),
    ...linesFromSignals("Bills and money", context.bills),
    ...linesFromSignals("Goals", context.goals),
    ...linesFromSignals("Habits", context.habits),
    ...linesFromSignals("Health", context.health),
    ...linesFromSignals("Calendar", context.calendar),
    "Limits: read-only context; do not claim you changed LifeOps data unless the UI explicitly reports that action succeeded.",
  ];
  return rows.filter(Boolean).join("\n").slice(0, 6000);
}
