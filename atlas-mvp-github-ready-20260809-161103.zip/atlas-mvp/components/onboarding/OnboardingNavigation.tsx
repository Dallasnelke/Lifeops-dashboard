import { getStepIndex } from "@/lib/onboarding/profile";
import type { OnboardingStepId } from "@/lib/onboarding/types";

export function OnboardingNavigation({
  currentStep,
  onBack,
  onNext,
  onSkip,
  nextLabel = "Continue",
  nextDisabled = false,
}: {
  currentStep: OnboardingStepId;
  onBack: () => void;
  onNext: () => void;
  onSkip: () => void;
  nextLabel?: string;
  nextDisabled?: boolean;
}) {
  const isFirst = getStepIndex(currentStep) === 0;
  return (
    <div className="setup-actions">
      {!isFirst && (
        <button type="button" onClick={onBack}>
          Back
        </button>
      )}
      <button type="button" onClick={onSkip}>
        Skip for now
      </button>
      <button
        className="primary"
        type="button"
        onClick={onNext}
        disabled={nextDisabled}
      >
        {nextLabel}
      </button>
    </div>
  );
}
