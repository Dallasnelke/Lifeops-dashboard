"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { useAtlasSpeechRecognition } from "@/hooks/useAtlasSpeechRecognition";
import type { AtlasState } from "@/lib/atlas/types";
import {
  buildHistoryItem,
  lifeScanSchema,
  missionSchema,
  missionStorage,
  simplifyMission,
  type LifeScan,
  type Mission,
  type StoredMissionState,
} from "@/lib/missions";

type Props = {
  open: boolean;
  onClose: () => void;
  onAtlasStateChange: (state: AtlasState) => void;
  onOpenChat: () => void;
};

const initialScan: LifeScan = {
  situation: "",
  energy: "steady",
  availableMinutes: 25,
  derailment: "",
};

function missionStatusLabel(mission: Mission): string {
  if (mission.status === "active") return "Mission active";
  if (mission.status === "blocked") return "Rescue requested";
  if (mission.status === "completed") return "Mission complete";
  return "Mission ready";
}

export function MissionControl({
  open,
  onClose,
  onAtlasStateChange,
  onOpenChat,
}: Props) {
  const [stored, setStored] = useState<StoredMissionState>(() =>
    missionStorage.load(),
  );
  const [scan, setScan] = useState<LifeScan>(initialScan);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState("");
  const [rescueReason, setRescueReason] = useState("");
  const [reflection, setReflection] = useState("");
  const [obstacle, setObstacle] = useState("");
  const [nowMs, setNowMs] = useState(() => Date.now());
  const [notice, setNotice] = useState("");
  const [listening, setListening] = useState(false);
  const mission = stored.current;

  const speech = useAtlasSpeechRecognition(
    (value) => setScan((current) => ({ ...current, situation: value })),
    (active) => {
      setListening(active);
      onAtlasStateChange(active ? "listening" : "idle");
    },
  );

  useEffect(() => {
    missionStorage.save(stored);
  }, [stored]);

  useEffect(() => {
    if (mission?.status !== "active") return;
    const timer = window.setInterval(() => setNowMs(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [mission?.status]);

  useEffect(() => {
    if (!open) onAtlasStateChange("idle");
  }, [onAtlasStateChange, open]);

  const elapsedMinutes = mission?.startedAt
    ? Math.max(0, Math.floor((nowMs - Date.parse(mission.startedAt)) / 60_000))
    : 0;
  const completedCount = stored.history.filter(
    (item) => item.status === "completed",
  ).length;
  const completionRate = stored.history.length
    ? Math.round((completedCount / stored.history.length) * 100)
    : 0;
  const commonObstacle = useMemo(() => {
    const counts = new Map<string, number>();
    stored.history.forEach((item) => {
      const value = item.obstacle.trim();
      if (value) counts.set(value, (counts.get(value) || 0) + 1);
    });
    return [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || "";
  }, [stored.history]);

  async function requestMission(mode: "create" | "rescue", reason = "") {
    const parsedScan = lifeScanSchema.safeParse(scan);
    if (!parsedScan.success) {
      setError("Tell Atlas what is happening in at least a few words.");
      return;
    }
    setGenerating(true);
    setError("");
    setNotice("");
    onAtlasStateChange("thinking");
    try {
      const response = await fetch("/api/atlas/mission", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode,
          scan: parsedScan.data,
          currentMission: mode === "rescue" ? mission : undefined,
          rescueReason: reason,
        }),
      });
      const payload = (await response.json()) as {
        mission?: unknown;
        error?: string;
        fallback?: boolean;
      };
      if (!response.ok || !payload.mission)
        throw new Error(payload.error || "Atlas could not build the mission.");
      const nextMission = missionSchema.parse(payload.mission);
      setStored((current) => ({ ...current, current: nextMission }));
      setRescueReason("");
      setNotice(
        payload.fallback || nextMission.source === "local-planner"
          ? "Built locally. Add an OpenAI key for deeper personalization."
          : "Atlas used your Life Scan to build this mission.",
      );
      onAtlasStateChange("success");
    } catch (caught) {
      setError(
        caught instanceof Error
          ? caught.message
          : "Atlas could not build the mission.",
      );
      onAtlasStateChange("error");
    } finally {
      setGenerating(false);
    }
  }

  function submitScan(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void requestMission("create");
  }

  function updateMission(update: Partial<Mission>) {
    if (!mission) return;
    setStored((current) => ({
      ...current,
      current: missionSchema.parse({ ...mission, ...update }),
    }));
  }

  function startMission() {
    updateMission({ status: "active", startedAt: new Date().toISOString() });
    setNowMs(Date.now());
    onAtlasStateChange("attention");
  }

  function makeEasier() {
    if (!mission) return;
    setStored((current) => ({
      ...current,
      current: simplifyMission(mission),
    }));
    setNotice("Atlas reduced the mission to its smallest useful version.");
    onAtlasStateChange("success");
  }

  function completeMission() {
    updateMission({
      status: "completed",
      completedAt: new Date().toISOString(),
    });
    onAtlasStateChange("success");
  }

  function saveReview() {
    if (!mission) return;
    const item = buildHistoryItem(mission, reflection, obstacle);
    setStored((current) => ({
      current: null,
      history: [item, ...current.history].slice(0, 90),
    }));
    setReflection("");
    setObstacle("");
    setScan(initialScan);
    setNotice("Review saved. Atlas will use this pattern locally next time.");
    onAtlasStateChange("idle");
  }

  if (!open) return null;

  return (
    <div className="mission-backdrop" role="presentation">
      <section
        className="mission-control"
        role="dialog"
        aria-modal="true"
        aria-labelledby="mission-control-title"
      >
        <header className="mission-header">
          <div>
            <p className="eyebrow">Atlas Mission Control</p>
            <h1 id="mission-control-title">
              {mission ? missionStatusLabel(mission) : "What needs your attention?"}
            </h1>
          </div>
          <div className="mission-header-actions">
            <button type="button" onClick={onOpenChat}>Talk to Atlas</button>
            <button type="button" onClick={onClose}>Close</button>
          </div>
        </header>

        {notice && <p className="mission-notice" role="status">{notice}</p>}
        {error && <p className="mission-error" role="alert">{error}</p>}

        {!mission && (
          <div className="mission-scan-layout">
            <form className="life-scan-card" onSubmit={submitScan}>
              <div className="mission-section-heading">
                <span>01</span>
                <div>
                  <p className="eyebrow">Life Scan</p>
                  <h2>Give Atlas the unfiltered version.</h2>
                </div>
              </div>
              <label htmlFor="life-scan-situation">
                What is happening, and what is competing for your attention?
              </label>
              <textarea
                id="life-scan-situation"
                value={scan.situation}
                onChange={(event) =>
                  setScan((current) => ({
                    ...current,
                    situation: event.target.value,
                  }))
                }
                placeholder="I barely slept, work starts at noon, the apartment is a mess, and I keep avoiding my application..."
                rows={6}
                maxLength={1800}
              />
              <button
                className="mission-voice-button"
                type="button"
                onClick={speech.startListening}
                disabled={!speech.supported}
                aria-pressed={listening}
              >
                {listening ? "Listening..." : "Speak Life Scan"}
              </button>
              {speech.interimText && (
                <p className="mission-interim">{speech.interimText}</p>
              )}
              <div className="mission-field-grid">
                <fieldset>
                  <legend>Energy right now</legend>
                  <div className="mission-segmented">
                    {(["low", "steady", "high"] as const).map((energy) => (
                      <button
                        key={energy}
                        type="button"
                        className={scan.energy === energy ? "selected" : ""}
                        onClick={() => setScan((current) => ({ ...current, energy }))}
                      >
                        {energy}
                      </button>
                    ))}
                  </div>
                </fieldset>
                <label>
                  Time available
                  <select
                    value={scan.availableMinutes}
                    onChange={(event) =>
                      setScan((current) => ({
                        ...current,
                        availableMinutes: Number(event.target.value),
                      }))
                    }
                  >
                    <option value={10}>10 minutes</option>
                    <option value={25}>25 minutes</option>
                    <option value={45}>45 minutes</option>
                    <option value={60}>1 hour</option>
                    <option value={120}>2 hours</option>
                  </select>
                </label>
              </div>
              <label>
                What is most likely to derail you? <span>Optional</span>
                <input
                  value={scan.derailment}
                  onChange={(event) =>
                    setScan((current) => ({
                      ...current,
                      derailment: event.target.value,
                    }))
                  }
                  placeholder="Low energy, interruptions, uncertainty..."
                  maxLength={400}
                />
              </label>
              <button className="mission-primary" type="submit" disabled={generating}>
                {generating ? "Atlas is assessing..." : "Build my mission"}
              </button>
            </form>

            <aside className="mission-pattern-card">
              <p className="eyebrow">Local pattern memory</p>
              <strong>{stored.history.length}</strong>
              <span>missions reviewed</span>
              <div className="mission-pattern-stat">
                <b>{completionRate}%</b>
                <span>completion rate</span>
              </div>
              {commonObstacle && (
                <div className="mission-pattern-insight">
                  <span>Repeated friction</span>
                  <p>{commonObstacle}</p>
                </div>
              )}
              <p className="mission-privacy-note">
                Mission history stays in this browser. Atlas shows its evidence and never changes outside systems from this screen.
              </p>
            </aside>
          </div>
        )}

        {mission && mission.status !== "completed" && (
          <div className="mission-command-layout">
            <article className={`mission-command-card status-${mission.status}`}>
              <div className="mission-command-topline">
                <span>{mission.difficulty} mission</span>
                <span>{mission.estimatedMinutes} min</span>
                <span>{mission.risk} risk</span>
              </div>
              <p className="eyebrow">Primary command</p>
              <h2>{mission.title}</h2>
              <p className="mission-outcome">{mission.outcome}</p>
              <div className="mission-first-step">
                <span>Start here</span>
                <strong>{mission.firstStep}</strong>
              </div>
              {mission.status === "active" && (
                <div className="mission-progress" role="timer">
                  <div>
                    <span>Elapsed</span>
                    <strong>{elapsedMinutes} min</strong>
                  </div>
                  <div className="mission-progress-track">
                    <span
                      style={{
                        width: `${Math.min(100, (elapsedMinutes / mission.estimatedMinutes) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              )}
              <div className="mission-actions">
                {mission.status !== "active" ? (
                  <button className="mission-primary" type="button" onClick={startMission}>
                    Start mission
                  </button>
                ) : (
                  <button className="mission-primary" type="button" onClick={completeMission}>
                    Mission complete
                  </button>
                )}
                <button type="button" onClick={makeEasier}>Make easier</button>
                <button
                  type="button"
                  onClick={() => updateMission({ status: "blocked" })}
                >
                  I&apos;m blocked
                </button>
              </div>
            </article>

            <aside className="mission-evidence-card">
              <p className="eyebrow">Why this move</p>
              <p>{mission.why}</p>
              <ul>
                {mission.evidence.map((item) => <li key={item}>{item}</li>)}
              </ul>
              <div className="mission-fallback">
                <span>Five-minute fallback</span>
                <p>{mission.fallback}</p>
              </div>
              <span className="mission-source">
                {mission.source === "atlas-ai" ? "Generated by Atlas AI" : "Generated by local planner"}
              </span>
            </aside>

            {mission.status === "blocked" && (
              <section className="mission-rescue-card">
                <p className="eyebrow">Rescue Mode</p>
                <h2>What changed?</h2>
                <p>Atlas will protect the outcome and reduce the friction.</p>
                <textarea
                  value={rescueReason}
                  onChange={(event) => setRescueReason(event.target.value)}
                  placeholder="I lost time, my energy dropped, or the first step is unclear..."
                  rows={3}
                  maxLength={500}
                />
                <div className="mission-actions">
                  <button
                    className="mission-primary"
                    type="button"
                    disabled={generating}
                    onClick={() => void requestMission("rescue", rescueReason)}
                  >
                    {generating ? "Rebuilding..." : "Rebuild the mission"}
                  </button>
                  <button type="button" onClick={makeEasier}>Use fallback now</button>
                </div>
              </section>
            )}
          </div>
        )}

        {mission?.status === "completed" && (
          <section className="mission-review-card">
            <p className="eyebrow">Evening review</p>
            <h2>Close the loop while it is fresh.</h2>
            <p>{mission.title}</p>
            <label>
              What worked?
              <textarea
                value={reflection}
                onChange={(event) => setReflection(event.target.value)}
                rows={3}
                maxLength={500}
                placeholder="Starting small helped, the timing was right..."
              />
            </label>
            <label>
              What created friction?
              <input
                value={obstacle}
                onChange={(event) => setObstacle(event.target.value)}
                maxLength={300}
                placeholder="Interruptions, unclear next step, low energy..."
              />
            </label>
            <button className="mission-primary" type="button" onClick={saveReview}>
              Save review and prepare tomorrow
            </button>
          </section>
        )}
      </section>
    </div>
  );
}
