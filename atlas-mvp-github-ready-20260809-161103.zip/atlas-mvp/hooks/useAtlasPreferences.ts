"use client";

import { useState } from "react";
import { atlasStorage, defaultPreferences } from "@/lib/atlas/storage";
import type { AtlasPreferences } from "@/lib/atlas/types";

export function useAtlasPreferences() {
  const [preferences, setPreferences] = useState<AtlasPreferences>(
    () => atlasStorage.load()?.preferences ?? defaultPreferences,
  );

  return { preferences, setPreferences };
}
