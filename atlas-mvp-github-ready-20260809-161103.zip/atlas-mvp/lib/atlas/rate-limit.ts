type Bucket = {
  count: number;
  resetAt: number;
};

const buckets = new Map<string, Bucket>();
const LIMIT = 18;
const WINDOW_MS = 60_000;

export function checkRateLimit(
  identifier: string,
  now = Date.now(),
): { allowed: boolean; remaining: number; resetAt: number } {
  const key = identifier || "local";
  const current = buckets.get(key);
  if (!current || current.resetAt <= now) {
    const resetAt = now + WINDOW_MS;
    buckets.set(key, { count: 1, resetAt });
    return { allowed: true, remaining: LIMIT - 1, resetAt };
  }
  if (current.count >= LIMIT) {
    return { allowed: false, remaining: 0, resetAt: current.resetAt };
  }
  current.count += 1;
  return {
    allowed: true,
    remaining: LIMIT - current.count,
    resetAt: current.resetAt,
  };
}

export function resetRateLimitForTests(): void {
  buckets.clear();
}
