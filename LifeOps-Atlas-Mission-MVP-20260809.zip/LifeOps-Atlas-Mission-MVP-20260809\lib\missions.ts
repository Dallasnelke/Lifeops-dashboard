import { z } from "zod";

export const energySchema = z.enum(["low", "steady", "high"]);
export const missionStatusSchema = z.enum([
  "ready",
  "active",
  "blocked",
  "completed",
]);

export const lifeScanSchema = z.object({
  situation: z.string().trim().min(3).max(1800),
  energy: energySchema,
  availableMinutes: z.number().int().min(5).max(240),
  derailment: z.string().trim().max(400).default(""),
});

export const missionSchema = z.object({
  id: z.string().trim().min(1).max(120),
  createdAt: z.string().trim().min(1).max(40),
  title: z.string().trim().min(3).max(100),
  outcome: z.string().trim().min(3).max(220),
  firstStep: z.string().trim().min(3).max(220),
  why: z.string().trim().min(3).max(400),
  evidence: z.array(z.string().trim().min(1).max(180)).max(4),
  estimatedMinutes: z.number().int().min(5).max(240),
  difficulty: z.enum(["light", "focused", "deep"]),
  risk: z.enum(["low", "medium", "high"]),
  fallback: z.string().trim().min(3).max(220),
  status: missionStatusSchema,
  source: z.enum(["atlas-ai", "local-planner"]),
  startedAt: z.string().trim().max(40).optional(),
  completedAt: z.string().trim().max(40).optional(),
  rescueCount: z.number().int().min(0).max(20).default(0),
});

export const missionHistoryItemSchema = z.object({
  id: z.string().trim().min(1).max(120),
  missionTitle: z.string().trim().min(1).max(100),
  status: z.enum(["completed", "blocked"]),
  reflection: z.string().trim().max(500),
  obstacle: z.string().trim().max(300),
  completedAt: z.string().trim().min(1).max(40),
});

export const storedMissionStateSchema = z.object({
  current: missionSchema.nullable(),
  history: z.array(missionHistoryItemSchema).max(90),
});

export const missionRequestSchema = z.object({
  mode: z.enum(["create", "rescue"]).default("create"),
  scan: lifeScanSchema,
  currentMission: missionSchema.optional(),
  rescueReason: z.string().trim().max(500).default(""),
});

export type LifeScan = z.infer<typeof lifeScanSchema>;
export type Mission = z.infer<typeof missionSchema>;
export type MissionHistoryItem = z.infer<typeof missionHistoryItemSchema>;
export type StoredMissionState = z.infer<typeof storedMissionStateSchema>;

export const MISSION_STORAGE_KEY = "lifeops-atlas-missions-v1";

export function createLocalMission(
  scan: LifeScan,
  now = new Date().toISOString(),
  id = crypto.randomUUID(),
): Mission {
  const opening = scan.situation
    .split(/[.!?\n]/)
    .map((part) => part.trim())
    .find(Boolean) || "Move the day forward";
  const minutes = Math.max(
    5,
    Math.min(scan.availableMinutes, scan.energy === "low" ? 15 : 30),
  );
  const title = opening.length > 64 ? `${opening.slice(0, 61)}...` : opening;

  return missionSchema.parse({
    id,
    createdAt: now,
    title,
    outcome: `Create visible progress on: ${opening}`,
    firstStep: `Spend ${Math.min(5, minutes)} minutes defining the smallest finishable step, then begin it.`,
    why: "A bounded action reduces decision load and creates evidence about what should happen next.",
    evidence: [
      `You have ${scan.availableMinutes} minutes available.`,
      `Your reported energy is ${scan.energy}.`,
      scan.derailment ? `Likely disruption: ${scan.derailment}` : "No specific disruption was reported.",
    ],
    estimatedMinutes: minutes,
    difficulty: scan.energy === "high" && minutes >= 25 ? "focused" : "light",
    risk: scan.derailment ? "medium" : "low",
    fallback: "Work for five minutes and leave a clear note describing the next step.",
    status: "ready",
    source: "local-planner",
    rescueCount: 0,
  });
}

export function simplifyMission(mission: Mission): Mission {
  return missionSchema.parse({
    ...mission,
    firstStep: mission.fallback,
    outcome: `Make a smaller visible move on: ${mission.title}`,
    estimatedMinutes: Math.max(5, Math.ceil(mission.estimatedMinutes / 2)),
    difficulty: "light",
    status: "ready",
  });
}

export function rescueMission(
  current: Mission,
  reason: string,
  now = new Date().toISOString(),
): Mission {
  const simplified = simplifyMission(current);
  return missionSchema.parse({
    ...simplified,
    id: crypto.randomUUID(),
    createdAt: now,
    why: reason.trim()
      ? `The original plan changed because: ${reason.trim()}. This version protects momentum with less friction.`
      : "The original plan became difficult. This version protects momentum with less friction.",
    evidence: [
      ...current.evidence.slice(0, 2),
      reason.trim() || "The original mission was reported as blocked.",
    ],
    rescueCount: current.rescueCount + 1,
    source: "local-planner",
  });
}

export function buildHistoryItem(
  mission: Mission,
  reflection: string,
  obstacle: string,
  now = new Date().toISOString(),
): MissionHistoryItem {
  return missionHistoryItemSchema.parse({
    id: mission.id,
    missionTitle: mission.title,
    status: mission.status === "completed" ? "completed" : "blocked",
    reflection,
    obstacle,
    completedAt: mission.completedAt || now,
  });
}

function canUseStorage(): boolean {
  try {
    return typeof window !== "undefined" && Boolean(window.localStorage);
  } catch {
    return false;
  }
}

export const missionStorage = {
  load(): StoredMissionState {
    const empty: StoredMissionState = { current: null, history: [] };
    if (!canUseStorage()) return empty;
    try {
      const raw = window.localStorage.getItem(MISSION_STORAGE_KEY);
      return raw
        ? storedMissionStateSchema.catch(empty).parse(JSON.parse(raw))
        : empty;
    } catch {
      return empty;
    }
  },
  save(value: StoredMissionState): boolean {
    if (!canUseStorage()) return false;
    try {
      window.localStorage.setItem(
        MISSION_STORAGE_KEY,
        JSON.stringify(storedMissionStateSchema.parse(value)),
      );
      return true;
    } catch {
      return false;
    }
  },
  clear(): void {
    if (canUseStorage()) window.localStorage.removeItem(MISSION_STORAGE_KEY);
  },
};

export const missionJsonSchema = {
  type: "object",
  additionalProperties: false,
  required: [
    "title",
    "outcome",
    "firstStep",
    "why",
    "evidence",
    "estimatedMinutes",
    "difficulty",
    "risk",
    "fallback",
  ],
  properties: {
    title: { type: "string", minLength: 3, maxLength: 100 },
    outcome: { type: "string", minLength: 3, maxLength: 220 },
    firstStep: { type: "string", minLength: 3, maxLength: 220 },
    why: { type: "string", minLength: 3, maxLength: 400 },
    evidence: {
      type: "array",
      maxItems: 4,
      items: { type: "string", minLength: 1, maxLength: 180 },
    },
    estimatedMinutes: { type: "integer", minimum: 5, maximum: 240 },
    difficulty: { type: "string", enum: ["light", "focused", "deep"] },
    risk: { type: "string", enum: ["low", "medium", "high"] },
    fallback: { type: "string", minLength: 3, maxLength: 220 },
  },
} as const;

