import type { OnboardingStepId } from "./types";

export const onboardingCopy: Record<
  OnboardingStepId,
  {
    eyebrow: string;
    title: string;
    helper: string;
    atlasLine: string;
  }
> = {
  "meet-atlas": {
    eyebrow: "Meet Atlas",
    title: "Eat toward your goal without the spreadsheet.",
    helper:
      "Atlas starts with a few signals, then builds one practical food move.",
    atlasLine:
      "I can help with nutrition habits and body-composition goals. I do not diagnose, treat, or replace a professional.",
  },
  identity: {
    eyebrow: "Identity",
    title: "What should Atlas call you?",
    helper: "Use a preferred name. This stays local in your browser.",
    atlasLine: "A name keeps coaching personal without requiring an account.",
  },
  "nutrition-goal": {
    eyebrow: "Nutrition Goal",
    title: "What are you eating toward?",
    helper: "Choose the closest goal. You can change it later.",
    atlasLine: "Atlas uses your goal to suggest the next useful food action.",
  },
  "body-baseline": {
    eyebrow: "Body Baseline",
    title: "Share only what you want.",
    helper:
      "Age, height, and weight are optional. Atlas can still work without them.",
    atlasLine: "Body data is sensitive. It stays optional and off by default.",
  },
  "eating-style": {
    eyebrow: "Eating Style",
    title: "What style would actually fit your life?",
    helper: "Pick the approach you could repeat on a normal week.",
    atlasLine: "The best plan is the one you can execute consistently.",
  },
  "food-preferences": {
    eyebrow: "Food Preferences",
    title: "What should Atlas consider?",
    helper: "Add foods, limits, budget, and cooking access if helpful.",
    atlasLine: "Preferences make suggestions more realistic and less generic.",
  },
  "daily-rhythm": {
    eyebrow: "Daily Rhythm",
    title: "When does food usually happen?",
    helper: "Use rough defaults. Precision can come later.",
    atlasLine: "Timing helps Atlas avoid plans that fight your actual day.",
  },
  challenges: {
    eyebrow: "Common Challenges",
    title: "What usually gets in the way?",
    helper: "Choose any that fit. This is not a diagnosis.",
    atlasLine: "Atlas uses friction points to lower difficulty, not to judge.",
  },
  tracking: {
    eyebrow: "Tracking",
    title: "How much tracking feels sustainable?",
    helper: "Start light. You can become more detailed later.",
    atlasLine: "Useful tracking should reduce confusion, not create pressure.",
  },
  personality: {
    eyebrow: "Atlas Personality",
    title: "How should Atlas coach?",
    helper: "Choose the communication style that would help you move.",
    atlasLine: "Tone changes guidance. It does not change safety limits.",
  },
  character: {
    eyebrow: "Atlas Appearance",
    title: "Shape the prototype.",
    helper: "This is a configurable prototype, not final character art.",
    atlasLine: "The renderer is built so better models can replace it later.",
  },
  voice: {
    eyebrow: "Voice",
    title: "Choose the voice direction.",
    helper: "Voice is optional. Browser support varies.",
    atlasLine: "Voice stays optional and can be disabled at any time.",
  },
  memory: {
    eyebrow: "Memory and Privacy",
    title: "What may Atlas remember?",
    helper: "Sensitive categories stay off unless you turn them on.",
    atlasLine: "You can review, export, or delete local memory later.",
  },
  review: {
    eyebrow: "Review",
    title: "Review the nutrition foundation.",
    helper: "This is the minimum useful profile, not a permanent label.",
    atlasLine: "Atlas will use this foundation to prepare one first plan.",
  },
  "first-plan": {
    eyebrow: "First Plan",
    title: "Atlas is preparing your first move.",
    helper: "One clear food action is better than a complicated dashboard.",
    atlasLine: "The first move is practical, non-medical, and adjustable.",
  },
  complete: {
    eyebrow: "Ready",
    title: "Atlas is ready.",
    helper: "Launch with one useful nutrition move.",
    atlasLine: "Start simple. Improve with real feedback.",
  },
};
