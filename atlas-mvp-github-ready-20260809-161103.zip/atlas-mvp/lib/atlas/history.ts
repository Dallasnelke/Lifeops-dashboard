import type { AtlasRequestHistoryItem } from "./types";

export const MAX_HISTORY_MESSAGES = 12;
export const MAX_HISTORY_CHARACTERS = 12000;

export function truncateUnicode(input: string, maxLength: number): string {
  return Array.from(input).slice(0, maxLength).join("");
}

export function truncateHistory(history: AtlasRequestHistoryItem[]): {
  history: AtlasRequestHistoryItem[];
  truncated: boolean;
} {
  let total = 0;
  const kept: AtlasRequestHistoryItem[] = [];
  for (const item of history.slice(-MAX_HISTORY_MESSAGES).reverse()) {
    const content = truncateUnicode(item.content.trim(), 4000);
    if (!content) continue;
    const nextTotal = total + Array.from(content).length;
    if (nextTotal > MAX_HISTORY_CHARACTERS) break;
    kept.push({ role: item.role, content });
    total = nextTotal;
  }
  kept.reverse();
  return { history: kept, truncated: kept.length < history.length };
}
