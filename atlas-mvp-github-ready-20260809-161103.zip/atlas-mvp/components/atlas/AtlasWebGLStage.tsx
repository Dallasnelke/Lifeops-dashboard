"use client";

import { useEffect, useRef, useState } from "react";
import type {
  AtlasPreferences,
  AtlasState,
  AtlasVisualIntensity,
} from "@/lib/atlas/types";

type AtlasWebGLStageProps = {
  state: AtlasState;
  preferences: AtlasPreferences;
  onReady?: (ready: boolean) => void;
};

type Vec3 = [number, number, number];
type Mat4 = Float32Array;

type MeshBuffers = {
  vertexBuffer: WebGLBuffer;
  normalBuffer: WebGLBuffer;
  indexBuffer: WebGLBuffer;
  indexCount: number;
};

type RendererResources = {
  gl: WebGLRenderingContext;
  program: WebGLProgram;
  mesh: MeshBuffers;
  locations: {
    position: number;
    normal: number;
    model: WebGLUniformLocation;
    viewProjection: WebGLUniformLocation;
    baseColor: WebGLUniformLocation;
    accentColor: WebGLUniformLocation;
    cameraPosition: WebGLUniformLocation;
    lightPosition: WebGLUniformLocation;
    glow: WebGLUniformLocation;
    material: WebGLUniformLocation;
  };
};

type Part = {
  name: string;
  translate: Vec3;
  rotate: Vec3;
  scale: Vec3;
  color: Vec3;
  glow: number;
  material: number;
};

const VERTEX_SHADER = `
attribute vec3 aPosition;
attribute vec3 aNormal;

uniform mat4 uModel;
uniform mat4 uViewProjection;

varying vec3 vNormal;
varying vec3 vWorldPosition;

void main() {
  vec4 worldPosition = uModel * vec4(aPosition, 1.0);
  vWorldPosition = worldPosition.xyz;
  vNormal = normalize(mat3(uModel) * aNormal);
  gl_Position = uViewProjection * worldPosition;
}
`;

const FRAGMENT_SHADER = `
precision mediump float;

uniform vec3 uBaseColor;
uniform vec3 uAccentColor;
uniform vec3 uCameraPosition;
uniform vec3 uLightPosition;
uniform float uGlow;
uniform float uMaterial;

varying vec3 vNormal;
varying vec3 vWorldPosition;

void main() {
  vec3 normal = normalize(vNormal);
  vec3 viewDirection = normalize(uCameraPosition - vWorldPosition);
  vec3 lightDirection = normalize(uLightPosition - vWorldPosition);
  vec3 halfVector = normalize(viewDirection + lightDirection);

  float diffuse = max(dot(normal, lightDirection), 0.0);
  float rim = pow(1.0 - max(dot(normal, viewDirection), 0.0), 2.3);
  float specular = pow(max(dot(normal, halfVector), 0.0), mix(18.0, 68.0, uMaterial));
  float verticalWarmth = smoothstep(-1.7, 2.4, vWorldPosition.y);

  vec3 metal = uBaseColor * (0.46 + diffuse * 0.54);
  vec3 edge = uAccentColor * (rim * (0.16 + uGlow * 0.22) + specular * (0.1 + uMaterial * 0.18));
  vec3 innerWarmth = uAccentColor * verticalWarmth * 0.025;
  vec3 color = metal + edge + innerWarmth;

  gl_FragColor = vec4(color, 1.0);
}
`;

const BLACK_GOLD: Vec3 = [0.018, 0.016, 0.012];
const DEEP_GRAPHITE: Vec3 = [0.04, 0.036, 0.028];
const GLASS_BLACK: Vec3 = [0.024, 0.021, 0.017];
const JOINT_GOLD: Vec3 = [0.58, 0.4, 0.1];

export function AtlasWebGLStage({
  state,
  preferences,
  onReady,
}: AtlasWebGLStageProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<number | null>(null);
  const propsRef = useRef({ state, preferences });
  const [supported, setSupported] = useState(true);

  useEffect(() => {
    propsRef.current = { state, preferences };
  }, [state, preferences]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const gl = canvas.getContext("webgl", {
      alpha: true,
      antialias: true,
      depth: true,
      powerPreference: "high-performance",
      premultipliedAlpha: false,
    });

    if (!gl) {
      setSupported(false);
      onReady?.(false);
      return;
    }

    const resources = createResources(gl);
    if (!resources) {
      setSupported(false);
      onReady?.(false);
      return;
    }
    const activeCanvas = canvas;
    const activeResources = resources;

    onReady?.(true);
    let disposed = false;
    const cameraPosition: Vec3 = [0, 0.48, 8.15];
    const lightPosition: Vec3 = [-2.4, 4.1, 4.3];

    function resizeCanvas() {
      const pixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);
      const rect = activeCanvas.getBoundingClientRect();
      const width = Math.max(1, Math.floor(rect.width * pixelRatio));
      const height = Math.max(1, Math.floor(rect.height * pixelRatio));
      if (activeCanvas.width !== width || activeCanvas.height !== height) {
        activeCanvas.width = width;
        activeCanvas.height = height;
      }
      activeResources.gl.viewport(
        0,
        0,
        activeCanvas.width,
        activeCanvas.height,
      );
    }

    function render(timeMs: number) {
      if (disposed) return;
      resizeCanvas();

      const { state: currentState, preferences: currentPreferences } =
        propsRef.current;
      const t = timeMs / 1000;
      const stateConfig = getStateConfig(currentState);
      const intensity = getIntensity(currentPreferences.visualIntensity);
      const motion =
        currentPreferences.motionStyle === "still"
          ? 0
          : currentPreferences.motionStyle === "alive"
            ? 1.25
            : 0.72;
      const breath = Math.sin(t * (0.85 + stateConfig.speed * 0.35)) * motion;
      const turn = Math.sin(t * 0.28) * 0.045 * motion;
      const viewProjection = createViewProjection(
        activeCanvas.width / Math.max(activeCanvas.height, 1),
        cameraPosition,
      );
      const accent = hexToVector(currentPreferences.accentColor);

      drawScene(activeResources, {
        time: t,
        breath,
        turn,
        accent,
        cameraPosition,
        lightPosition,
        viewProjection,
        glow: stateConfig.glow * intensity,
      });

      frameRef.current = window.requestAnimationFrame(render);
    }

    frameRef.current = window.requestAnimationFrame(render);

    return () => {
      disposed = true;
      if (frameRef.current !== null) {
        window.cancelAnimationFrame(frameRef.current);
        frameRef.current = null;
      }
      cleanupResources(activeResources);
    };
  }, [onReady]);

  if (!supported) {
    return null;
  }

  return (
    <canvas ref={canvasRef} className="atlas-webgl-stage" aria-hidden="true" />
  );
}

function createResources(gl: WebGLRenderingContext): RendererResources | null {
  const vertexShader = compileShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
  const fragmentShader = compileShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER);
  if (!vertexShader || !fragmentShader) return null;

  const program = gl.createProgram();
  if (!program) return null;
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);
  gl.deleteShader(vertexShader);
  gl.deleteShader(fragmentShader);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.error("Atlas WebGL program failed", gl.getProgramInfoLog(program));
    gl.deleteProgram(program);
    return null;
  }

  const mesh = createSphereMesh(gl, 18, 12);
  if (!mesh) {
    gl.deleteProgram(program);
    return null;
  }

  const locations = {
    position: gl.getAttribLocation(program, "aPosition"),
    normal: gl.getAttribLocation(program, "aNormal"),
    model: getUniform(gl, program, "uModel"),
    viewProjection: getUniform(gl, program, "uViewProjection"),
    baseColor: getUniform(gl, program, "uBaseColor"),
    accentColor: getUniform(gl, program, "uAccentColor"),
    cameraPosition: getUniform(gl, program, "uCameraPosition"),
    lightPosition: getUniform(gl, program, "uLightPosition"),
    glow: getUniform(gl, program, "uGlow"),
    material: getUniform(gl, program, "uMaterial"),
  };

  if (
    locations.position < 0 ||
    locations.normal < 0 ||
    Object.values(locations).some((value) => value === null)
  ) {
    cleanupResources({ gl, program, mesh, locations } as RendererResources);
    return null;
  }

  gl.enable(gl.DEPTH_TEST);
  gl.enable(gl.CULL_FACE);
  gl.cullFace(gl.BACK);
  gl.clearColor(0, 0, 0, 0);

  return { gl, program, mesh, locations };
}

function compileShader(
  gl: WebGLRenderingContext,
  type: number,
  source: string,
) {
  const shader = gl.createShader(type);
  if (!shader) return null;
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error("Atlas WebGL shader failed", gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}

function getUniform(
  gl: WebGLRenderingContext,
  program: WebGLProgram,
  name: string,
) {
  const location = gl.getUniformLocation(program, name);
  if (!location) console.error(`Atlas WebGL missing uniform: ${name}`);
  return location as WebGLUniformLocation;
}

function createSphereMesh(
  gl: WebGLRenderingContext,
  columns: number,
  rows: number,
): MeshBuffers | null {
  const vertices: number[] = [];
  const normals: number[] = [];
  const indices: number[] = [];

  for (let y = 0; y <= rows; y += 1) {
    const v = y / rows;
    const theta = v * Math.PI;
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let x = 0; x <= columns; x += 1) {
      const u = x / columns;
      const phi = u * Math.PI * 2;
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);
      const px = cosPhi * sinTheta;
      const py = cosTheta;
      const pz = sinPhi * sinTheta;
      vertices.push(px, py, pz);
      normals.push(px, py, pz);
    }
  }

  for (let y = 0; y < rows; y += 1) {
    for (let x = 0; x < columns; x += 1) {
      const first = y * (columns + 1) + x;
      const second = first + columns + 1;
      indices.push(first, second, first + 1, second, second + 1, first + 1);
    }
  }

  const vertexBuffer = gl.createBuffer();
  const normalBuffer = gl.createBuffer();
  const indexBuffer = gl.createBuffer();
  if (!vertexBuffer || !normalBuffer || !indexBuffer) return null;

  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
  gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.STATIC_DRAW);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
  gl.bufferData(
    gl.ELEMENT_ARRAY_BUFFER,
    new Uint16Array(indices),
    gl.STATIC_DRAW,
  );

  return {
    vertexBuffer,
    normalBuffer,
    indexBuffer,
    indexCount: indices.length,
  };
}

function drawScene(
  resources: RendererResources,
  options: {
    time: number;
    breath: number;
    turn: number;
    accent: Vec3;
    cameraPosition: Vec3;
    lightPosition: Vec3;
    viewProjection: Mat4;
    glow: number;
  },
) {
  const { gl, program, mesh, locations } = resources;
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.useProgram(program);

  gl.bindBuffer(gl.ARRAY_BUFFER, mesh.vertexBuffer);
  gl.enableVertexAttribArray(locations.position);
  gl.vertexAttribPointer(locations.position, 3, gl.FLOAT, false, 0, 0);

  gl.bindBuffer(gl.ARRAY_BUFFER, mesh.normalBuffer);
  gl.enableVertexAttribArray(locations.normal);
  gl.vertexAttribPointer(locations.normal, 3, gl.FLOAT, false, 0, 0);

  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.indexBuffer);
  gl.uniformMatrix4fv(locations.viewProjection, false, options.viewProjection);
  gl.uniform3fv(locations.accentColor, options.accent);
  gl.uniform3fv(locations.cameraPosition, options.cameraPosition);
  gl.uniform3fv(locations.lightPosition, options.lightPosition);

  const bodyParts = createAtlasParts(options);
  for (const part of bodyParts) {
    const model = composeMatrix(part.translate, part.rotate, part.scale);
    gl.uniformMatrix4fv(locations.model, false, model);
    gl.uniform3fv(locations.baseColor, part.color);
    gl.uniform1f(locations.glow, part.glow);
    gl.uniform1f(locations.material, part.material);
    gl.drawElements(gl.TRIANGLES, mesh.indexCount, gl.UNSIGNED_SHORT, 0);
  }
}

function createAtlasParts({
  breath,
  turn,
  glow,
}: {
  time: number;
  breath: number;
  turn: number;
  accent: Vec3;
  cameraPosition: Vec3;
  lightPosition: Vec3;
  viewProjection: Mat4;
  glow: number;
}): Part[] {
  const chestRise = breath * 0.035;
  const headRise = breath * 0.045;
  const armSwing = breath * 0.025;

  return [
    {
      name: "torso",
      translate: [0, 0.72 + chestRise, 0],
      rotate: [0.04, turn, 0],
      scale: [0.48, 0.78, 0.24],
      color: GLASS_BLACK,
      glow: glow * 0.5,
      material: 0.96,
    },
    {
      name: "chest-shell",
      translate: [0, 0.98 + chestRise, 0.03],
      rotate: [0.08, turn, 0],
      scale: [0.58, 0.38, 0.16],
      color: DEEP_GRAPHITE,
      glow: glow * 0.42,
      material: 1,
    },
    {
      name: "pelvis",
      translate: [0, -0.08, 0],
      rotate: [-0.03, turn, 0],
      scale: [0.36, 0.32, 0.21],
      color: BLACK_GOLD,
      glow: glow * 0.32,
      material: 0.9,
    },
    {
      name: "neck",
      translate: [0, 1.52 + headRise * 0.45, 0],
      rotate: [0, turn, 0],
      scale: [0.16, 0.2, 0.14],
      color: BLACK_GOLD,
      glow: glow * 0.25,
      material: 0.88,
    },
    {
      name: "head",
      translate: [0, 1.86 + headRise, 0],
      rotate: [0.03, turn * 1.35, 0],
      scale: [0.23, 0.34, 0.22],
      color: GLASS_BLACK,
      glow: glow * 0.65,
      material: 1,
    },
    {
      name: "face-sensor",
      translate: [0, 1.93 + headRise, 0.2],
      rotate: [0, turn, 0],
      scale: [0.048 + glow * 0.008, 0.048 + glow * 0.008, 0.022],
      color: JOINT_GOLD,
      glow: 0.74 + glow * 0.55,
      material: 0.72,
    },
    {
      name: "core",
      translate: [0, 0.94 + chestRise, 0.2],
      rotate: [0, turn, 0],
      scale: [0.11 + glow * 0.012, 0.11 + glow * 0.012, 0.05],
      color: JOINT_GOLD,
      glow: 0.95 + glow * 0.65,
      material: 0.72,
    },
    limb(
      "upper-arm-left",
      [-0.48, 0.68, 0],
      [0.2, 0.18, 0.58 + armSwing],
      [0.14, 0.5, 0.11],
      glow,
    ),
    limb(
      "upper-arm-right",
      [0.48, 0.68, 0],
      [0.2, -0.18, -0.58 - armSwing],
      [0.14, 0.5, 0.11],
      glow,
    ),
    limb(
      "forearm-left",
      [-0.68, 0.1, 0.03],
      [0.12, 0.1, 0.22 + armSwing],
      [0.12, 0.46, 0.09],
      glow,
    ),
    limb(
      "forearm-right",
      [0.68, 0.1, 0.03],
      [0.12, -0.1, -0.22 - armSwing],
      [0.12, 0.46, 0.09],
      glow,
    ),
    joint("shoulder-left", [-0.42, 1.1 + chestRise, 0.04], glow),
    joint("shoulder-right", [0.42, 1.1 + chestRise, 0.04], glow),
    joint("hand-left", [-0.74, -0.36, 0.05], glow * 0.85),
    joint("hand-right", [0.74, -0.36, 0.05], glow * 0.85),
    limb(
      "thigh-left",
      [-0.19, -0.58, 0],
      [-0.02, 0, 0.1],
      [0.15, 0.64, 0.11],
      glow,
    ),
    limb(
      "thigh-right",
      [0.19, -0.58, 0],
      [-0.02, 0, -0.1],
      [0.15, 0.64, 0.11],
      glow,
    ),
    limb(
      "shin-left",
      [-0.17, -1.34, 0.02],
      [-0.01, 0, -0.02],
      [0.12, 0.62, 0.09],
      glow,
    ),
    limb(
      "shin-right",
      [0.17, -1.34, 0.02],
      [-0.01, 0, 0.02],
      [0.12, 0.62, 0.09],
      glow,
    ),
    joint("knee-left", [-0.19, -0.94, 0.08], glow),
    joint("knee-right", [0.19, -0.94, 0.08], glow),
    joint("foot-left", [-0.16, -1.95, 0.08], glow * 0.9),
    joint("foot-right", [0.16, -1.95, 0.08], glow * 0.9),
  ];
}

function limb(
  name: string,
  translate: Vec3,
  rotate: Vec3,
  scale: Vec3,
  glow: number,
): Part {
  return {
    name,
    translate,
    rotate,
    scale,
    color: BLACK_GOLD,
    glow: glow * 0.24,
    material: 0.88,
  };
}

function joint(name: string, translate: Vec3, glow: number): Part {
  return {
    name,
    translate,
    rotate: [0, 0, 0],
    scale: [0.055 + glow * 0.01, 0.055 + glow * 0.01, 0.055],
    color: JOINT_GOLD,
    glow: 0.95 + glow,
    material: 0.72,
  };
}

function getStateConfig(state: AtlasState) {
  switch (state) {
    case "listening":
      return { glow: 0.62, speed: 1.25 };
    case "thinking":
      return { glow: 0.48, speed: 1.6 };
    case "speaking":
      return { glow: 0.72, speed: 1.45 };
    case "success":
      return { glow: 0.74, speed: 1.85 };
    case "attention":
      return { glow: 0.42, speed: 0.85 };
    case "error":
      return { glow: 0.32, speed: 0.65 };
    case "idle":
    default:
      return { glow: 0.18, speed: 0.8 };
  }
}

function getIntensity(intensity: AtlasVisualIntensity) {
  if (intensity === "minimal") return 0.64;
  if (intensity === "radiant") return 1.28;
  return 1;
}

function hexToVector(hex: string): Vec3 {
  const normalized = /^#[0-9a-f]{6}$/i.test(hex) ? hex : "#d9b45f";
  const value = normalized.slice(1);
  return [
    parseInt(value.slice(0, 2), 16) / 255,
    parseInt(value.slice(2, 4), 16) / 255,
    parseInt(value.slice(4, 6), 16) / 255,
  ];
}

function createViewProjection(aspect: number, cameraPosition: Vec3): Mat4 {
  const projection = perspective(Math.PI / 5.4, aspect, 0.1, 18);
  const view = lookAt(cameraPosition, [0, -0.02, 0], [0, 1, 0]);
  return multiply(projection, view);
}

function composeMatrix(translate: Vec3, rotate: Vec3, scale: Vec3): Mat4 {
  let matrix = identity();
  matrix = multiply(matrix, translation(translate));
  matrix = multiply(matrix, rotationY(rotate[1]));
  matrix = multiply(matrix, rotationX(rotate[0]));
  matrix = multiply(matrix, rotationZ(rotate[2]));
  matrix = multiply(matrix, scaling(scale));
  return matrix;
}

function identity(): Mat4 {
  return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
}

function translation([x, y, z]: Vec3): Mat4 {
  return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1]);
}

function scaling([x, y, z]: Vec3): Mat4 {
  return new Float32Array([x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1]);
}

function rotationX(angle: number): Mat4 {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return new Float32Array([1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]);
}

function rotationY(angle: number): Mat4 {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return new Float32Array([c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]);
}

function rotationZ(angle: number): Mat4 {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return new Float32Array([c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
}

function perspective(
  fieldOfView: number,
  aspect: number,
  near: number,
  far: number,
): Mat4 {
  const f = 1 / Math.tan(fieldOfView / 2);
  const rangeInv = 1 / (near - far);
  return new Float32Array([
    f / aspect,
    0,
    0,
    0,
    0,
    f,
    0,
    0,
    0,
    0,
    (near + far) * rangeInv,
    -1,
    0,
    0,
    near * far * rangeInv * 2,
    0,
  ]);
}

function lookAt(eye: Vec3, target: Vec3, up: Vec3): Mat4 {
  const zAxis = normalize([
    eye[0] - target[0],
    eye[1] - target[1],
    eye[2] - target[2],
  ]);
  const xAxis = normalize(cross(up, zAxis));
  const yAxis = cross(zAxis, xAxis);

  return new Float32Array([
    xAxis[0],
    yAxis[0],
    zAxis[0],
    0,
    xAxis[1],
    yAxis[1],
    zAxis[1],
    0,
    xAxis[2],
    yAxis[2],
    zAxis[2],
    0,
    -dot(xAxis, eye),
    -dot(yAxis, eye),
    -dot(zAxis, eye),
    1,
  ]);
}

function multiply(a: Mat4, b: Mat4): Mat4 {
  const out = new Float32Array(16);
  for (let row = 0; row < 4; row += 1) {
    for (let column = 0; column < 4; column += 1) {
      out[column * 4 + row] =
        a[0 * 4 + row] * b[column * 4 + 0] +
        a[1 * 4 + row] * b[column * 4 + 1] +
        a[2 * 4 + row] * b[column * 4 + 2] +
        a[3 * 4 + row] * b[column * 4 + 3];
    }
  }
  return out;
}

function normalize([x, y, z]: Vec3): Vec3 {
  const length = Math.hypot(x, y, z) || 1;
  return [x / length, y / length, z / length];
}

function cross(a: Vec3, b: Vec3): Vec3 {
  return [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
}

function dot(a: Vec3, b: Vec3): number {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

function cleanupResources(resources: RendererResources) {
  const { gl, program, mesh } = resources;
  gl.deleteBuffer(mesh.vertexBuffer);
  gl.deleteBuffer(mesh.normalBuffer);
  gl.deleteBuffer(mesh.indexBuffer);
  gl.deleteProgram(program);
}
