﻿import { z } from "zod";
import { lifeOpsContextSchema } from "./lifeops-context";

export const personalitySchema = z.enum([
  "calm-strategist",
  "warm-coach",
  "direct-adviser",
  "curious-collaborator",
]);
export const coachingStyleSchema = z.enum([
  "concise",
  "balanced",
  "reflective",
  "step-by-step",
]);
export const atlasFormSchema = z.enum([
  "orb",
  "emblem",
  "humanoid",
  "pet",
  "spirit",
  "robot",
]);

export const safeTextSchema = z.string().trim().min(1).max(4000);

export const historyItemSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().trim().min(1).max(4000),
});

export const atlasRequestSchema = z.object({
  conversationId: z.string().trim().min(1).max(120),
  message: safeTextSchema,
  history: z.array(historyItemSchema).max(24).default([]),
  preferences: z.object({
    personality: personalitySchema.default("calm-strategist"),
    coachingStyle: coachingStyleSchema.default("balanced"),
    atlasName: z.string().trim().min(1).max(32).default("Atlas"),
  }),
  lifeOpsContext: lifeOpsContextSchema.optional(),
});

export const preferencesSchema = z.object({
  name: z.string().trim().min(1).max(32),
  form: atlasFormSchema,
  personality: personalitySchema,
  coachingStyle: coachingStyleSchema,
  accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  speechEnabled: z.boolean(),
  localMemoryEnabled: z.boolean(),
});

export type AtlasValidatedRequest = z.infer<typeof atlasRequestSchema>;
