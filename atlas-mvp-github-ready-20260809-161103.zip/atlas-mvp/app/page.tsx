"use client";

import type { CSSProperties, PointerEvent } from "react";
import { useEffect, useRef, useState } from "react";
import { AtlasChat } from "@/components/atlas/AtlasChat";
import { AtlasWebGLStage } from "@/components/atlas/AtlasWebGLStage";
import { defaultPreferences } from "@/lib/atlas/storage";
import type { AtlasPreferences, AtlasState } from "@/lib/atlas/types";

export default function Home() {
  const [chatOpen, setChatOpen] = useState(false);
  const [atlasState, setAtlasState] = useState<AtlasState>("idle");
  const [webglReady, setWebglReady] = useState(false);
  const [preferences, setPreferences] =
    useState<AtlasPreferences>(defaultPreferences);
  const shellRef = useRef<HTMLElement>(null);
  const pointerFrameRef = useRef<number | null>(null);
  const pendingPointerRef = useRef<{ x: string; y: string } | null>(null);

  const interfaceNodes = Array.from({ length: 6 }, (_, index) => (
    <span
      key={index}
      className={`atlas-interface-node node-${index + 1}`}
      aria-hidden="true"
    />
  ));

  const biometricNodes = Array.from({ length: 5 }, (_, index) => (
    <span
      key={index}
      className={`atlas-bio-node bio-${index + 1}`}
      aria-hidden="true"
    />
  ));

  function handlePointerMove(event: PointerEvent<HTMLButtonElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    pendingPointerRef.current = {
      x: `${((event.clientX - rect.left) / rect.width) * 100}%`,
      y: `${((event.clientY - rect.top) / rect.height) * 100}%`,
    };

    if (pointerFrameRef.current !== null) {
      return;
    }

    pointerFrameRef.current = window.requestAnimationFrame(() => {
      const pointer = pendingPointerRef.current;
      if (pointer) {
        shellRef.current?.style.setProperty("--pointer-x", pointer.x);
        shellRef.current?.style.setProperty("--pointer-y", pointer.y);
      }
      pointerFrameRef.current = null;
    });
  }

  function resetPointer() {
    if (pointerFrameRef.current !== null) {
      window.cancelAnimationFrame(pointerFrameRef.current);
      pointerFrameRef.current = null;
    }
    pendingPointerRef.current = null;
    shellRef.current?.style.setProperty("--pointer-x", "50%");
    shellRef.current?.style.setProperty("--pointer-y", "50%");
  }

  useEffect(() => {
    return () => {
      if (pointerFrameRef.current !== null) {
        window.cancelAnimationFrame(pointerFrameRef.current);
      }
    };
  }, []);

  return (
    <main
      ref={shellRef}
      className={`atlas-visual-shell state-${atlasState} form-${preferences.form} motion-${preferences.motionStyle} intensity-${preferences.visualIntensity} ${webglReady ? "webgl-ready" : ""} ${chatOpen ? "assistant-open" : ""}`}
      data-atlas-state={atlasState}
      style={{ "--atlas-accent": preferences.accentColor } as CSSProperties}
    >
      <button
        className="atlas-visual-stage"
        type="button"
        aria-label={`Open ${preferences.name}`}
        onPointerMove={handlePointerMove}
        onPointerLeave={resetPointer}
        onClick={() => setChatOpen(true)}
      >
        <span className="atlas-deep-space" aria-hidden="true" />
        <span className="atlas-energy-field" aria-hidden="true" />
        <AtlasWebGLStage
          state={atlasState}
          preferences={preferences}
          onReady={setWebglReady}
        />
        <svg
          className="atlas-vector-character"
          viewBox="0 0 420 820"
          aria-hidden="true"
          focusable="false"
        >
          <defs>
            <radialGradient id="atlasGoldCore" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#fff6c8" />
              <stop offset="32%" stopColor="#ffd261" />
              <stop offset="72%" stopColor="#d9a632" stopOpacity="0.28" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="atlasMetal" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fff0a8" stopOpacity="0.66" />
              <stop offset="15%" stopColor="#2a220f" />
              <stop offset="42%" stopColor="#050505" />
              <stop offset="62%" stopColor="#0c0a05" />
              <stop offset="82%" stopColor="#b8872c" stopOpacity="0.58" />
              <stop offset="100%" stopColor="#fff0a8" stopOpacity="0.46" />
            </linearGradient>
            <linearGradient
              id="atlasShadowMetal"
              x1="0%"
              y1="0%"
              x2="100%"
              y2="0%"
            >
              <stop offset="0%" stopColor="#020202" />
              <stop offset="24%" stopColor="#11100d" />
              <stop offset="48%" stopColor="#040404" />
              <stop offset="58%" stopColor="#6f5620" stopOpacity="0.5" />
              <stop offset="72%" stopColor="#0a0805" />
              <stop offset="100%" stopColor="#020202" />
            </linearGradient>
            <radialGradient id="atlasBlackGlass" cx="50%" cy="32%" r="72%">
              <stop offset="0%" stopColor="#4c4124" stopOpacity="0.42" />
              <stop offset="34%" stopColor="#17130b" stopOpacity="0.92" />
              <stop offset="72%" stopColor="#040404" stopOpacity="0.98" />
              <stop offset="100%" stopColor="#000000" />
            </radialGradient>
            <linearGradient
              id="atlasEdgeLight"
              x1="0%"
              y1="0%"
              x2="100%"
              y2="0%"
            >
              <stop offset="0%" stopColor="#ffeeb4" stopOpacity="0.88" />
              <stop offset="36%" stopColor="#d9b45f" stopOpacity="0.18" />
              <stop offset="64%" stopColor="#d9b45f" stopOpacity="0.18" />
              <stop offset="100%" stopColor="#ffeeb4" stopOpacity="0.88" />
            </linearGradient>
            <linearGradient
              id="atlasSpecular"
              x1="0%"
              y1="0%"
              x2="100%"
              y2="0%"
            >
              <stop offset="0%" stopColor="#fff7d2" stopOpacity="0" />
              <stop offset="42%" stopColor="#fff0aa" stopOpacity="0.74" />
              <stop offset="66%" stopColor="#d7a641" stopOpacity="0.36" />
              <stop offset="100%" stopColor="#fff7d2" stopOpacity="0" />
            </linearGradient>
            <linearGradient
              id="atlasEnergyStroke"
              x1="0%"
              y1="0%"
              x2="0%"
              y2="100%"
            >
              <stop offset="0%" stopColor="#fff7d0" stopOpacity="0" />
              <stop offset="18%" stopColor="#fff7d0" stopOpacity="0.95" />
              <stop offset="52%" stopColor="#f0b93d" stopOpacity="0.58" />
              <stop offset="86%" stopColor="#fff0a3" stopOpacity="0.92" />
              <stop offset="100%" stopColor="#fff7d0" stopOpacity="0" />
            </linearGradient>
            <filter
              id="atlasVectorGlow"
              x="-60%"
              y="-60%"
              width="220%"
              height="220%"
            >
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feColorMatrix
                in="blur"
                type="matrix"
                values="1 0 0 0 0.98 0 0.74 0 0 0.55 0 0 0.2 0 0.05 0 0 0 0.8 0"
                result="goldBlur"
              />
              <feMerge>
                <feMergeNode in="goldBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          <g className="vector-aura" filter="url(#atlasVectorGlow)">
            <ellipse cx="210" cy="405" rx="144" ry="342" />
            <path d="M210 40 C258 150 272 250 244 386 C222 494 232 615 210 778" />
            <path d="M210 40 C162 150 148 250 176 386 C198 494 188 615 210 778" />
          </g>

          <g className="vector-body">
            <path
              className="vector-part vector-head"
              d="M184 116 C184 68 198 44 210 38 C222 44 236 68 236 116 C237 158 228 192 210 202 C192 192 183 158 184 116 Z"
            />
            <path
              className="vector-shadow vector-head-shadow"
              d="M210 46 C228 61 232 101 226 143 C223 168 218 188 210 199 C222 186 236 158 236 116 C236 68 222 44 210 38 Z"
            />
            <path
              className="vector-panel"
              d="M195 86 C203 74 217 74 225 86 C223 120 219 151 210 177 C201 151 197 120 195 86 Z"
            />
            <path
              className="vector-specular vector-head-glint"
              d="M195 79 C201 62 217 57 226 80"
            />
            <path
              className="vector-face-line"
              d="M210 54 C210 82 210 126 210 181"
            />
            <circle className="vector-face-sensor" cx="210" cy="104" r="17" />
            <circle
              className="vector-face-sensor-inner"
              cx="210"
              cy="104"
              r="6"
            />
            <path
              className="vector-part vector-neck"
              d="M192 195 L228 195 L235 235 L185 235 Z"
            />
            <path
              className="vector-part vector-chest"
              d="M112 270 C139 220 181 214 210 243 C239 214 281 220 308 270 C288 337 254 389 210 421 C166 389 132 337 112 270 Z"
            />
            <path
              className="vector-shadow vector-torso-shadow"
              d="M210 244 C252 273 271 330 250 382 C237 402 223 416 210 421 C231 357 229 299 210 244 Z"
            />
            <path
              className="vector-part vector-core-shell"
              d="M174 285 C190 256 230 256 246 285 C260 314 244 350 210 356 C176 350 160 314 174 285 Z"
            />
            <circle className="vector-core" cx="210" cy="312" r="39" />
            <circle className="vector-core-inner" cx="210" cy="312" r="17" />
            <path
              className="vector-highlight vector-highlight-left"
              d="M145 263 C166 243 190 250 202 277 C188 324 174 363 154 385 C138 340 132 296 145 263 Z"
            />
            <path
              className="vector-highlight vector-highlight-right"
              d="M275 263 C254 243 230 250 218 277 C232 324 246 363 266 385 C282 340 288 296 275 263 Z"
            />
            <path
              className="vector-specular vector-chest-glint-left"
              d="M145 273 C163 250 188 253 199 282 C188 327 174 361 158 379"
            />
            <path
              className="vector-specular vector-chest-glint-right"
              d="M275 273 C257 250 232 253 221 282 C232 327 246 361 262 379"
            />
            <path
              className="vector-part vector-waist"
              d="M171 412 C188 394 232 394 249 412 L264 500 C246 526 224 540 210 545 C196 540 174 526 156 500 Z"
            />
            <path
              className="vector-shadow vector-waist-shadow"
              d="M210 405 C232 420 246 462 244 508 C231 529 218 540 210 545 C222 494 222 447 210 405 Z"
            />
            <path
              className="vector-part vector-arm vector-arm-left"
              d="M122 279 C95 322 82 374 76 443 C73 475 88 490 101 464 C114 402 134 351 164 305 Z"
            />
            <path
              className="vector-part vector-arm vector-arm-right"
              d="M298 279 C325 322 338 374 344 443 C347 475 332 490 319 464 C306 402 286 351 256 305 Z"
            />
            <path
              className="vector-specular vector-arm-glint-left"
              d="M135 287 C113 336 101 384 94 444"
            />
            <path
              className="vector-specular vector-arm-glint-right"
              d="M285 287 C307 336 319 384 326 444"
            />
            <path
              className="vector-hand vector-hand-left"
              d="M73 452 C58 464 49 482 52 496 C66 492 82 480 96 464 Z"
            />
            <path
              className="vector-hand vector-hand-right"
              d="M347 452 C362 464 371 482 368 496 C354 492 338 480 324 464 Z"
            />
            <path
              className="vector-part vector-leg vector-leg-left"
              d="M158 504 C179 526 195 561 199 616 L191 758 C170 732 154 668 150 608 C147 560 148 528 158 504 Z"
            />
            <path
              className="vector-part vector-leg vector-leg-right"
              d="M262 504 C241 526 225 561 221 616 L229 758 C250 732 266 668 270 608 C273 560 272 528 262 504 Z"
            />
            <path
              className="vector-specular vector-leg-glint-left"
              d="M169 526 C186 568 190 628 188 732"
            />
            <path
              className="vector-specular vector-leg-glint-right"
              d="M251 526 C234 568 230 628 232 732"
            />
          </g>

          <g className="vector-circuits">
            <path d="M210 56 L210 770" />
            <path d="M189 126 C198 153 204 180 210 212 C216 180 222 153 231 126" />
            <path d="M141 270 C174 286 195 300 210 312 C225 300 246 286 279 270" />
            <path d="M129 352 C163 380 188 402 210 432 C232 402 257 380 291 352" />
            <path d="M160 536 C185 574 200 620 210 704 C220 620 235 574 260 536" />
            <path d="M99 452 C130 425 151 396 176 360" />
            <path d="M321 452 C290 425 269 396 244 360" />
          </g>

          <g className="vector-joints">
            <circle cx="210" cy="104" r="15" />
            <circle cx="151" cy="288" r="9" />
            <circle cx="269" cy="288" r="9" />
            <circle cx="91" cy="454" r="8" />
            <circle cx="329" cy="454" r="8" />
            <circle cx="184" cy="610" r="8" />
            <circle cx="236" cy="610" r="8" />
            <circle cx="192" cy="760" r="8" />
            <circle cx="228" cy="760" r="8" />
          </g>
        </svg>
        <span className="atlas-core-glow" aria-hidden="true" />
        <span className="atlas-head-sensor" aria-hidden="true" />
        <span className="atlas-spine-light" aria-hidden="true" />
        <span className="atlas-vertical-light" aria-hidden="true" />
        <span className="atlas-ring ring-a" aria-hidden="true" />
        <span className="atlas-ring ring-b" aria-hidden="true" />
        <span className="atlas-ring ring-c" aria-hidden="true" />
        <span className="atlas-orbit-shell orbit-shell-a" aria-hidden="true" />
        <span className="atlas-orbit-shell orbit-shell-b" aria-hidden="true" />
        <span className="atlas-interface-grid" aria-hidden="true" />
        <span className="atlas-data-rain" aria-hidden="true" />
        {interfaceNodes}
        {biometricNodes}
        <span className="atlas-particles" aria-hidden="true" />
        <span className="atlas-neural-halo" aria-hidden="true" />
        <span className="atlas-ground" aria-hidden="true" />
      </button>
      <AtlasChat
        open={chatOpen}
        onClose={() => {
          setChatOpen(false);
          setAtlasState("idle");
        }}
        onStateChange={setAtlasState}
        onPreferencesChange={setPreferences}
      />
    </main>
  );
}
